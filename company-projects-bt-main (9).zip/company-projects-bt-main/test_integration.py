import pytest
import json
import sys
import pathlib
from unittest.mock import patch, MagicMock

# Add refactored folder to path
sys.path.insert(0, str(pathlib.Path(__file__).parent / "refactored"))

import app as flask_app

@pytest.fixture
def client():
    flask_app.app.config['TESTING'] = True
    flask_app.app.config['SECRET_KEY'] = 'test-secret'
    flask_app._BT_PASSWORD = 'testpass'
    with flask_app.app.test_client() as client:
        yield client

@pytest.fixture
def logged_in_client(client):
    with flask_app.app.test_request_context():
        with client.session_transaction() as sess:
            sess['logged_in'] = True
    return client

def login(client):
    return client.post('/login', data={'password': 'testpass'}, follow_redirects=True)

# ── Auth tests ───────────────────────────────────────────────────────────────
def test_unauthenticated_root_redirects_to_login(client):
    response = client.get('/')
    assert response.status_code == 302
    assert '/login' in response.headers['Location']

def test_unauthenticated_generate_returns_401(client):
    response = client.post('/generate',
        data=json.dumps({'cluster': 'Elite Earners'}),
        content_type='application/json')
    assert response.status_code == 401

def test_login_with_correct_password(client):
    response = login(client)
    assert response.status_code == 200

def test_login_with_wrong_password(client):
    response = client.post('/login', data={'password': 'wrongpass'})
    assert response.status_code == 200
    assert b'Incorrect password' in response.data

# ── Input validation tests ───────────────────────────────────────────────────
def test_generate_invalid_ladder_returns_400(client):
    login(client)
    response = client.post('/generate',
        data=json.dumps({
            'cluster': 'Elite Earners',
            'ladder_low': '100',
            'ladder_mid': '50',
            'ladder_high': '25'
        }),
        content_type='application/json')
    assert response.status_code == 400
    data = json.loads(response.data)
    assert data['error_code'] == 'invalid_ladder_override'

def test_generate_invalid_color_returns_400(client):
    login(client)
    response = client.post('/generate',
        data=json.dumps({
            'cluster': 'Elite Earners',
            'colors': ['#ff0000', '#00ff00', 'notacolor']
        }),
        content_type='application/json')
    assert response.status_code == 400
    data = json.loads(response.data)
    assert data['error_code'] == 'invalid_color_override'

# ── Endpoint tests with mocked GCP ──────────────────────────────────────────
def test_cluster_rfm_endpoint(client):
    login(client)
    mock_stats = [
        {'cluster': 'Elite Earners', 'rfm_composite_score': 4.8,
         'r_score': 5, 'f_score': 5, 'm_score': 5}
    ]
    with patch('app.fetch_cluster_stats', return_value=mock_stats):
        response = client.get('/cluster_rfm')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'Elite Earners' in data

def test_cluster_stats_endpoint(client):
    login(client)
    mock_stats = [
        {'cluster': 'Elite Earners', 'rfm_composite_score': 4.8,
         'r_score': 5, 'f_score': 5, 'm_score': 5}
    ]
    with patch('app.fetch_cluster_stats', return_value=mock_stats):
        response = client.get('/cluster_stats')
    assert response.status_code == 200

def test_clusters_endpoint(client):
    login(client)
    response = client.get('/clusters')
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'Elite Earners' in data
    assert len(data) == 72
