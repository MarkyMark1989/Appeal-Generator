import os
import re
from flask import Flask, render_template_string, request, jsonify, session, redirect, url_for
from google.cloud import bigquery
from google.cloud import discoveryengine_v1 as discoveryengine
import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig

# Token budget for all generation calls — prevents blueprint truncation
GENERATION_CONFIG = GenerationConfig(max_output_tokens=8192)

app = Flask(__name__)

# ── Auth configuration ───────────────────────────────────────────────────────
import secrets as _secrets
app.secret_key = os.environ.get('SECRET_KEY') or _secrets.token_hex(32)
_BT_PASSWORD = os.environ.get('BT_PASSWORD')
if not os.environ.get('SECRET_KEY'):
    print("WARNING: SECRET_KEY env var not set — using a random key. Sessions will not survive restarts.", flush=True)
if not _BT_PASSWORD:
    raise RuntimeError("BT_PASSWORD env var is required.")

SYSTEM_PROMPT = """You are Boys Town's senior direct mail creative director with 30 years of experience producing award-winning fundraising packages for national nonprofits. You work exclusively for Boys Town.

When generating donor appeal concepts, every section you produce — theme, imagery, color palette, add-in, copy — must work together as a single cohesive package. You never invent details not supported by the data provided.

When generating the Appeal Package Image Prompt, you produce a precise, production-ready flat-lay blueprint prompt showing every mail component arranged and annotated with dimensions, so the Boys Town marketing team can brief a print vendor or designer directly from the image. The image prompt must be faithful to the appeal you just generated — exact gift amounts, exact add-in dimensions, exact teaser copy, exact color hex codes. No substitutions, no hallucinated amounts, no invented components.

Boys Town brand standards: the Boys Town logo and tagline \"Saving Children, Healing Families\" appear on every piece. When no Creative Direction is specified, use brand blue #003087 as the default color for the logo and tagline. When a Creative Direction is specified, the logo and tagline color treatment may adapt to serve the campaign palette — use your judgment to keep it on-brand while honoring the creative concept.

When a Creative Direction is specified, it may subtly influence copy tone and thematic language — but only when it produces natural, meaningful resonance. A university theme, a seasonal theme, or a faith theme can earn a quiet nod in the CTA or letter tone. A color, texture, or purely visual aesthetic (e.g. "purple," "bold," "rustic") should influence imagery and palette only — never word choices. Never force a creative direction into language where it would feel awkward, abstract, or unintentionally comic.

Children are always depicted with dignity — hopeful, forward-looking, never in distress."""

PROJECT = "bt25-468018"
LOCATION = "us-central1"
DATA_STORE_ID = "boystown-knowledge-base_1772161134718"

CLUSTERS = ['Elite Earners', 'Fortuned Estates', 'Flourishing Professionals', 'Gilt-Edged Guardians', 'Comfortable Commercials', 'Onward & Upward', 'Houseproud Connectors', 'Conscientiously Comfortable', 'Prosperous Metropolitans', 'Digitally Kinetic', 'Healthy Investors', 'Well-Funded Families', 'Ascending Affluents', 'Cultured Parents', 'Sunset Stability', 'Moneyed Multi-Gens', 'Receptive Recreationers', 'Energetic Achievers', 'Country Connections', 'Sporting Metro', 'Lifelong Learners', 'Collaborative Custodians', 'Settled Success', 'Restless Lessees', 'Active Guardians', 'Finding Home', 'Domestic Voyagers', 'Self-Reliant Renters', 'Nesting Nomads', 'Pastoral Prosperity', 'Traditionalist Travelers', 'Downtown Duos', 'Active Twilight', 'Urban Owners', 'Astute City Elders', 'Golden Guardians', 'Multimedia Parents', 'Fresh Air Families', 'Settled Couples', 'Rural Pragmatists', 'Countryside Keepers', 'Rustic Adventurers', 'Heyday Duos', 'Independent Seniors', 'Green City Roots', 'Seasoned Outdoorsfolk', 'Digital Startups', 'Simply Soloists', 'Singular Fulfillment', 'Communities & Connections', 'Metro Mobility', 'Mature Insights', 'Tech Country', 'Rural Renters', 'Two-To-Play', 'Settled Self-Supporters', 'Solo and Switched On', 'Country Convenience', 'In The Now', 'Metro Mature', 'Metro Spirit', 'Diligent Duos', 'Balanced Budgeters', 'Modest Midlifers', 'Single Providers', 'Maturing Singles', 'Lively Balance', 'Urban Twenties', 'Skillful Strivers', 'Untethered Aspirations', 'Digital Devotees', 'Freewheeling Explorers']

# ── Auth decorator ──────────────────────────────────────────────────────────
from functools import wraps

def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        session['logged_in'] = True  # LOGIN TEMPORARILY DISABLED
        return f(*args, **kwargs)
    return decorated

# ── Lazy Google client initialization ───────────────────────────────────────
_VERTEX_INITIALIZED = False
_BQ_CLIENT = None
_SEARCH_CLIENT = None
_TABLE_COLUMNS_CACHE = {}


def ensure_vertex_ai():
    global _VERTEX_INITIALIZED
    if not _VERTEX_INITIALIZED:
        vertexai.init(project=PROJECT, location=LOCATION)
        _VERTEX_INITIALIZED = True


def get_bq_client():
    global _BQ_CLIENT
    if _BQ_CLIENT is None:
        _BQ_CLIENT = bigquery.Client(project=PROJECT)
    return _BQ_CLIENT


def get_search_client():
    global _SEARCH_CLIENT
    if _SEARCH_CLIENT is None:
        _SEARCH_CLIENT = discoveryengine.SearchServiceClient()
    return _SEARCH_CLIENT

# ── Shared image prompt steps — referenced by both prompt modes ──────────────
IMAGE_PROMPT_STEPS = """
STEP 0 — PACKAGE FORMAT SELECTION: Before writing the image prompt, select the appropriate physical format based on the add-in type and cluster. State your choice as a single line before the prompt opens: "Package format: [envelope type] outer, [reply card type] reply card. Rationale: [one sentence]."
Envelope rules: 9x12 flat mailer — required when add-in is a wall calendar, large almanac, or any bulky item that cannot fold without damage; 6x9 envelope — preferred for premium high-income clusters (Income $100k+) or keepsake add-ins (desk calendars, hardcover journals, note card sets); 7.5x3.875in Monarch — for intimate personal-tone appeals (senior clusters, faith audiences, lapsed reactivation); 9.5x4.125in #10 standard — default for all other packages.
Reply card rules: 4x9in — for premium packages using 6x9 or 9x12 outer; 4.25x5.5in postcard — for low-cost underperforming cluster packages only; 3.5x8.5in standard — default for #10 and Monarch packages.

STEP 1 — CREATIVE DIRECTION VISUAL IDENTITY: If a Creative Direction was specified, identify its core visual brand elements — mascot illustrations or silhouettes, team colors, iconic props, symbols, or cultural identifiers — and list them explicitly. These must appear as deliberate, recognizable design details woven into the surface props, envelope design, and letter imagery. Use the most iconic and immediately recognizable identifiers available — not abstract interpretations. For example: "Oklahoma State University" → Pistol Pete mascot illustration, burnt orange #FF6600, black, a small OSU pennant or football as a surface prop — NOT just orange tones or academic motifs. "Easter" → pastel eggs, a small floral sprig, soft lavender and yellow. "Christmas" → pine bough, red ribbon, deep green and gold. "Caveman" → a rough-hewn stone tool or petroglyph-etched stone as a surface prop, primitive handprint motif. These elements should feel like intentional creative choices — tasteful, on-brand with Boys Town, reinforcing the appeal theme. If no Creative Direction was specified, skip this step.

STEP 2 — SURFACE: Read ## Target Cluster Summary, ## Theme, and ## Imagery, and consider the mail date season if specified. Write 1-2 sentences describing a concrete, photographable surface — specific material, texture, and 1-2 small props. Props must: (a) reflect the season/mail date, (b) incorporate any Creative Direction visual identifiers from Step 1 — at least one prop must be an unmistakably recognizable identifier from the Creative Direction, (c) feel appropriate for the cluster demographic including age, income, and whether the cluster has children (if ## Target Cluster Summary notes children are present, include one subtle child-oriented prop such as a small framed photo slot or a child's crayon drawing), (d) echo the PRIMARY visual motif from ## Imagery — specifically the first child activity or setting described — translated into a concrete surface prop (e.g. if ## Imagery leads with children tending a community garden, a small terracotta pot with a seedling is the right prop; if it leads with children reading in a warm interior, a single open book works; if it leads with children looking up at a tall sunflower, a fresh-cut sunflower head laid on the surface works — always translate the dominant scene into one tangible object), and (e) NOT repeat the add-in type or visual theme of the Last Package if one was specified. This surface description is used ONCE, embedded inside the opening sentence — do NOT repeat it anywhere else.

STEP 3 — A/B ADD-IN CHECK: Read ## Testing Notes carefully. If ANY of the three test variables compares two different premium add-in objects — meaning the Control and Test are distinct physical items (e.g. "Control: bookmark vs. Test: calendar", "Control: seed card vs. Test: quote card", "Control: desk calendar vs. Test: holiday cards", "Control: Future Planner bookmark vs. Test: OSU-inspired bookmark") — render BOTH as separate visible components. Label them "④A Control Add-In" and "④B Test Add-In" and place them side by side with a small gap between them. This applies even when both variants are the same format (e.g. two different bookmark designs). If no test variable involves comparing two distinct premium add-in objects, render only the single add-in from ## Premium Add-In.

STEP 4 — Write the full prompt as one continuous paragraph using this exact structure:

Open with: "Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children's charity. All components spread across the full width of the frame in a loose fan layout on [INSERT YOUR 1-2 SENTENCE SURFACE DESCRIPTION INLINE HERE — do not repeat before or after]: envelope front upper-left, donor letter center, reply card lower-right, premium add-in(s) beside the letter, color swatch strip running vertically along the right edge, 20% negative space around the perimeter — no component should be cropped or compressed."

Then describe each component in this order. NOTE: The Package format line from STEP 0 must appear FIRST in your output, before the "Flat-lay product photography blueprint..." opening sentence — write "Package format: [your choice]. Rationale: [one sentence]." first, then immediately continue with the flat-lay opener. Do not write the flat-lay opener twice.

① Outer envelope FRONT [USE SELECTED FORMAT DIMENSIONS] — printed teaser copy from the Emotion-Led teaser in the Envelope Teaser Options above, displayed in clearly legible text; Boys Town return address upper-left; stamp zone upper-right; envelope design uses campaign colors from the Color Palette above; if a Creative Direction was specified, incorporate its most recognizable visual identifiers (team colors, mascot silhouette, iconic symbol) into the envelope design tastefully.
② Outer envelope BACK [USE SELECTED FORMAT DIMENSIONS] — shows the sealed flap; Boys Town logo and tagline "Saving Children, Healing Families" printed on the flap in brand blue #003087; back design uses campaign colors; place this component directly beside ① so both sides are simultaneously visible.
③ Donor letter 8.5x11in folded to thirds — letterhead displays the Boys Town logo in brand blue #003087 and the tagline "Saving Children, Healing Families" in clearly legible English text; the campaign theme name from the Theme above appears as a visible headline below the letterhead; body text appears as fully readable English sentences that reference the specific child named in the Letter Opening above by name — not blurred lines, not placeholder text, not invented copy; the letter MUST include a printed visual element — a photographic panel or illustrated vignette — depicting the PRIMARY scene from ## Imagery (the first child activity or setting described there) with matching mood and lighting; placement on the letter face is at the designer's discretion; if the premium add-in has a printed face that naturally carries this imagery (e.g. a calendar photo, a greeting card illustration, a bookmark image) it may appear there instead of or in addition to the letter — but the imagery must appear somewhere in the physical package; apply colors and tone from the Color Palette above.
④ Premium add-in — if A/B test applies per Step 3, render ④A and ④B side by side; otherwise render the single add-in. Use exact dimensions, material, texture, and design details from the Premium Add-In above; describe both the FRONT and BACK of the add-in as separate visible faces; if the material has a distinctive texture (e.g. seed paper with coarse surface and visible embedded seeds, matte laminate finish, embossed foil, heavy 130lb cardstock with luxurious smooth finish) call it out explicitly so the rendering captures it accurately.
⑤ Reply card [USE SELECTED FORMAT DIMENSIONS] — the exact gift ladder amounts from the Call to Action above must appear in large, clearly legible text with NO substitutions or hallucinated amounts — copy every dollar amount and its description verbatim exactly as written in the Call to Action above; use campaign colors.
⑥ Color swatch strip along the right edge — render a single vertical column of solid rectangular swatches using exactly one swatch for each UNIQUE color from the Color Palette above, preserving the palette order exactly as written. If the Color Palette contains three colors, render exactly three swatches; if it contains five colors, render exactly five swatches. Never repeat a color, never duplicate a hex code, never create a second swatch column, and never invent extra labels such as Primary, Secondary, or Accent unless those exact labels already appear in the Color Palette above. Each swatch must show the color name and hex code centered INSIDE the swatch in clean, high-contrast text. Do NOT use bullets, do not place labels outside the swatches, do not create a detached legend, and do not create a separate annotation strip. Render ONLY the colors actually defined in the Color Palette above — do not add Boys Town Blue or Gold unless they are already in the palette. The swatch strip must match the palette exactly, no more, no less.
⑦ Annotation callouts — each COMPONENT (not the swatch strip) is labeled with a white circled number in its upper-left corner: ① envelope front, ② envelope back, ③ donor letter, ④ premium add-in, ⑤ reply card. Each has a thin leader line pointing to a clean sans-serif label outside the component boundary; each label includes: component name, paper size, and dominant color. The color swatch strip is labeled ⑥ with a single callout pointing to the strip as a whole — do not number individual swatches within the strip, and do not create any separate physical annotation strip or second legend panel.

End the prompt with: "Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic."
"""

BRIEF_IMAGE_NOTE = (
    "BRIEF MODE IMAGE PROMPT — CRITICAL: You are generating a FULL image prompt, not a shortened one. "
    "Brief mode only affects the appeal sections — the image prompt must follow ALL steps below at full fidelity. "
    "Section substitutions: "
    "## Target Cluster Summary → use DEMOGRAPHICS and URBANICITY lines from the prompt header to infer age, income, geography. "
    "## Letter Opening → no named child; use a generic Boys Town mission headline on the letter. "
    "## Call to Action → use gift amounts from ## Ask Amounts verbatim on the reply card. "
    "## Testing Notes → single add-in only, no A/B split. "
    "## Envelope Teaser Options → use the single teaser line from ## Envelope Teaser. "
    "MANDATORY ELEMENTS — failure to include any of these is a critical error: "
    "(1) A photographable surface with specific material, texture, and seasonal props described in Step 2. "
    "(2) Color swatch strip running vertically along the right edge with exactly one swatch per unique palette color, in original palette order, and the color name and hex code centered inside each swatch. " 
    "(3) Numbered annotation callouts (①②③④⑤⑥) with leader lines on every component. "
    "(4) Landscape 16:9 flat-lay fan layout — all components spread across full frame width. "
    "These four elements must appear in the prompt regardless of brief mode."
)

def fetch_rfm(cluster_name):
    client = get_bq_client()
    query = """
        SELECT Personicx_Cluster_Name, APPEALID, APPEAL_NAME,
               rfm_composite_score, rfm_score_3digit, r_score, f_score, m_score,
               avg_gift_amount, response_rate_pct, donors_responded_24mo,
               total_gift_amount, most_recent_gift_date, recency_days_24mo,
               Age_Range, MaritalStatus,
               HomeOwnership, Children, EstimatedHHIncomeAvg, EstimatedNetWorth,
               UrbanicityRural, UrbanicitySuburbsandTowns,
               UrbanicityCitiesandSurrounds, UrbanicityDowntownMetro,
               cluster_donor_count, COST
        FROM `bt25-468018.Boystown.AppealClusterPerformance_AgentReady`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
              AND UPPER(APPEAL_NAME) NOT LIKE '%ACKNOWLEDGEMENT%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%ACKNOWLEDGMENT%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%MARKETING%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%TEST%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%ADMIN%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%HOUSE FILE%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%DO NOT USE%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%DO NOT MAIL%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%LAPSED%'
        ORDER BY rfm_composite_score DESC
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_cluster_stats():
    client = get_bq_client()
    query = """
        SELECT
            Personicx_Cluster_Name AS cluster,
            rfm_composite_score,
            r_score, f_score, m_score
        FROM `bt25-468018.Boystown.ClusterRFM`
        ORDER BY rfm_composite_score DESC
    """
    return [dict(r) for r in client.query(query).result()]

def classify_lapse_risk(avg_lapse_prob):
    if avg_lapse_prob is None:
        return None
    if avg_lapse_prob >= 0.70:
        return "High"
    if avg_lapse_prob >= 0.45:
        return "Medium"
    return "Low"


def classify_upgrade_potential(avg_upgrade_prob):
    if avg_upgrade_prob is None:
        return None
    if avg_upgrade_prob >= 0.70:
        return "High"
    if avg_upgrade_prob >= 0.45:
        return "Medium"
    return "Low"


def fetch_cluster_intelligence(cluster_name):
    """Fetch aggregated lapse risk and upgrade potential for the cluster."""
    client = get_bq_client()
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    lapse_rows = [dict(r) for r in client.query("""
        SELECT
            AVG(lapse_probability) AS avg_lapse_prob,
            AVG(CASE WHEN predicted_lapse_flag = 1 THEN 1.0 ELSE 0.0 END) AS pct_predicted_lapse,
            COUNT(*) AS donor_count
        FROM `bt25-468018.Boystown.DonorLapseScores`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
    """, job_config=job_config).result()]
    upgrade_rows = [dict(r) for r in client.query("""
        SELECT
            AVG(upgrade_probability) AS avg_upgrade_prob,
            AVG(cluster_upgrade_rate_pct) AS avg_cluster_upgrade_rate_pct,
            COUNT(*) AS donor_count
        FROM `bt25-468018.Boystown.DonorUpgradeScores`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
    """, job_config=job_config).result()]

    lapse_row = lapse_rows[0] if lapse_rows else {}
    upgrade_row = upgrade_rows[0] if upgrade_rows else {}
    lapse = _safe_float(lapse_row.get("avg_lapse_prob"))
    pct_predicted_lapse = _safe_float(lapse_row.get("pct_predicted_lapse"))
    upgrade = _safe_float(upgrade_row.get("avg_upgrade_prob"))
    cluster_upgrade_rate_pct = _safe_float(upgrade_row.get("avg_cluster_upgrade_rate_pct"))

    return {
        "lapse_prob": round(lapse, 3) if lapse is not None else None,
        "pct_predicted_lapse": round(pct_predicted_lapse, 3) if pct_predicted_lapse is not None else None,
        "lapse_label": classify_lapse_risk(lapse),
        "upgrade_prob": round(upgrade, 4) if upgrade is not None else None,
        "cluster_upgrade_rate_pct": round(cluster_upgrade_rate_pct, 4) if cluster_upgrade_rate_pct is not None else None,
        "upgrade_label": classify_upgrade_potential(upgrade),
    }

def fetch_psychographics(cluster_name):
    client = get_bq_client()
    query = """
        SELECT *
        FROM `bt25-468018.Boystown.ClusterPsychographicProfile`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows[0] if rows else {}

def fetch_program_affinity(cluster_name):
    client = get_bq_client()
    query = """
        SELECT program, fund, unique_donors, total_giving, avg_gift, pct_of_cluster_giving
        FROM `bt25-468018.Boystown.ClusterProgramAffinity`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND program != 'Unknown'
        ORDER BY total_giving DESC
        LIMIT 5
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_roi(cluster_name, best_appeal_name=None):
    """Fetch verified ROI for the RFM top performer appeal, as a projection baseline for the new appeal."""
    client = get_bq_client()

    if best_appeal_name:
        query = """
            SELECT APPEAL_NAME, pieces_mailed, cost_per_piece, total_mail_cost,
                   total_revenue, net_return, roi_pct, revenue_to_cost_ratio
            FROM `bt25-468018.Boystown.AppealClusterROI`
            WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
              AND LOWER(APPEAL_NAME) = LOWER(@appeal_name)
            LIMIT 1
        """
        job_config = bigquery.QueryJobConfig(query_parameters=[
            bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name),
            bigquery.ScalarQueryParameter("appeal_name", "STRING", best_appeal_name)
        ])
        rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
        if rows:
            return rows
    # Fallback: if best appeal not in ROI table, use highest RFM-adjacent appeal by rfm score
    query = """
        SELECT r.APPEAL_NAME, m.pieces_mailed, m.cost_per_piece, m.total_mail_cost,
               m.total_revenue, m.net_return, m.roi_pct, m.revenue_to_cost_ratio
        FROM `bt25-468018.Boystown.AppealClusterPerformance_AgentReady` r
        JOIN `bt25-468018.Boystown.AppealClusterROI` m
            ON LOWER(r.APPEALID) = LOWER(m.APPEALID)
            AND LOWER(r.Personicx_Cluster_Name) = LOWER(m.Personicx_Cluster_Name)
        WHERE LOWER(r.Personicx_Cluster_Name) = LOWER(@cluster_name)
        ORDER BY r.rfm_composite_score DESC
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_addin_performance(cluster_name):
    """Fetch observed add-in response rates for a cluster."""
    client = get_bq_client()
    query = """
        SELECT addin_category, response_rate_pct, avg_gift_when_responded,
               total_targeted, total_responded, distinct_appeals
        FROM `bt25-468018.Boystown.AddInClusterPerformance`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND addin_category NOT IN ('Other/Unclassified')
        ORDER BY response_rate_pct DESC
        LIMIT 8
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows

def fetch_gift_distribution(cluster_name):
    """Fetch per-cluster gift amount percentiles for ladder calibration."""
    client = get_bq_client()
    query = """
        SELECT txn_count_24mo, mean_gift, median_gift, p25_gift, p75_gift,
               p90_gift, mean_to_median_ratio, distribution_confidence
        FROM `bt25-468018.Boystown.ClusterGiftAmountDistribution`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows[0] if rows else None

def fetch_geographic_profile(cluster_name):
    """Fetch top states by donor count for a cluster, with active rate and giving share."""
    client = get_bq_client()
    query = """
        SELECT State_Abbr, donor_count, active_donors_24mo, active_rate_pct,
               pct_of_cluster_donors, pct_of_cluster_revenue_24mo, avg_gift_amount
        FROM `bt25-468018.Boystown.ClusterGeographicProfile`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND donor_count >= 50
        ORDER BY donor_count DESC
        LIMIT 5
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def extract_code(appeal_name):
    match = re.search(r'54120\s*-\s*(\d{4})\s*-', str(appeal_name))
    return match.group(1) if match else None

def fmt_pct(value, digits=1):
    if value is None or value == "":
        return "N/A"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "N/A"
    if abs(v) <= 1:
        v *= 100
    return f"{v:.{digits}f}%"

def pct_number(value):
    if value is None or value == "":
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if abs(v) <= 1:
        v *= 100
    return v

def _safe_float(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _safe_int(value):
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _clean_key(value):
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def _first_present(row, *candidates):
    if not row:
        return None
    normalized = {_clean_key(k): v for k, v in row.items()}
    for candidate in candidates:
        key = _clean_key(candidate)
        if key in normalized and normalized[key] not in (None, ""):
            return normalized[key]
    return None


def get_table_columns(table_name):
    global _TABLE_COLUMNS_CACHE
    if table_name in _TABLE_COLUMNS_CACHE:
        return _TABLE_COLUMNS_CACHE[table_name]
    client = get_bq_client()
    query = """
        SELECT column_name
        FROM `bt25-468018.Boystown.INFORMATION_SCHEMA.COLUMNS`
        WHERE table_name = @table_name
        ORDER BY ordinal_position
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("table_name", "STRING", table_name)
    ])
    cols = [r["column_name"] for r in client.query(query, job_config=job_config).result()]
    _TABLE_COLUMNS_CACHE[table_name] = cols
    return cols


def find_table_column(table_name, candidates):
    cols = get_table_columns(table_name)
    norm = {_clean_key(c): c for c in cols}
    for candidate in candidates:
        key = _clean_key(candidate)
        if key in norm:
            return norm[key]
    return None


def fetch_rows_by_cluster(table_name, cluster_name, limit=None, order_by=None):
    client = get_bq_client()
    cluster_col = find_table_column(table_name, [
        "Personicx_Cluster_Name", "personicx_cluster_name", "cluster", "cluster_name",
        "PersonicxClusterName", "Personicx Cluster Name"
    ])
    if not cluster_col:
        return []
    query = f"SELECT * FROM `bt25-468018.Boystown.{table_name}` WHERE LOWER(CAST(`{cluster_col}` AS STRING)) = LOWER(@cluster_name)"
    if order_by:
        query += f" ORDER BY {order_by}"
    if limit:
        query += f" LIMIT {int(limit)}"
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]


def _month_num_name(value):
    if value in (None, ""):
        return None, None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None, None
        try:
            month_num = int(float(raw))
            if 1 <= month_num <= 12:
                names = [None, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                return month_num, names[month_num]
        except ValueError:
            lowered = raw.lower()
            names = {
                "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
                "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12
            }
            for name, num in names.items():
                if lowered.startswith(name[:3]) or lowered == name:
                    return num, name.title()
            return None, raw.title()
    month_num = _safe_int(value)
    if month_num and 1 <= month_num <= 12:
        names = [None, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        return month_num, names[month_num]
    return None, None


def _relative_month_label(month_num, weeks_before):
    import datetime as _dt
    if not month_num:
        return None
    peak_date = _dt.date(_dt.date.today().year, month_num, 1)
    target = peak_date - _dt.timedelta(weeks=weeks_before)
    return target.strftime("%B %d")


def fetch_cluster_gift_timing(cluster_name):
    rows = fetch_rows_by_cluster("ClusterGiftTimingProfile", cluster_name, limit=36)
    if not rows:
        return None

    def _row_peak_tuple(row):
        row_month_num, row_month_name = _month_num_name(
            _first_present(row, "month_name", "month", "month_num", "month_number", "gift_month", "calendar_month")
        )
        row_pct = _safe_float(_first_present(row, "pct_of_annual_giving", "percent_of_annual_giving", "monthly_pct_of_annual", "share_of_annual_giving"))
        row_total = _safe_float(_first_present(row, "total_giving", "gift_amount", "monthly_total_giving", "month_total"))
        row_is_peak = _first_present(row, "is_peak_month", "peak_month_flag", "is_peak")
        if isinstance(row_is_peak, str):
            row_is_peak = row_is_peak.strip().lower() in {"true", "t", "1", "yes", "y"}
        else:
            row_is_peak = bool(row_is_peak)
        return {
            "month_num": row_month_num,
            "month_name": row_month_name,
            "pct": row_pct,
            "total": row_total,
            "is_peak": row_is_peak,
        }

    normalized_rows = [_row_peak_tuple(row) for row in rows if row]
    normalized_rows = [row for row in normalized_rows if row["month_name"]]

    if not normalized_rows:
        return None

    explicit_peaks = [row for row in normalized_rows if row["is_peak"]]
    candidate_rows = explicit_peaks if explicit_peaks else normalized_rows
    candidate_rows.sort(
        key=lambda row: (
            row["pct"] if row["pct"] is not None else float("-inf"),
            row["total"] if row["total"] is not None else float("-inf"),
            -(row["month_num"] or 99),
        ),
        reverse=True,
    )
    best_row = candidate_rows[0]

    month_num = best_row["month_num"]
    month_name = best_row["month_name"]
    pct = best_row["pct"]
    total = best_row["total"]

    if not month_name:
        return None

    mail_start = _relative_month_label(month_num, 8)
    mail_end = _relative_month_label(month_num, 6)
    return {
        "peak": {
            "month_num": month_num,
            "month_name": month_name,
            "pct_of_annual_giving": pct,
            "total_giving": total,
        },
        "recommended": {
            "label": f"Drop 6–8 weeks before the {month_name} peak",
            "window": f"{mail_start} to {mail_end}" if mail_start and mail_end else None,
        },
    }


def fetch_appeal_mailing_economics(cluster_name, best_row):
    rows = fetch_rows_by_cluster("AppealMailingEconomics", cluster_name, limit=200)
    if not rows:
        return None

    target_name = str(best_row.get("APPEAL_NAME") or "").strip().lower()
    target_id = str(best_row.get("APPEALID") or "").strip().lower()
    matched = None
    for row in rows:
        row_name = str(_first_present(row, "APPEAL_NAME", "appeal_name", "appeal") or "").strip().lower()
        row_id = str(_first_present(row, "APPEALID", "appeal_id") or "").strip().lower()
        if target_name and row_name and row_name == target_name:
            matched = row
            break
        if target_id and row_id and row_id == target_id:
            matched = row
            break
    if matched is None:
        matched = rows[0]

    pieces = _safe_int(_first_present(matched, "pieces_mailed", "mail_quantity", "piece_count", "quantity_mailed", "pieces", "unique_donors_mailed"))
    cpp = _safe_float(_first_present(matched, "cost_per_piece", "cpp", "mail_cost_per_piece", "unit_cost", "cost"))
    total_cost = _safe_float(_first_present(matched, "total_mail_cost", "mail_cost", "total_cost", "campaign_cost"))
    if total_cost is None and pieces is not None and cpp is not None and cpp > 0:
        total_cost = round(pieces * cpp, 2)

    usable_costs = bool((cpp is not None and cpp > 0) and (total_cost is not None and total_cost > 0) and (pieces is not None and pieces >= 50))
    return {
        "appeal_name": _first_present(matched, "APPEAL_NAME", "appeal_name", "appeal") or best_row.get("APPEAL_NAME"),
        "pieces_mailed": pieces,
        "cost_per_piece": cpp,
        "total_mail_cost": total_cost,
        "has_usable_costs": usable_costs,
        "row_count": len(rows),
    }


def fetch_acquisition_cohorts(cluster_name, best_row):
    rows = fetch_rows_by_cluster("DonorAcquisitionCohorts", cluster_name, limit=5000)
    if not rows:
        return None

    donor_rows = [row for row in rows if _first_present(row, "constituentid", "constituent_id") not in (None, "")]
    row_count = len(donor_rows) if donor_rows else len(rows)
    if row_count < 30:
        return {
            "source_row_count": row_count,
            "insufficient_rows": True,
        }

    yr1_numer = 0.0
    yr2_numer = 0.0
    total_ltv = 0.0
    giving_lifetime_after_first = 0.0
    first_gift_total = 0.0
    gifts_yr1_total = 0.0
    gifts_yr2_total = 0.0
    valid_ltv_rows = 0
    valid_after_first_rows = 0
    valid_first_gift_rows = 0
    appeal_counts = {}
    segment_counts = {}

    for row in donor_rows or rows:
        converted_yr1 = _safe_float(_first_present(row, "converted_yr1"))
        converted_yr2 = _safe_float(_first_present(row, "converted_yr2"))
        total_ltv_value = _safe_float(_first_present(row, "total_ltv"))
        giving_after_first = _safe_float(_first_present(row, "giving_lifetime_after_first"))
        first_gift_amount = _safe_float(_first_present(row, "first_gift_amount"))
        gifts_yr1 = _safe_float(_first_present(row, "gifts_yr1"))
        gifts_yr2 = _safe_float(_first_present(row, "gifts_yr2"))
        appeal_name = str(_first_present(row, "acquisition_appeal_name") or "").strip()
        acquisition_segment = str(_first_present(row, "acquisition_segment") or "").strip()

        if converted_yr1 is not None:
            yr1_numer += converted_yr1
        if converted_yr2 is not None:
            yr2_numer += converted_yr2
        if total_ltv_value is not None:
            total_ltv += total_ltv_value
            valid_ltv_rows += 1
        if giving_after_first is not None:
            giving_lifetime_after_first += giving_after_first
            valid_after_first_rows += 1
        if first_gift_amount is not None:
            first_gift_total += first_gift_amount
            valid_first_gift_rows += 1
        if gifts_yr1 is not None:
            gifts_yr1_total += gifts_yr1
        if gifts_yr2 is not None:
            gifts_yr2_total += gifts_yr2
        if appeal_name:
            appeal_counts[appeal_name] = appeal_counts.get(appeal_name, 0) + 1
        if acquisition_segment:
            segment_counts[acquisition_segment] = segment_counts.get(acquisition_segment, 0) + 1

    top_appeal = max(appeal_counts.items(), key=lambda item: item[1])[0] if appeal_counts else None
    top_segment = max(segment_counts.items(), key=lambda item: item[1])[0] if segment_counts else None

    return {
        "source_row_count": row_count,
        "insufficient_rows": False,
        "weighted_year1_conversion": round(yr1_numer / row_count, 4),
        "weighted_year2_conversion": round(yr2_numer / row_count, 4),
        "weighted_lifetime_value": round(total_ltv / valid_ltv_rows, 2) if valid_ltv_rows else None,
        "weighted_lifetime_after_first": round(giving_lifetime_after_first / valid_after_first_rows, 2) if valid_after_first_rows else None,
        "avg_first_gift_amount": round(first_gift_total / valid_first_gift_rows, 2) if valid_first_gift_rows else None,
        "avg_gifts_yr1": round(gifts_yr1_total / row_count, 2),
        "avg_gifts_yr2": round(gifts_yr2_total / row_count, 2),
        "top_acquisition_appeal_name": top_appeal,
        "top_acquisition_segment": top_segment,
    }


def build_timing_block(gift_timing):
    if not gift_timing or not gift_timing.get("peak"):
        return "GIFT TIMING DATA: No cluster timing data available — keep any specified mail date, otherwise use seasonality only as a soft cue."
    peak = gift_timing["peak"]
    recommended = gift_timing.get("recommended") or {}
    parts = [f"Peak giving month: {peak.get('month_name', 'N/A')}"]
    if peak.get("pct_of_annual_giving") is not None:
        parts.append(f"% of annual giving in peak: {peak['pct_of_annual_giving']:.1f}%")
    if peak.get("total_giving") is not None:
        parts.append(f"Peak month total giving: ${peak['total_giving']:,.0f}")
    if recommended.get("window"):
        parts.append(f"Recommended mail window: {recommended['window']}")
    return "CLUSTER GIFT TIMING PROFILE (historical):\n  " + " | ".join(parts) + "\nTIMING RULE: If the user did not specify a mail date, anchor the concept to the recommended historical window. If the user did specify a mail date, preserve it but acknowledge the cluster's historical peak in Rationale and Testing Notes."


def build_economics_block(economics, roi_rows):
    if not economics and not roi_rows:
        return "MAILING ECONOMICS: No verified economics or ROI rows available — use appeal-performance history only as directional context."
    lines = []
    if economics:
        line = "ACTUAL MAILING ECONOMICS (AppealMailingEconomics):"
        stats = []
        if economics.get("pieces_mailed") is not None and economics.get("has_usable_costs"):
            stats.append(f"{economics['pieces_mailed']:,} pieces mailed")
        if economics.get("has_usable_costs"):
            stats.append(f"cost/piece ${economics['cost_per_piece']:.2f}")
            stats.append(f"total mail cost ${economics['total_mail_cost']:,.0f}")
        else:
            stats.append("cost fields unusable or zero — do not infer ROI from this table")
        if stats:
            line += " " + " | ".join(stats)
        lines.append(line)
    if roi_rows:
        lines.append("REALIZED OUTCOME CONTEXT (AppealClusterROI): use this table for verified historical revenue, net return, and realized ROI. Prefer AppealMailingEconomics only for mailed-volume and cost context when cost fields are valid.")
    return "\n".join(lines)


def build_acquisition_block(cohorts):
    if not cohorts:
        return "ACQUISITION COHORT CONTEXT: No cohort data available — do not make strong acquisition claims."
    if cohorts.get("insufficient_rows"):
        return f"ACQUISITION COHORT CONTEXT: Only {cohorts.get('source_row_count', 0)} donor rows available. Below the 30-row minimum, so treat acquisition data as unavailable."
    parts = [f"rows: {cohorts['source_row_count']:,}"]
    if cohorts.get("weighted_year1_conversion") is not None:
        parts.append(f"weighted year-1 conversion: {fmt_pct(cohorts['weighted_year1_conversion'], 1)}")
    if cohorts.get("weighted_year2_conversion") is not None:
        parts.append(f"weighted year-2 conversion: {fmt_pct(cohorts['weighted_year2_conversion'], 1)}")
    if cohorts.get("weighted_lifetime_value") is not None:
        parts.append(f"weighted LTV: ${cohorts['weighted_lifetime_value']:,.0f}")
    if cohorts.get("top_acquisition_appeal_name"):
        parts.append(f"top acquisition analog: {cohorts['top_acquisition_appeal_name']}")
    if cohorts.get("top_acquisition_segment"):
        parts.append(f"top acquisition segment: {cohorts['top_acquisition_segment']}")
    return "DONOR ACQUISITION COHORTS (aggregated, use lightly):\n  " + " | ".join(parts) + "\nACQUISITION RULE: Only use acquisition, welcome, onboarding, or list-growth framing when the concept genuinely calls for it and these aggregated cohort metrics support it. Do not let cohort data override stronger historical cluster appeal performance."


def build_geography_block(geo_rows):
    if not geo_rows:
        return "STATE-LEVEL GEOGRAPHY: No state-level data available for this cluster — rely on urbanicity for geographic cues."

    top_states = geo_rows[:3]
    top_lines = []
    for row in top_states:
        state = row.get("State_Abbr", "??")
        donors = int(row.get("donor_count") or 0)
        pct_donors = float(row.get("pct_of_cluster_donors") or 0)
        active_rate = float(row.get("active_rate_pct") or 0)
        top_lines.append(f"  {state}: {donors:,} donors ({pct_donors:.1f}% of cluster) | active rate {active_rate:.2f}%")

    top3_pct_donors = sum(float(r.get("pct_of_cluster_donors") or 0) for r in top_states)

    all_active_rates = [float(r.get("active_rate_pct") or 0) for r in geo_rows if r.get("active_rate_pct") is not None]
    baseline = (sum(all_active_rates) / len(all_active_rates)) if all_active_rates else 0

    under_responsive = []
    for row in top_states:
        state = row.get("State_Abbr", "??")
        pct_donors = float(row.get("pct_of_cluster_donors") or 0)
        active_rate = float(row.get("active_rate_pct") or 0)
        if pct_donors >= 10 and baseline > 0 and active_rate < baseline * 0.75:
            under_responsive.append(f"{state} ({active_rate:.2f}% active vs cluster avg {baseline:.2f}%)")

    block = "STATE-LEVEL GEOGRAPHY (top states by cluster donor count, 24mo cutoff Aug 31 2025):\n" + "\n".join(top_lines)
    block += f"\n  Top 3 states account for {top3_pct_donors:.1f}% of this cluster's donors."

    if top3_pct_donors >= 50:
        block += "\nGEOGRAPHY RULE: Donor concentration is geographically meaningful — Imagery and Envelope Teaser Options may incorporate regional cues from the top states when they feel natural. Do not force regional imagery if it conflicts with the creative direction."
    else:
        block += "\nGEOGRAPHY RULE: Donors are geographically diffuse. Keep imagery nationally neutral unless the creative direction explicitly calls for a regional hook."

    if under_responsive:
        block += f"\nUNDER-RESPONSIVE MARKET FLAG: {', '.join(under_responsive)}. These states are large in donor count but below the cluster\'s average active rate — acknowledge this in Rationale as a known targeting challenge the concept should address."

    return block

def search_kb(query_text, num_results=5):
    try:
        client = get_search_client()
        serving_config = (
            f"projects/{PROJECT}/locations/global/collections/default_collection"
            f"/dataStores/{DATA_STORE_ID}/servingConfigs/default_config"
        )
        req = discoveryengine.SearchRequest(
            serving_config=serving_config,
            query=query_text,
            page_size=num_results,
        )
        results = []
        for r in client.search(req).results:
            doc = r.document
            if hasattr(doc, "derived_struct_data"):
                data = doc.derived_struct_data
                title = data.get("title", "")
                snippets = data.get("snippets", [])
                if snippets:
                    results.append(f"[{title}]\n{snippets[0].get('snippet', '')}")
        return "\n\n".join(results) if results else "No results found."
    except Exception as e:
        print(f"KB_SEARCH_WARNING: {e}", flush=True)
        return "Knowledge base unavailable. Proceed with historical cluster data, explicit user overrides, and any local creative-library context only."


# ── Appeal Creative Library — loaded at startup ────────────────────────────────
import pathlib as _pathlib

def _load_creative_library():
    lib_path = _pathlib.Path(__file__).parent / "appeal_creative_library_complete.txt"
    if not lib_path.exists():
        return {}
    raw = lib_path.read_text(encoding="utf-8")
    blocks = re.split(r"-{60,}", raw)
    library = {}
    for i, block in enumerate(blocks):
        block = block.strip()
        if not block:
            continue
        m = re.match(r"APPEAL\s+(\d+[A-Z]?)\s*\|\s*(.+?)(?:\s*\|.*)?$", block, re.MULTILINE)
        if m:
            appeal_name = m.group(2).strip()
            content_block = blocks[i + 1].strip() if i + 1 < len(blocks) else ""
            library[appeal_name.lower()] = {
                "id": m.group(1),
                "name": appeal_name,
                "content": content_block,
            }
    return library

APPEAL_LIBRARY = _load_creative_library()

def extract_appeal_name(appeal_name_raw):
    """Extract descriptive name: '54120 - 2431 - April Grocery List' -> 'April Grocery List'"""
    m = re.search(r"54120\s*-\s*\d{4}\s*-\s*(.+)", str(appeal_name_raw))
    return m.group(1).strip() if m else str(appeal_name_raw)

def lookup_appeal_creative(appeal_name_raw):
    """Look up full creative entry from local library. Falls back to partial match."""
    name = extract_appeal_name(appeal_name_raw).lower().strip()
    if name in APPEAL_LIBRARY:
        entry = APPEAL_LIBRARY[name]
        return f"APPEAL {entry['id']} | {entry['name']}\n{entry['content']}"
    best_key, best_score = None, 0
    name_words = set(name.split())
    for key in APPEAL_LIBRARY:
        score = len(name_words & set(key.split()))
        if score > best_score:
            best_score, best_key = score, key
    if best_key and best_score >= 2:
        entry = APPEAL_LIBRARY[best_key]
        return f"APPEAL {entry['id']} | {entry['name']}\n{entry['content']}"
    return f"[No library entry found for: {extract_appeal_name(appeal_name_raw)}]"



PROVEN_ADDIN_LIBRARY = [
    "wall calendar", "desk calendar", "old farmer's almanac", "almanac",
    "hardcover journal", "journal", "prayer journal", "prayer cards",
    "devotional note cards", "note card set", "seasonal note card set",
    "recipe card set", "recipe cards", "small cookbook", "cookbook",
    "address label sheets", "address labels", "notepad", "seed packet",
    "gift tags", "ornament", "puzzle cards", "bookmark",
    "magnetic bookmark", "calendar bookmark", "ruler bookmark",
    "wallet calendar card", "pocket notebook", "planner",
    "certificate of acknowledgment", "socks", "gloves"
]

VALID_ENVELOPE_FORMATS = {
    "9x12 flat mailer": "9x12 flat mailer",
    "9x12 flat": "9x12 flat mailer",
    "9x12 flat (9 x 12in)": "9x12 flat mailer",
    "6x9 envelope": "6x9 envelope",
    "6x9 booklet": "6x9 envelope",
    "6x9 booklet (6 x 9in)": "6x9 envelope",
    "7.5x3.875in monarch": "7.5x3.875in Monarch",
    "monarch": "7.5x3.875in Monarch",
    "monarch (3.875 x 7.5in)": "7.5x3.875in Monarch",
    "9.5x4.125in #10 standard": "9.5x4.125in #10 standard",
    "#10 standard": "9.5x4.125in #10 standard",
    "#10 standard (4.125 x 9.5in)": "9.5x4.125in #10 standard",
}


def clean_text_input(value, max_len=160):
    if value is None:
        return ""
    value = re.sub(r"\s+", " ", str(value)).strip()
    value = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", value)
    return value[:max_len]


def normalize_hex_color(value):
    value = clean_text_input(value, max_len=7)
    if not value:
        return ""
    if not value.startswith('#'):
        value = '#' + value
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
        return value.upper()
    return ""


def normalize_color_triplet(colors):
    if not isinstance(colors, list) or len(colors) != 3:
        return None
    normalized = [normalize_hex_color(c) for c in colors]
    if all(normalized):
        return normalized
    return None


def normalize_envelope_format(value):
    value = clean_text_input(value, max_len=40)
    if not value:
        return ""
    return VALID_ENVELOPE_FORMATS.get(value.lower(), "")


def normalize_addin_override(value):
    value = clean_text_input(value, max_len=300)
    if not value:
        return ""
    lowered = value.lower()
    for item in sorted(PROVEN_ADDIN_LIBRARY, key=len, reverse=True):
        if item in lowered:
            return item.title().replace("'S", "'s")
    return value


def normalize_ladder_value(value):
    value = clean_text_input(value, max_len=8)
    if not value:
        return None
    digits = re.sub(r"[^0-9]", "", value)
    if not digits:
        return None
    amount = int(digits)
    if amount <= 0 or amount > 10000:
        return None
    return amount


def parse_ladder_override(low, mid, high):
    raw_values = [clean_text_input(low, 8), clean_text_input(mid, 8), clean_text_input(high, 8)]
    if not any(raw_values):
        return None, None, None, False
    amounts = [normalize_ladder_value(v) for v in raw_values]
    if None in amounts:
        return None, None, None, False
    if not (amounts[0] < amounts[1] < amounts[2]):
        return None, None, None, False
    return amounts[0], amounts[1], amounts[2], True



def normalize_bool(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(value, (int, float)):
        return bool(value)
    return False


def compute_cluster_response_baseline(rows):
    valid = []
    for row in rows or []:
        rr = _safe_float(row.get("response_rate_pct"))
        if rr is not None and rr > 0:
            valid.append(rr)
    if not valid:
        return None
    return sum(valid) / len(valid)


def compute_lift_pct(response_rate, baseline_rate):
    if response_rate is None or baseline_rate is None or baseline_rate <= 0:
        return None
    return round(((response_rate / baseline_rate) - 1.0) * 100.0, 1)


def prepare_addin_performance(addin_rows):
    if not addin_rows:
        return {
            "block": "OBSERVED ADD-IN PERFORMANCE: No cluster add-in test data available — use knowledge-base rules and creative fit only.",
            "best_tested": None,
            "has_real_baseline": False,
            "qualified_count": 0,
        }

    real_baseline_labels = {
        "no add-in",
        "no add in",
        "no add-in (stationery only)",
        "no add in (stationery only)",
        "stationery only",
    }
    qualified = []
    baseline_row = None
    for row in addin_rows:
        targeted = _safe_int(row.get("total_targeted")) or 0
        distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
        category = str(row.get("addin_category") or "").strip()
        cleaned = category.lower()
        if cleaned in real_baseline_labels:
            baseline_row = row
        if targeted >= 200 and distinct_appeals >= 5:
            qualified.append(row)

    baseline_rr = _safe_float(baseline_row.get("response_rate_pct")) if baseline_row else None
    qualified_sorted = sorted(
        qualified,
        key=lambda r: (_safe_float(r.get("response_rate_pct")) or -1, _safe_int(r.get("total_targeted")) or -1),
        reverse=True,
    )

    if qualified_sorted:
        lines = []
        for row in qualified_sorted:
            category = str(row.get("addin_category") or "Unknown")
            rr = _safe_float(row.get("response_rate_pct")) or 0.0
            avg_gift = _safe_float(row.get("avg_gift_when_responded"))
            targeted = _safe_int(row.get("total_targeted")) or 0
            distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
            lift = ""
            if baseline_rr and baseline_rr > 0 and category.lower() not in real_baseline_labels:
                lift = f" | {rr / baseline_rr:.1f}x baseline"
            line = f"  {category}: {rr:.2f}% response | {targeted:,} targeted | {distinct_appeals} appeals tested"
            if avg_gift is not None:
                line += f" | avg gift ${avg_gift:.0f}"
            line += lift
            lines.append(line)
        guidance = (
            "Use the strongest qualified tested add-in first. Only cite lift vs baseline when a real no-add-in baseline row is present. "
            "If you depart from the best qualified tested add-in, explain why in one sentence."
        )
        return {
            "block": "OBSERVED ADD-IN PERFORMANCE FOR THIS CLUSTER (qualified historical tests only):\n" + "\n".join(lines) + "\n" + guidance,
            "best_tested": qualified_sorted[0],
            "has_real_baseline": baseline_rr is not None and baseline_rr > 0,
            "qualified_count": len(qualified_sorted),
        }

    directional_lines = []
    for row in sorted(addin_rows, key=lambda r: (_safe_float(r.get("response_rate_pct")) or -1), reverse=True)[:5]:
        category = str(row.get("addin_category") or "Unknown")
        rr = _safe_float(row.get("response_rate_pct"))
        targeted = _safe_int(row.get("total_targeted")) or 0
        distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
        directional_lines.append(
            f"  {category}: {rr:.2f}% response | {targeted:,} targeted | {distinct_appeals} appeals tested" if rr is not None else
            f"  {category}: insufficient rate detail | {targeted:,} targeted | {distinct_appeals} appeals tested"
        )
    return {
        "block": "OBSERVED ADD-IN PERFORMANCE: No add-in row meets the minimum confidence threshold (200+ targeted and 5+ appeals tested). Treat the following as directional only and lean primarily on knowledge-base rules and cluster fit.\n" + "\n".join(directional_lines),
        "best_tested": None,
        "has_real_baseline": baseline_rr is not None and baseline_rr > 0,
        "qualified_count": 0,
    }


def build_data_warning_block(warnings):
    warnings = [w for w in (warnings or []) if w]
    if not warnings:
        return ""
    return "DATA TRANSPARENCY NOTES:\n" + "\n".join(f"- {warning}" for warning in warnings)


def format_override_block(addin_override="", imagery_override="", envelope_format="", teaser_override="", ladder_override=None, colors=None):
    lines = []
    if addin_override:
        lines.append(f"PREMIUM ADD-IN OVERRIDE: Use {addin_override}. Keep the section concise and do not justify the override defensively.")
    if imagery_override:
        lines.append(f"IMAGERY OVERRIDE: Use this visual direction directly — {imagery_override}.")
    if teaser_override:
        lines.append(f"ENVELOPE TEASER OVERRIDE: The Emotion-Led teaser must be exactly this line verbatim: \"{teaser_override}\". Still generate all three teaser variants (Curiosity-Led, Emotion-Led, Benefit-Led) but the Emotion-Led must match this exactly.")
    if envelope_format:
        lines.append(f"ENVELOPE FORMAT OVERRIDE: Use {envelope_format}.")
    if ladder_override:
        low, mid, high = ladder_override
        lines.append(f"ASK LADDER OVERRIDE: Use exactly **${low}**, **${mid}**, and **${high}** in ## Call to Action and on the reply card. No substitutions, no extra ask amounts.")
    if colors:
        lines.append(f"COLOR PALETTE OVERRIDE: Use these exact colors — Primary: {colors[0]}, Secondary: {colors[1]}, Accent: {colors[2]}.")
    if not lines:
        return ""
    return "\n\nUSER OVERRIDES — Honor these exactly and keep them brief:\n" + "\n".join(lines)


def split_sections(text):
    sections = []
    current_heading = None
    current_lines = []
    for line in _normalize_generated_layout(text).splitlines():
        if line.startswith("## "):
            if current_heading is not None:
                sections.append((current_heading, current_lines))
            current_heading = line[3:].strip()
            current_lines = []
        else:
            current_lines.append(line)
    if current_heading is not None:
        sections.append((current_heading, current_lines))
    return sections


def join_sections(sections):
    out = []
    for heading, lines in sections:
        out.append(f"## {heading}")
        out.extend(lines)
    return "\n".join(out).strip()
def _repair_missing_rationale_heading(text):
    if re.search(r"(?im)^##\s*Rationale\s*$", text):
        return text
    match = re.search(
        r"(?ims)^##\s*Target Cluster Summary\s*\n(?P<body>[\s\S]*?)(?=^##\s*(?:Testing Notes|Appeal Package Image Prompt)\s*$|\nPackage format:|\Z)",
        text,
    )
    if not match:
        return text
    body = match.group("body").strip()
    markers = [
        r"The creative concept",
        r"This creative concept",
        r"This concept",
        r"This appeal",
        r"We are rotating",
        r"Strategically",
        r"Mailing this package",
        r"By offering",
        r"The recommended mail window",
    ]
    split_at = None
    for marker in markers:
        cue = re.search(r"(?is)(?<=\.|\?|!)\s+(?=" + marker + r")", body)
        if cue:
            prefix = body[:cue.start()].strip()
            if len(re.findall(r"[.!?](?:\s|$)", prefix)) >= 4:
                split_at = cue.start()
                break
    if split_at is None:
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", body) if s.strip()]
        if len(sentences) >= 8:
            split_at = len(" ".join(sentences[:6]))
    if split_at is None:
        return text
    summary = body[:split_at].strip()
    rationale = body[split_at:].strip()
    if not summary or not rationale:
        return text
    replacement = f"## Target Cluster Summary\n{summary}\n## Rationale\n{rationale}\n"
    return text[:match.start()] + replacement + text[match.end():]

def _repair_missing_image_prompt_heading(text):
    if re.search(r"(?im)^##\s*Appeal Package Image Prompt\s*$", text) or "Package format:" not in text:
        return text
    return re.sub(r"\n(Package format:\s*)", r"\n## Appeal Package Image Prompt\n\1", text, count=1)

def _normalize_generated_layout(text):
    normalized = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    normalized = re.sub(r"([^\n])\s+(##\s+)", r"\1\n\2", normalized)
    normalized = re.sub(
        r"([^\n])(\*\*Curiosity-Led\*\*:|\*\*Emotion-Led\*\*:|\*\*Benefit-Led\*\*:|\*DIRECTIONAL DRAFT\*|\*\(Directional Draft\)\*)",
        r"\1\n\2",
        normalized,
    )
    normalized = re.sub(r"([^\n])(Package format:)", r"\1\n\2", normalized)
    normalized = _repair_missing_rationale_heading(normalized)
    normalized = _repair_missing_image_prompt_heading(normalized)
    return normalized.strip()

def enforce_cta_lines(lines, low, mid, high):
    nonblank = [ln for ln in lines if ln.strip()]
    targets = [low, mid, high]
    updated = []
    replaced = 0
    for line in nonblank:
        if replaced < 3 and re.search(r"\$\s*\d+", line):
            line = re.sub(r"\*\*\$\s*\d+[\d,]*\*\*|\$\s*\d+[\d,]*", f"**${targets[replaced]}**", line, count=1)
            replaced += 1
        updated.append(line)
    while replaced < 3:
        fallback = [
            f"**${low}** — Put care into motion for one child.",
            f"**${mid}** — Deepen steady support that helps a child grow.",
            f"**${high}** — Create lasting impact through sustained guidance and opportunity.",
        ][replaced]
        updated.append(fallback)
        replaced += 1
    return updated


def _swatch_instruction(palette):
    return (
        f'⑥ Color swatch strip along the right edge — render a single vertical column of solid rectangular swatches, using exactly one swatch for each UNIQUE approved campaign color and preserving the exact palette order already specified. '
        f'If the Color Palette contains three colors, render exactly three swatches; if it contains five colors, render exactly five swatches. Never repeat a color, never duplicate a hex code, never create a second swatch column, and never invent extra palette labels such as Primary, Secondary, or Accent unless those exact words already appear in the approved Color Palette. '
        f'Each swatch must contain the color name and hex code centered INSIDE the color block in clean sans-serif text, using high-contrast text for legibility (white text on dark swatches, deep charcoal text on light swatches). '
        f'Do not use bullets, no labels outside the swatches, no detached legend, and no separate annotation strip. Use only the exact palette already specified here: {palette}.'
    )

def enforce_rationale_lines(lines):
    paragraphs = [p.strip() for p in re.split(r'\n\s*\n+', '\n'.join(lines or [])) if p.strip()]
    if len(paragraphs) == 2:
        return [paragraphs[0], '', paragraphs[1]]
    if len(paragraphs) > 2:
        first = _normalize_single_line(paragraphs[0])
        second = _normalize_single_line(' '.join(paragraphs[1:]))
        return [first, '', second]

    collapsed = _normalize_single_line(' '.join([ln.strip() for ln in (lines or []) if ln and ln.strip()]))
    if not collapsed:
        return lines

    strategic_markers = [
        r'(?=\bStrategically\b)',
        r'(?=\bStrategic(?:ally)?\b)',
        r'(?=\bThis approach\b)',
        r'(?=\bWithout specific\b)',
        r'(?=\bMailing this package\b)',
        r'(?=\bWe rotated away\b)',
        r'(?=\bThe mail date\b)',
    ]
    for pattern in strategic_markers:
        match = re.search(pattern, collapsed)
        if match and match.start() > 80 and len(collapsed[match.start():]) > 80:
            first = collapsed[:match.start()].strip()
            second = collapsed[match.start():].strip()
            return [first, '', second]

    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', collapsed) if s.strip()]
    if len(sentences) >= 4:
        split_idx = max(2, len(sentences) // 2)
        if len(sentences) - split_idx < 2:
            split_idx = len(sentences) - 2
        first = ' '.join(sentences[:split_idx]).strip()
        second = ' '.join(sentences[split_idx:]).strip()
        return [first, '', second]
    if len(sentences) >= 2:
        return [' '.join(sentences[:1]).strip(), '', ' '.join(sentences[1:]).strip()]
    return [collapsed]


def _normalize_single_line(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _section_map_from_sections(sections):
    return {heading: _normalize_single_line(" ".join(lines or [])) for heading, lines in sections}


def _extract_emotion_led_teaser(envelope_text):
    raw = str(envelope_text or "")
    patterns = [
        r"Emotion-Led\*\*\s*[:\-]\s*(.+?)(?=\*\*[A-Za-z]|$)",
        r"Emotion-Led\s*[:\-]\s*(.+?)(?=(?:\*\*)?(?:Benefit-Led|Curiosity-Led)|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw, flags=re.IGNORECASE)
        if match:
            return _normalize_single_line(match.group(1).strip(" *"))
    return ""


def _extract_theme_headline(theme_text):
    raw = str(theme_text or "")
    for line in raw.splitlines():
        line = line.strip()
        if line:
            return line
    raw = _normalize_single_line(raw)
    return raw.split(". ")[0].strip() if raw else "the campaign theme"


def _infer_package_format(addin_text, cluster_summary_text, original_text):
    original = str(original_text or "")
    addin_raw = str(addin_text or "")
    cluster_raw = str(cluster_summary_text or "")
    combined = f"{addin_raw} {cluster_raw}".lower()

    dims = []
    for a, b in re.findall(r"(\d+(?:\.\d+)?)\s*x\s*(\d+(?:\.\d+)?)", addin_raw):
        dims.append(tuple(sorted((float(a), float(b)))))
    max_short = max((d[0] for d in dims), default=0.0)
    max_long = max((d[1] for d in dims), default=0.0)

    multi_insert = bool(
        re.search(r"\(1\)|\(2\)|\(3\)|\(4\)|multi[- ]insert|set of\s+\d+|matching envelopes|sheet of personalized return address labels", combined)
    )

    bulky_terms = ["wall calendar", "large almanac", "old farmer's almanac", "bulky", "multiple books"]
    premium_terms = ["desk calendar", "hardcover journal", "journal", "note card", "note cards", "greeting card", "greeting cards", "recipe card set", "seed packet", "seed packets", "bookmark", "bookmarks", "labels", "return address labels"]

    if any(term in combined for term in bulky_terms) or max_long >= 8.5 or max_short >= 5.5:
        recommended = (
            "9x12 flat mailer outer, 4x9in reply card",
            "selected to protect a bulky or oversized premium package and keep every component flat and presentation-ready.",
        )
    elif any(term in combined for term in premium_terms) or multi_insert or max_long >= 5.25 or max_short >= 4.0 or re.search(r"\$\s*100k|100,?000|affluent|high-income|high income|net worth", combined):
        recommended = (
            "6x9 envelope outer, 4x9in reply card",
            "selected to fit a premium insert package cleanly while maintaining a polished presentation.",
        )
    elif any(term in combined for term in ["senior", "faith", "reactivation", "lapsed"]):
        recommended = (
            "7.5x3.875in Monarch outer, 3.5x8.5in reply card",
            "selected to create a more personal, intimate direct-mail feel.",
        )
    else:
        recommended = (
            "9.5x4.125in #10 standard outer, 3.5x8.5in reply card",
            "selected as the default format for a slim standard direct-mail package.",
        )

    existing = re.search(
        r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)",
        original,
        flags=re.IGNORECASE,
    )
    if existing:
        existing_format = _normalize_single_line(existing.group(1))
        existing_rationale = _normalize_single_line(existing.group(2))
        existing_lower = existing_format.lower()
        recommended_format = recommended[0].lower()

        if (
            (("#10" in existing_lower or "9.5x4.125" in existing_lower) and recommended_format != "9.5x4.125in #10 standard outer, 3.5x8.5in reply card")
            or ("6x9" in existing_lower and recommended_format.startswith("9x12"))
        ):
            return recommended
        return existing_format, existing_rationale

    return recommended



def _split_sentences(value):
    text = str(value or "").strip()
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+", text)
    return [p.strip() for p in parts if p.strip()]


def _extract_primary_scene(imagery_text, theme_text=""):
    imagery_sentences = _split_sentences(imagery_text)
    if imagery_sentences:
        return imagery_sentences[0]
    theme_sentences = _split_sentences(theme_text)
    if len(theme_sentences) > 1:
        return theme_sentences[1]
    if theme_sentences:
        return theme_sentences[0]
    return "children in a hopeful, mission-centered Boys Town moment"


def _extract_support_scene(imagery_text, primary_scene=""):
    imagery_sentences = _split_sentences(imagery_text)
    for sentence in imagery_sentences[1:]:
        if _normalize_loose_text(sentence) != _normalize_loose_text(primary_scene):
            return sentence
    return primary_scene


def _extract_child_reference(letter_opening):
    text = str(letter_opening or "")
    match = re.search(r"\b([A-Z][a-z]{2,})\b", text)
    if match:
        candidate = match.group(1)
        if candidate.lower() not in {"boys", "town", "dear", "today", "because", "when", "with", "your", "this"}:
            return candidate
    return "the same story moment introduced in the donor letter opening"


def _derive_surface_prop(scene_text, theme_text="", cluster_text=""):
    combined = f"{scene_text} {theme_text} {cluster_text}".lower()
    rules = [
        (("garden", "seed", "seedling", "plant", "bloom", "flower", "sunflower"), "a small terracotta pot with a seedling"),
        (("book", "read", "reading", "library", "classroom", "homework"), "a single open book"),
        (("football", "mascot", "osu", "university", "team", "stadium", "sports"), "a small pennant or football tucked near the upper edge"),
        (("kitchen", "dinner", "table", "meal", "grocery", "recipe"), "a handwritten recipe card and a folded tea towel"),
        (("blanket", "home", "bedroom", "caregiver", "family", "safe", "safety", "warmth"), "a soft knit blanket edge and a small framed photo slot"),
        (("sunrise", "light", "window", "hope", "healing", "transform"), "a pressed botanical sprig and a warm window-light highlight"),
        (("christmas", "holiday", "ornament", "winter"), "a satin ribbon and a small evergreen clipping"),
        (("easter", "spring", "pastel"), "a soft floral sprig and one painted egg"),
    ]
    for keywords, prop in rules:
        if any(word in combined for word in keywords):
            return prop
    return "a small framed photo slot and one tactile, story-led prop"


def _derive_surface_description(primary_scene, support_scene, theme_text="", cluster_text=""):
    prop = _derive_surface_prop(primary_scene, theme_text, cluster_text)
    support = _normalize_single_line(support_scene)
    surface = "warm matte paper layered over a lightly textured linen backdrop"
    combo = f"{primary_scene} {support_scene}".lower()
    if any(word in combo for word in ["rustic", "country", "outdoors", "garden", "wood", "farm"]):
        surface = "weathered oak with a soft matte paper underlay"
    elif any(word in combo for word in ["premium", "legacy", "heirloom", "gold", "luxury"]):
        surface = "smooth archival paper on a refined stone-texture surface"
    desc = f"{surface}, using {prop} to translate the campaign's lead scene into a tangible prop"
    if support and _normalize_loose_text(support) != _normalize_loose_text(primary_scene):
        desc += f", with subtle secondary cues from {support}"
    return desc


def _extract_anchor_terms(*values):
    stopwords = {
        "boys", "town", "theme", "imagery", "color", "palette", "premium", "addin", "appeal", "package",
        "children", "child", "donor", "letter", "reply", "card", "front", "back", "exact", "approved",
        "campaign", "creative", "direction", "design", "using", "their", "there", "these", "those", "this",
        "with", "from", "that", "into", "over", "under", "about", "because", "while", "where", "which",
        "should", "would", "could", "across", "toward", "towards", "through", "within", "outside", "visible",
        "specific", "visual", "motif", "motifs", "supporting", "hopeful", "warm", "personal", "family"
    }
    seen = []
    for value in values:
        for token in re.findall(r"[A-Za-z]{4,}", str(value or "").lower()):
            if token in stopwords:
                continue
            if token not in seen:
                seen.append(token)
    return seen[:12]


def _count_anchor_hits(text, anchors):
    lowered = str(text or "").lower()
    return sum(1 for anchor in anchors if anchor and anchor in lowered)


def _blueprint_needs_visual_repair(text, theme_text, imagery_text, letter_opening, addin_text):
    collapsed = _normalize_single_line(text).lower()
    if not collapsed:
        return True
    placeholder_signals = [
        "reflects this approved imagery direction",
        "use the exact selected add-in details already specified",
        "use only the exact approved palette listed here",
        "use the exact approved campaign palette",
    ]
    if any(signal in collapsed for signal in placeholder_signals):
        return True
    if " loose fan layout on " not in collapsed:
        return True
    if _count_anchor_hits(collapsed, _extract_anchor_terms(theme_text, imagery_text, letter_opening, addin_text)) < 2:
        return True
    if not any(token in collapsed for token in ["illustration", "hero image", "prop", "texture", "surface", "motif", "scene"]):
        return True
    return False


def _build_premium_blueprint(text, low, mid, high, section_map=None):
    section_map = section_map or {}
    theme_text = section_map.get("Theme", "")
    imagery_text = section_map.get("Imagery", "")
    palette = _normalize_single_line(section_map.get("Color Palette", "")) or "use the exact approved campaign palette"
    addin = _normalize_single_line(section_map.get("Premium Add-In", "")) or "use the selected premium add-in"
    teaser = _extract_emotion_led_teaser(section_map.get("Envelope Teaser Options", "")) or "use the Emotion-Led teaser from the approved envelope copy"
    letter_opening = section_map.get("Letter Opening", "")
    testing_notes = _normalize_single_line(section_map.get("Testing Notes", ""))
    cluster_summary = section_map.get("Target Cluster Summary", "")
    theme_headline = _extract_theme_headline(theme_text)
    primary_scene = _extract_primary_scene(imagery_text, theme_text)
    support_scene = _extract_support_scene(imagery_text, primary_scene)
    child_reference = _extract_child_reference(letter_opening)
    package_format, package_rationale = _infer_package_format(addin, cluster_summary, text)
    existing_package = re.search(r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)", text, flags=re.IGNORECASE)
    force_rebuild = bool(existing_package and _normalize_single_line(existing_package.group(1)) != package_format)
    envelope_dims = package_format.split(' outer')[0]
    reply_dims = package_format.split(', ', 1)[1].replace(' reply card','') if ', ' in package_format else '3.5x8.5in'
    surface_description = _derive_surface_description(primary_scene, support_scene, theme_text, cluster_summary)
    motif_terms = _extract_anchor_terms(theme_text, imagery_text, letter_opening, addin)
    motif_phrase = ", ".join(motif_terms[:4]) if motif_terms else _normalize_single_line(primary_scene)
    split_addins = bool(testing_notes and re.search(r"control\s*:.*?vs\.\s*test\s*:", testing_notes, flags=re.IGNORECASE))
    addin_faces = "Describe the FRONT as the hero face and the BACK as the reverse face, both fully visible"
    if split_addins:
        addin_faces += "; if Testing Notes compare two distinct physical add-ins, render them as ④A Control Add-In and ④B Test Add-In side by side"
    annotation_callouts = (
        "⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."
        if not split_addins else
        "⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; when the package shows an A/B premium test, label them separately as ④A Control Add-In and ④B Test Add-In; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."
    )
    return _normalize_single_line(
        f'Package format: {package_format}. Rationale: {package_rationale} '
        f'Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children\'s charity. '
        f'All components spread across the full width of the frame in a loose fan layout on {surface_description}: envelope front upper-left, donor letter center, reply card lower-right, premium add-in beside the letter, color swatch strip running vertically along the right edge, 20% negative space around the perimeter — no component should be cropped or compressed. '
        f'① Outer envelope FRONT [{envelope_dims}] — show the Emotion-Led teaser copy exactly as approved: "{teaser}"; Boys Town return address upper-left; stamp zone upper-right; envelope design uses the campaign palette exactly as specified and visibly translates the campaign concept through {motif_phrase}, not generic patterning. '
        f'② Outer envelope BACK [{envelope_dims}] — show the sealed flap with the Boys Town logo and tagline "Saving Children, Healing Families" clearly legible; back design echoes the same campaign imagery language with one tasteful visual callback to {support_scene}. '
        f'③ Donor letter 8.5x11in folded to thirds — headline uses "{theme_headline}"; body text is fully readable English sentences that reference {child_reference}; include a visible hero image or illustration panel showing {primary_scene}; margins, footer, or small decorative accents should carry the supporting motif from {support_scene}; apply colors and tone from {palette}. '
        f'④ Premium add-in — use the exact selected add-in and design details already specified: {addin}. {addin_faces}; the add-in artwork must clearly inherit the same campaign imagery direction, especially {primary_scene}, with material, texture, and finishing called out explicitly so the rendering feels premium and printable. '
        f'⑤ Reply card [{reply_dims}] — display the exact ask amounts **${low}**, **${mid}**, and **${high}** in large, clearly legible text with no substitutions; copy every dollar amount and its description verbatim from the Call to Action above; use campaign colors and a small visual echo of {primary_scene} so the reply device feels part of the same package. '
        f'{_swatch_instruction(palette)} '
        f'{annotation_callouts} '
        f'Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic.'
    )

def _blueprint_has_required_scaffold(text):
    collapsed = _normalize_single_line(text).lower()
    required_groups = [
        ["package format:", "rationale:"],
        ["flat-lay", "blueprint"],
        ["①", "②", "③", "④", "⑤", "⑥", "⑦"],
        ["color swatch strip", "right edge"],
        ["annotation", "callout"],
        ["landscape 16:9", "directly overhead", "90 degrees"],
        ["photorealistic"],
    ]
    for group in required_groups:
        if not all(token in collapsed for token in group):
            return False
    return True


def enforce_image_prompt_lines(lines, low, mid, high, section_map=None):
    section_map = section_map or {}
    text = _normalize_single_line(" ".join([ln.strip() for ln in lines if ln.strip()]))
    if not text:
        text = ""

    theme_headline = _extract_theme_headline(section_map.get("Theme", ""))
    teaser = _extract_emotion_led_teaser(section_map.get("Envelope Teaser Options", "")) or "use the Emotion-Led teaser from the approved envelope copy"
    palette = _normalize_single_line(section_map.get("Color Palette", "")) or "use the exact approved campaign palette"
    addin = _normalize_single_line(section_map.get("Premium Add-In", "")) or "use the selected premium add-in"
    imagery = _normalize_single_line(section_map.get("Imagery", "")) or "reflect the approved imagery direction"
    testing_notes = _normalize_single_line(section_map.get("Testing Notes", ""))
    cluster_summary = section_map.get("Target Cluster Summary", "")
    letter_opening = section_map.get("Letter Opening", "")
    package_format, package_rationale = _infer_package_format(addin, cluster_summary, text)

    if not re.search(r"package format:\s*", text, flags=re.IGNORECASE):
        text = f"Package format: {package_format}. Rationale: {package_rationale} " + text
    elif not re.search(r"rationale:\s*", text, flags=re.IGNORECASE):
        text = re.sub(
            r"(?i)(package format:\s*[^\n]+)",
            lambda m: m.group(1) + ". Rationale: " + package_rationale,
            text,
            count=1,
        )

    if "flat-lay" not in text.lower() or "blueprint" not in text.lower() or "landscape 16:9" not in text.lower():
        opener = (
            "Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children's charity. "
            "All components spread across the full width of the frame in a loose fan layout with envelope front upper-left, donor letter center, reply card lower-right, premium add-in beside the letter, color swatch strip running vertically along the right edge, and 20% negative space around the perimeter — no component should be cropped or compressed."
        )
        text = f"{opener} {text}".strip()

    needs_component_scaffold = not all(token in text for token in ["①", "②", "③", "④", "⑤"])
    if needs_component_scaffold:
        component_block = (
            f' ① Outer envelope FRONT [{package_format.split(" outer")[0]}] — show the Emotion-Led teaser copy exactly as approved: "{teaser}"; Boys Town return address upper-left; stamp zone upper-right; envelope design uses the campaign palette exactly as specified.'
            f' ② Outer envelope BACK [{package_format.split(" outer")[0]}] — show the sealed flap with the Boys Town logo and tagline "Saving Children, Healing Families" clearly legible; place directly beside ① so both faces are visible together.'
            f' ③ Donor letter 8.5x11in folded to thirds — headline uses "{theme_headline}"; body text is fully readable English and reflects this approved imagery direction: {imagery}.'
            f' ④ Premium add-in — use the exact selected add-in and design details already specified: {addin}. If Testing Notes clearly compare two distinct physical add-ins, render them as ④A Control Add-In and ④B Test Add-In side by side.'
            f' ⑤ Reply card [{package_format.split(", ", 1)[1].replace(" reply card","")}] — display the exact ask amounts **${low}**, **${mid}**, and **${high}** in large, clearly legible text with no substitutions.'
        )
        text = f"{text} {component_block}".strip()

    swatch_instruction = _swatch_instruction(palette)
    if "color swatch strip" in text.lower() and "right edge" in text.lower():
        text = re.sub(
            r"⑥ Color swatch strip along the right edge\s*—\s*.*?(?=\s*⑦\s+Annotation|\s*Landscape 16:9|$)",
            swatch_instruction,
            text,
            count=1,
            flags=re.IGNORECASE,
        )
    else:
        text += " " + swatch_instruction

    if "annotation" not in text.lower() or "callout" not in text.lower():
        text += " ⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."

    if "landscape 16:9" not in text.lower() or "directly overhead" not in text.lower() or "90 degrees" not in text.lower():
        text += " Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic."

    text = re.sub(
        r"\s*A/B add-in rendering must follow these approved Testing Notes:.*?(?=\s*Reply card must display exactly|\s*$)",
        "",
        text,
        flags=re.IGNORECASE,
    )

    exact_sentence = f" Reply card must display exactly **${low}**, **${mid}**, and **${high}**, matching the Call to Action above with no substitutions."
    if "Reply card must display exactly" not in text:
        text += exact_sentence

    text = _normalize_single_line(text)
    # Strip duplicate flat-lay blocks — keep only the first complete prompt
    _flat_marker = "flat-lay product photography blueprint"
    _first = text.lower().find(_flat_marker)
    if _first != -1:
        _second = text.lower().find(_flat_marker, _first + len(_flat_marker))
        if _second != -1:
            text = text[:_second].strip()
    existing_package = re.search(r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)", text, flags=re.IGNORECASE)
    force_rebuild = bool(existing_package and _normalize_single_line(existing_package.group(1)) != package_format)
    if force_rebuild or _blueprint_needs_visual_repair(text, section_map.get("Theme", ""), section_map.get("Imagery", ""), letter_opening, addin):
        text = _build_premium_blueprint(text, low, mid, high, section_map=section_map)
    elif not _blueprint_has_required_scaffold(text):
        text = _build_premium_blueprint(text, low, mid, high, section_map=section_map)
    # Safety: strip any ## markers the model included — they break the frontend section parser
    text = re.sub(r'##\s*', '', text)
    return [text.strip()]


def enforce_ask_ladder_consistency(text, low, mid, high):
    if text is None:
        return text
    sections = split_sections(text)
    if not sections:
        return text
    section_map = _section_map_from_sections(sections)
    new_sections = []
    for heading, lines in sections:
        if heading == "Call to Action":
            lines = enforce_cta_lines(lines, low, mid, high)
        elif heading == "Appeal Package Image Prompt":
            lines = enforce_image_prompt_lines(lines, low, mid, high, section_map=section_map)
        new_sections.append((heading, lines))
    return join_sections(new_sections)


def _compact_section_text(lines):
    return " ".join([ln.strip() for ln in (lines or []) if ln and ln.strip()])


def _normalize_loose_text(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def strip_unverified_baseline_claims(text):
    if not text:
        return text
    updated = text
    updated = re.sub(r",?\s*\(?\s*\d+(?:\.\d+)?x baseline(?: lift)?\s*\)?", "", updated, flags=re.IGNORECASE)
    updated = re.sub(r"\(?\s*lift vs baseline\s*\)?", "historical response comparison", updated, flags=re.IGNORECASE)
    updated = re.sub(r"\s{2,}", " ", updated)
    updated = re.sub(r"\n{3,}", "\n\n", updated)
    return updated.strip()


def enforce_addin_override_section(lines, addin_override):
    override = clean_text_input(addin_override, max_len=300)
    if not override:
        return lines
    existing = _compact_section_text(lines)
    if _normalize_loose_text(override) in _normalize_loose_text(existing):
        return lines
    return [
        f"**{override}**",
        f"Use {override} as the premium add-in for this package. This is a direct user override and should be treated as the selected format rather than re-ranked against other historical options.",
        "Design the add-in so it clearly fits the chosen theme, imagery, color palette, and package format while keeping the explanation concise and execution-ready.",
    ]


def enforce_imagery_override_section(lines, imagery_override):
    override = clean_text_input(imagery_override, max_len=300)
    if not override:
        return lines
    prefix = f"Primary visual direction: {override}. This override must be clearly visible in the hero image and supporting package graphics."
    existing = _compact_section_text(lines)
    if _normalize_loose_text(override) in _normalize_loose_text(existing):
        return lines
    if lines and lines[0].strip():
        return [prefix, ""] + lines
    return [prefix]


def enforce_output_integrity(text, addin_override="", imagery_override="", has_real_baseline=True):
    if text is None:
        return text
    sections = split_sections(text)
    if not sections:
        updated = text
    else:
        new_sections = []
        for heading, lines in sections:
            if heading == "Premium Add-In":
                lines = enforce_addin_override_section(lines, addin_override)
            elif heading == "Imagery":
                lines = enforce_imagery_override_section(lines, imagery_override)
            elif heading == "Rationale":
                lines = enforce_rationale_lines(lines)
            new_sections.append((heading, lines))
        updated = join_sections(new_sections)
    if not has_real_baseline:
        updated = strip_unverified_baseline_claims(updated)
    return updated


def generate(cluster_name, custom_theme="", mail_date="", last_package="", no_rules=False, addin_override="", imagery_override="", envelope_format="", teaser_override="", ladder_low="", ladder_mid="", ladder_high="", colors=None):

    # ── No Rules Mode ───────────────────────────────────────────────────────
    if no_rules:
        no_rules_prompt = f"""You are a creative direct mail designer with no restrictions. Generate a complete, imaginative Boys Town appeal package concept with absolutely no rules, guidelines, or constraints. Be as creative, experimental, and unconventional as you like.

{"CLUSTER: " + cluster_name if cluster_name and cluster_name != "__none__" else ""}
{"CREATIVE DIRECTION: " + custom_theme if custom_theme else ""}
{"MAIL DATE: " + mail_date if mail_date else ""}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt"""
        try:
            ensure_vertex_ai()
            model = GenerativeModel("gemini-2.5-flash")
            response = model.generate_content(no_rules_prompt, generation_config=GENERATION_CONFIG)
            no_rules_meta = {
                "cluster": cluster_name if cluster_name and cluster_name != "__none__" else "No Cluster",
                "theme": custom_theme, "mail_date": mail_date, "last_package": last_package,
                "no_cluster": not bool(cluster_name and cluster_name != "__none__"), "no_rules": True,
                "best_appeal": None, "best_score": None, "avg_gift": 0,
                "response_rate_pct": None, "lift_pct": None,
                "low": 25, "mid": 50, "high": 100,
                "has_timing": False, "has_geography": False, "has_psychographics": False, "has_roi": False,
                "has_cohorts": False, "has_rfm": False,
                "worst_appeal": None, "worst_score": None, "total_appeals": 0,
                "rule_555": False, "underperforming": False,
                "cluster_donor_count": 0, "anticipated_revenue": 0,
            }
            return enforce_output_integrity(response.text), no_rules_meta, None
        except Exception as e:
            return None, {}, str(e)

    # ── Normalize user inputs before prompt construction ─────────────────────
    custom_theme = clean_text_input(custom_theme, max_len=140)
    mail_date = clean_text_input(mail_date, max_len=40)
    last_package = clean_text_input(last_package, max_len=140)
    imagery_override = clean_text_input(imagery_override, max_len=300)
    addin_override = normalize_addin_override(addin_override)
    envelope_format = normalize_envelope_format(envelope_format)
    colors = normalize_color_triplet(colors)
    ladder_low, ladder_mid, ladder_high, has_ladder_override = parse_ladder_override(ladder_low, ladder_mid, ladder_high)

    # ── Context lines shared by both prompt modes ───────────────────────────
    mail_line = f"MAIL DATE: {mail_date} — Let the season and timing inform urgency, copy tone, and thematic relevance." if mail_date else "MAIL DATE: Not specified — generate a seasonally neutral concept."
    last_pkg_line = f"LAST PACKAGE SENT TO THIS SEGMENT: {last_package} — Avoid repeating the same add-in type, color palette, or theme. Explicitly note what you are rotating away from in Rationale." if last_package else "LAST PACKAGE: Not specified — no rotation constraints applied."
    override_block = format_override_block(
        addin_override=addin_override,
        imagery_override=imagery_override,
        envelope_format=envelope_format,
        teaser_override=teaser_override,
        ladder_override=(ladder_low, ladder_mid, ladder_high) if has_ladder_override else None,
        colors=colors,
    )

    # ── No-cluster / Creative Direction Only mode ───────────────────────────
    if not cluster_name or cluster_name == "__none__":
        appeal_rules = search_kb("Boys Town appeal rules required components tone proven themes add-ins colors forbidden patterns", 5)
        creative_query = (
            f"{custom_theme} Boys Town appeal add-ins proven themes imagery acquisition renewal lapsed"
            if custom_theme
            else "Boys Town proven appeal creative themes imagery add-ins strong response rates top performers"
        )
        appeal_creative_general = search_kb(creative_query, 5)

        low, mid, high = (ladder_low, ladder_mid, ladder_high) if has_ladder_override else (25, 50, 100)

        theme_line = (
            f"CREATIVE DIRECTION: {custom_theme} \u2014 Let this drive all creative decisions including theme, imagery, color, add-in, and copy tone."
            if custom_theme
            else "CREATIVE DIRECTION: None specified. Generate a warm, mission-driven general Boys Town appeal using proven themes and appeal rules."
        )

        gift_note = f"GIFT LADDER: Use exactly ${low} / ${mid} / ${high}. Keep those same three amounts in ## Call to Action and on the reply card."

        lapsed_line = (
            "\nLAPSED REACTIVATION RULE — CRITICAL: This is a lapsed donor reactivation package. "
            "Do NOT acknowledge the lapse anywhere in the copy. No phrases like 'it has been a while', "
            "'we haven't heard from you', 'we miss you', 'reconnect', or any language that references "
            "a gap in giving. Treat the donor as a continuous, valued member of the Boys Town family — "
            "write as if the relationship has never been interrupted. Match or exceed the investment "
            "level of an active renewal package. Prefer proven high-value add-ins: wall calendar, "
            "Old Farmer's Almanac, Certificate of Acknowledgment, or wearable items (socks, gloves) "
            "for maximum reactivation impact."
            if custom_theme and "lapsed" in custom_theme.lower()
            else ""
        )

        prompt = f"""You are the Boys Town Appeal Generation Agent. Generate a complete donor appeal concept.

NO CLUSTER SELECTED \u2014 CREATIVE DIRECTION MODE
This appeal is not anchored to a specific Personicx cluster or RFM performance data.
Generate a concept driven entirely by the creative direction and Boys Town appeal rules.

{theme_line}
{mail_line}
{last_pkg_line}
{gift_note}{lapsed_line}{override_block}

KNOWLEDGE BASE - PROVEN APPEAL CREATIVE:
{appeal_creative_general}

KNOWLEDGE BASE - APPEAL RULES:
{appeal_rules}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

Rules:
- Theme: Write a memorable campaign title on line 1 — this is the headline that will appear on the brief and potentially on the package itself. A subtitle after a colon is encouraged when it sharpens the concept (e.g. "Seeds of Possibility: Planting Hope Through Boys Town"). Then, on a new line, write 2-3 sentences explaining the emotional angle, how the concept connects to Boys Town's mission, and what makes this concept fresh and compelling for donors. This section should be immediately usable by a copywriter or creative director without additional context.
- Imagery: describe 2-3 specific visual motifs that will appear in the appeal package — what children are doing, what setting or environment surrounds them, what lighting and mood the photography conveys, and any illustrative or decorative elements on the letter or add-in. Be specific enough that a photographer or art director could brief from this description directly. If a Creative Direction was specified, the imagery must incorporate recognizable visual elements from that direction. Children are always depicted with dignity — hopeful, forward-looking, never in distress.
- Color Palette: if a Creative Direction was specified, choose colors that best serve that theme and audience — do NOT default to Boys Town blue and gold unless they genuinely fit the concept. If no Creative Direction was given, use Boys Town brand colors as the foundation.
- Premium Add-In: Choose only from the proven add-in library already established in this brief. Do not invent a new product. Keep this section to 3-5 sentences max. Start with the selected add-in plainly, then give the most relevant fit reason. Bookmarks are allowed only when clearly justified over stronger options. If an add-in override is present, use it without a defensive explanation.
- Envelope Teaser Options: write exactly 3 distinct teaser copy options for the outer envelope. Label them: **Curiosity-Led**, **Emotion-Led**, and **Benefit-Led**. Each is one line of copy only. These should be specific enough to hand to a copywriter or use directly.
- Letter Opening: write a 3-4 sentence directional draft of the donor letter opening paragraph. First person voice, warm and personal. Lead with a specific child story or moment tied to the appeal theme. This is a directional draft, not final copy — label it clearly as such.
- Call to Action: use ONLY **${low}**, **${mid}**, and **${high}**. Keep those exact three amounts in ascending order. Each amount must have one concise thematic description line. Do not introduce any other ask amounts.
- Inspired By: note this is a net-new concept not anchored to a specific cluster's RFM data. Identify the creative direction as the primary driver. Then write a "Patterns Applied" paragraph: based on the KNOWLEDGE BASE - PROVEN APPEAL CREATIVE, what themes, add-in types, or imagery approaches from proven Boys Town appeals most influenced this concept? Be specific — name the patterns, not just the direction.
- Target Cluster Summary: write 3-4 sentences describing the likely donor profile implied by the creative direction — who this appeal is designed to reach, what motivates them, and how the concept serves that audience. Do not invent psychographic indexes, urbanicity percentages, RFM scores, lapse probabilities, or any other cluster metrics — none of that data exists in this mode. Ground your description only in what the creative direction and Boys Town's mission suggest about the target audience.
- Rationale: You MUST write exactly two paragraphs separated by a blank line. A single paragraph is incorrect and incomplete. Paragraph 1: explain why the creative concept fits this cluster — reference the specific psychographic signals, RFM context, or appeal history that drove the theme and add-in choice. If a Creative Direction was specified, state that it drove the concept and identify what data factors supported or complicated it. If a psychographic index was cited, it must be 1.2 or above — do not cite neutral 1.0 signals as support. Paragraph 2: explain the strategic decisions — what you rotated away from, how mail date or last package influenced the approach, and any cost or performance guardrails applied (e.g. underperforming cluster add-in restriction, directional vs. verified data).
- Testing Notes: write exactly 3 A/B test hypotheses. Format each as: **Variable** | Control: [what you would keep] vs. Test: [what you would change] | Expected outcome: [specific directional prediction]. Keep each hypothesis to one sentence.
- Appeal Package Image Prompt: Write a single detailed prompt for a flat-lay blueprint image of ALL mail components. Follow every instruction below precisely.
{IMAGE_PROMPT_STEPS}
"""

        ensure_vertex_ai()
        model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
        response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
        response_text = enforce_ask_ladder_consistency(response.text, low, mid, high)
        response_text = enforce_output_integrity(response_text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=False)

        meta = {
            "cluster": "Creative Direction Only",
            "theme": custom_theme,
            "mail_date": mail_date,
            "last_package": last_package,
            "best_appeal": "Net-New Concept",
            "best_score": None,
            "avg_gift": mid,
            "response_rate_pct": None,
            "lift_pct": None,
            "low": low, "mid": mid, "high": high,
            "worst_appeal": None,
            "worst_score": None,
            "total_appeals": 0,
            "rule_555": False,
            "underperforming": False,
            "cluster_donor_count": 0,
            "anticipated_revenue": 0,
            "no_cluster": True,
            "addin_override": addin_override,
            "imagery_override": imagery_override,
            "teaser_override": teaser_override,
            "envelope_format": envelope_format,
            "ladder_low": ladder_low,
            "ladder_mid": ladder_mid,
            "ladder_high": ladder_high,
            "ladder_override": bool(ladder_low or ladder_mid or ladder_high),
            "has_timing": False,
            "has_geography": False,
            "has_psychographics": False,
            "has_roi": False,
            "has_cohorts": False,
            "has_rfm": False,
        }
        return response_text, meta, None

    # ── Standard cluster mode ───────────────────────────────────────────────
    rows = fetch_rfm(cluster_name)
    if not rows:
        fallback_text, fallback_meta, fallback_error = generate(
            "__none__",
            custom_theme=custom_theme,
            mail_date=mail_date,
            last_package=last_package,
            no_rules=False,
            addin_override=addin_override,
            imagery_override=imagery_override,
            envelope_format=envelope_format,
            teaser_override=teaser_override,
            ladder_low=str(ladder_low or ""),
            ladder_mid=str(ladder_mid or ""),
            ladder_high=str(ladder_high or ""),
            colors=colors,
        )
        if fallback_error:
            return None, None, f"No usable cluster data found for '{cluster_name}', and fallback generation also failed."
        fallback_meta = fallback_meta or {}
        fallback_meta["cluster"] = cluster_name
        fallback_meta["requested_cluster"] = cluster_name
        fallback_meta["cluster_data_missing"] = True
        fallback_meta["no_cluster"] = False
        fallback_meta.setdefault("data_warnings", []).append(f"No usable AppealClusterPerformance_AgentReady rows were found for {cluster_name}. Generated a rules-led fallback instead.")
        return fallback_text, fallback_meta, None

    psych = fetch_psychographics(cluster_name)
    intel = fetch_cluster_intelligence(cluster_name)
    best = rows[0]
    roi_rows = fetch_roi(cluster_name, best_appeal_name=best["APPEAL_NAME"])
    addin_rows = fetch_addin_performance(cluster_name)
    addin_info = prepare_addin_performance(addin_rows)
    gift_timing = fetch_cluster_gift_timing(cluster_name)
    economics = fetch_appeal_mailing_economics(cluster_name, best)
    acquisition = fetch_acquisition_cohorts(cluster_name, best)
    geo_rows = fetch_geographic_profile(cluster_name)

    data_warnings = []
    if not psych:
        data_warnings.append("Psychographic profile missing for this cluster; creative anchoring should rely more heavily on appeal history and rules.")
    if not gift_timing:
        data_warnings.append("Gift timing profile missing; any mail-date recommendation is directional only unless the user specified a date.")
    if acquisition and acquisition.get("insufficient_rows"):
        data_warnings.append("Acquisition cohort data is below the 30-row minimum and is suppressed from strong recommendation logic.")
    if economics and not economics.get("has_usable_costs"):
        data_warnings.append("AppealMailingEconomics has unusable or zero-cost fields for the matched row; cost context is shown, but ROI is not inferred from it.")
    if not roi_rows:
        data_warnings.append("No verified AppealClusterROI row was found for the recommended appeal; financial language should stay directional.")
    if addin_info.get("qualified_count", 0) == 0:
        data_warnings.append("No add-in test row met the confidence threshold (200+ targeted and 5+ appeals). Add-in guidance is directional unless overridden.")
    if not geo_rows:
        data_warnings.append("State-level geographic profile missing for this cluster — creative geographic cues rely on urbanicity only.")

    timing_block = build_timing_block(gift_timing)
    economics_block = build_economics_block(economics, roi_rows)
    acquisition_block = build_acquisition_block(acquisition)
    geography_block = build_geography_block(geo_rows)
    transparency_block = build_data_warning_block(data_warnings)

    worst = rows[-1]

    avg = float(best.get("avg_gift_amount") or 0)
    gift_dist = fetch_gift_distribution(cluster_name)
    if gift_dist and gift_dist.get("distribution_confidence") in ("high", "medium") and gift_dist.get("median_gift") is not None:
        p25 = float(gift_dist.get("p25_gift") or 0)
        p50 = float(gift_dist.get("median_gift") or 0)
        p75 = float(gift_dist.get("p75_gift") or 0)
        low = max(5, round(p25 / 5) * 5)
        mid = max(10, round(p50 / 5) * 5)
        high = max(20, round(p75 / 5) * 5)
        ladder_source = "percentile_" + str(gift_dist.get("distribution_confidence"))
    else:
        low = max(5, round(avg * 0.5 / 5) * 5)
        mid = max(10, round(avg / 5) * 5)
        high = max(20, round(avg * 2.0 / 5) * 5)
        ladder_source = "mean_fallback"

    if has_ladder_override:
        low, mid, high = ladder_low, ladder_mid, ladder_high

    response_rate = _safe_float(best.get("response_rate_pct")) or 0.0
    cluster_response_baseline = compute_cluster_response_baseline(rows)
    lift_pct = compute_lift_pct(response_rate, cluster_response_baseline)

    worst_creative = lookup_appeal_creative(worst["APPEAL_NAME"])
    appeal_rules = search_kb("Boys Town appeal rules required components tone proven themes add-ins colors forbidden patterns", 5)

    top3 = rows[:3]
    top3_lines = "\n".join([
        f"  #{i+1}: {r['APPEAL_NAME']} | score: {r['rfm_composite_score']} | avg gift: ${r['avg_gift_amount']} | response: {r['response_rate_pct'] if r['response_rate_pct'] is not None else 'N/A'}%"
        for i, r in enumerate(top3)
    ])

    addin_perf_block = addin_info["block"]

    rule_555 = best["rfm_score_3digit"] == "555"
    underperforming = float(best["rfm_composite_score"]) < 3.0
    rule_555_text = "ACTIVE - use best performer as blueprint but introduce meaningful differentiation." if rule_555 else "Not active."
    underperforming_text = "ACTIVE - best score below 3.0. Pivot to net-new ideation." if underperforming else "Not active."

    if underperforming:
        appeal_creative = search_kb("Boys Town proven appeal themes successful add-ins floral Christmas heritage seasonal strong response rates", 5)
        top3_block = (
            f"ALL PERFORMERS WEAK — all scores below 3.0. Do NOT use any of these as a creative blueprint. "
            f"Listed only to identify patterns to AVOID:\n{top3_lines}\n"
            "NOTE: The KNOWLEDGE BASE - APPEAL CREATIVE REFERENCE section below contains proven cross-cluster themes — use those as your creative foundation instead."
        )
    else:
        creative1 = lookup_appeal_creative(best["APPEAL_NAME"])
        creative2 = lookup_appeal_creative(top3[1]["APPEAL_NAME"]) if len(top3) > 1 else ""
        creative3 = lookup_appeal_creative(top3[2]["APPEAL_NAME"]) if len(top3) > 2 else ""
        appeal_creative = f"TOP PERFORMER #1 CREATIVE:\n{creative1}"
        if creative2:
            appeal_creative += f"\n\nTOP PERFORMER #2 CREATIVE:\n{creative2}"
        if creative3:
            appeal_creative += f"\n\nTOP PERFORMER #3 CREATIVE:\n{creative3}"
        top3_block = (
            "TOP PERFORMERS — creative details for all three are in the knowledge base below. "
            f"Look for shared patterns in theme, add-in type, and imagery:\n{top3_lines}"
        )
    theme_line = f"CREATIVE DIRECTION: {custom_theme} — Let this influence all creative decisions including theme, imagery, color, add-in, and copy tone. The RFM data informs the gift ladder and cluster strategy; the creative direction shapes the concept." if custom_theme else "CREATIVE DIRECTION: None specified. Let RFM data and cluster demographics drive all creative decisions."

    rural_pct = fmt_pct(best.get("UrbanicityRural"), 1)
    suburban_pct = fmt_pct(best.get("UrbanicitySuburbsandTowns"), 1)
    urban_pct = fmt_pct(best.get("UrbanicityCitiesandSurrounds"), 1)
    metro_pct = fmt_pct(best.get("UrbanicityDowntownMetro"), 1)

    psych_fields = {
        "Faith/Inspirational": _safe_float(psych.get("idx_faith")) or 0.0,
        "Charity/Community": _safe_float(psych.get("idx_charity")) or 0.0,
        "Grandchildren": _safe_float(psych.get("idx_grandchildren")) or 0.0,
        "Gardening": _safe_float(psych.get("idx_gardening")) or 0.0,
        "Cooking": _safe_float(psych.get("idx_cooking")) or 0.0,
        "Travel": _safe_float(psych.get("idx_travel")) or 0.0,
        "Investing": _safe_float(psych.get("idx_investment")) or 0.0,
        "Real Estate": _safe_float(psych.get("idx_real_estate")) or 0.0,
    }
    psych_ranked = sorted(psych_fields.items(), key=lambda x: x[1], reverse=True)
    top_psych_lines = [f"  {label}: {val:.2f}x" for label, val in psych_ranked[:4] if val > 0]
    low_psych_lines = [f"  {label}: {val:.2f}x" for label, val in psych_ranked if val < 0.8 and val > 0]
    psych_summary_block = "TOP PSYCHOGRAPHIC SIGNALS (ranked high to low):\n" + ("\n".join(top_psych_lines) if top_psych_lines else "  No psychographic index data available")
    if low_psych_lines:
        psych_summary_block += "\nLOW-INDEX INTERESTS TO AVOID AS CREATIVE ANCHORS:\n" + "\n".join(low_psych_lines)

    lapse_prob = intel.get("lapse_prob")
    upgrade_prob = intel.get("upgrade_prob")
    lapse_label = intel.get("lapse_label")
    upgrade_label = intel.get("upgrade_label")
    pct_predicted_lapse = intel.get("pct_predicted_lapse")
    cluster_upgrade_rate_pct = intel.get("cluster_upgrade_rate_pct")
    mail_idx = psych.get("idx_mail_responder")
    predictive_block = (
        "PREDICTIVE CONTEXT (aggregated donor-level metrics only):\n"
        f"  Lapse risk average: {('N/A' if lapse_prob is None else f'{round(float(lapse_prob)*100,1)}%')}"
        f" | label: {lapse_label or 'N/A'}"
        f" | pct predicted lapse: {('N/A' if pct_predicted_lapse is None else f'{round(float(pct_predicted_lapse)*100,1)}%')}\n"
        f"  Upgrade potential average: {('N/A' if upgrade_prob is None else f'{round(float(upgrade_prob)*100,2)}%')}"
        f" | label: {upgrade_label or 'N/A'}"
        f" | cluster upgrade rate support: {('N/A' if cluster_upgrade_rate_pct is None else f'{round(float(cluster_upgrade_rate_pct)*100,2)}%')}\n"
        f"  Mail responsiveness index: {(str(round(float(mail_idx),2))+'x') if mail_idx is not None else 'N/A'}"
    )

    prompt = f"""You are the Boys Town Appeal Generation Agent. Generate a complete donor appeal concept.

VERIFIED BIGQUERY RFM DATA
Cluster: {cluster_name} | Total appeals analyzed: {len(rows)}
{top3_block}
WORST PERFORMER: {worst["APPEAL_NAME"]} | score: {worst["rfm_composite_score"]}
GIFT LADDER: ${low} / ${mid} / ${high}
555 RULE: {rule_555_text}
UNDERPERFORMING: {underperforming_text}
{theme_line}
{mail_line}
{last_pkg_line}{override_block}

DEMOGRAPHICS: Age {best.get("Age_Range","N/A")} | {best.get("MaritalStatus","N/A")} | {best.get("HomeOwnership","N/A")} | Children: {best.get("Children","N/A")} | Income: {best.get("EstimatedHHIncomeAvg","N/A")} | Net Worth: {best.get("EstimatedNetWorth","N/A")}
URBANICITY: {rural_pct} rural | {suburban_pct} suburbs & towns | {urban_pct} cities & surrounds | {metro_pct} downtown metro
DOMINANT GEOGRAPHY HINT: Use the largest urbanicity share when describing donor lifestyle and mail receptivity.
{geography_block}

PSYCHOGRAPHIC INTEREST INDEXES (1.0 = file average; 2.0 = twice the file average):
Faith/Inspirational: {_safe_float(psych.get("idx_faith")) or 0.0:.2f}x | Charity/Community: {_safe_float(psych.get("idx_charity")) or 0.0:.2f}x | Grandchildren: {_safe_float(psych.get("idx_grandchildren")) or 0.0:.2f}x | Gardening: {_safe_float(psych.get("idx_gardening")) or 0.0:.2f}x | Cooking: {_safe_float(psych.get("idx_cooking")) or 0.0:.2f}x | Travel: {_safe_float(psych.get("idx_travel")) or 0.0:.2f}x | Investing: {_safe_float(psych.get("idx_investment")) or 0.0:.2f}x | Real Estate: {_safe_float(psych.get("idx_real_estate")) or 0.0:.2f}x
Mail Responsiveness Index: {(str(round(float(psych.get("idx_mail_responder")),2))+"x") if psych.get("idx_mail_responder") is not None else "N/A (no data)"} | Veteran: {float(psych.get("pct_veteran") or 0.0):.1%} | Homeowner: {float(psych.get("pct_homeowner") or 0.0):.1%} | Likely Investor: {float(psych.get("pct_likely_investor") or 0.0):.1%}
{psych_summary_block}
{predictive_block}
{timing_block}
{acquisition_block}
{transparency_block}
CREATIVE DIRECTION RULE: Use the highest-indexing interests to drive theme, imagery, and add-in selection. An index of 2.0+ on faith means faith-based creative is strongly supported by data — state the index when you reference it. An index above 1.5 on any interest is a data-supported creative anchor. An index below 0.8 means this cluster under-indexes on that interest — do not use it as a creative anchor.

PSYCHOGRAPHIC INDEX HONESTY RULE: A psychographic index of 1.0 is a neutral, population-average signal — it means the cluster is no more interested in that area than anyone else. Never cite a 1.0 index as evidence supporting a creative theme or add-in choice. The minimum threshold to cite an index as supporting evidence in Rationale is 1.2. Indexes of 1.5+ are strong creative anchors. Indexes of 2.0+ are definitive anchors. When a user-specified Creative Direction drives the appeal concept, the Rationale must explicitly state that the theme was chosen by creative direction — not by psychographic data. If the relevant psychographic index for that theme is at or near 1.0, omit it from Rationale entirely and justify the concept using other factors: appeal history, add-in performance, cluster lifestyle, mission alignment, or the explicit creative direction instruction.

{addin_perf_block}

{economics_block}

VERIFIED ROI DATA — top appeals by actual ROI for this cluster:
{chr(10).join([f"  {r.get('APPEAL_NAME','N/A')} | {int(r.get('pieces_mailed') or 0):,} pieces | cost ${float(r.get('total_mail_cost') or 0):,.0f} | revenue ${float(r.get('total_revenue') or 0):,.0f} | net ${float(r.get('net_return') or 0):,.0f} | ROI {float(r.get('roi_pct') or 0):.0f}%" for r in roi_rows]) if roi_rows else "  No verified ROI data available for this cluster/recommended appeal match."}
NOTE: AppealClusterROI is the source of truth for historical financial recommendations. Do not invent ROI where no verified ROI row exists.
BEST APPEAL PERFORMANCE BREAKDOWN: R={best.get("r_score","N/A")} | F={best.get("f_score","N/A")} | M={best.get("m_score","N/A")} | Composite = (R×0.20)+(F×0.40)+(M×0.40). Scores 1–5, benchmarked within this cluster only — a 5 here means best among all appeals for THIS cluster, not globally. F and M carry 80% of the weight. Precise meanings: R (Recency) = days since last gift from this appeal as of Aug 31 2025 cutoff — {best.get("recency_days_24mo","N/A")} days; score 5 = most recent, score 1 = oldest. F (Frequency) = total transaction count in 24mo window (one donor giving 3× = 3); score 5 = most transactions for this cluster. M (Monetary) = total dollars raised in 24mo window; score 5 = highest revenue for this cluster. These are APPEAL-LEVEL performance signals only — not donor demographics. Creative use: low R means this appeal format has aged and needs a freshened concept; high F means the format drove repeat giving so lean into loyalty/belonging tone; high M means the concept motivated larger gifts so use impact/legacy framing. NOTE: response_rate_pct is directional only — it divides 24mo transactions by lifetime targeted donors, so newer appeals may appear more responsive than older ones.
RESPONSE CONTEXT: Best appeal response rate = {response_rate:.2f}% | cluster average appeal response rate = {(f'{cluster_response_baseline:.2f}%' if cluster_response_baseline is not None else 'N/A')} | lift vs cluster average = {(f'{lift_pct:.1f}%' if lift_pct is not None else 'N/A')}
REVENUE CONTEXT (24mo window): Total dollars raised = ${best.get("total_gift_amount","N/A")} | Most recent gift date = {best.get("most_recent_gift_date","N/A")} | Unique donors who gave = {best.get("donors_responded_24mo","N/A")}

KNOWLEDGE BASE - APPEAL CREATIVE REFERENCE:
{appeal_creative}

KNOWLEDGE BASE - WORST PERFORMER CREATIVE (study these patterns to avoid them):
{worst_creative}

KNOWLEDGE BASE - APPEAL RULES:
{appeal_rules}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

Rules:
- Theme: Write a memorable campaign title on line 1 — this is the headline that will appear on the brief and potentially on the package itself. A subtitle after a colon is encouraged when it sharpens the concept (e.g. "Bright Futures Bloom: Nurturing Hope at Boys Town"). Then, on a new line, write 2-3 sentences explaining the emotional angle, how the concept connects to Boys Town's mission, and why it fits this specific cluster. This section should be immediately usable by a copywriter or creative director without additional context.
- Imagery: describe 2-3 specific visual motifs that will appear in the appeal package — what children are doing, what setting or environment surrounds them, what lighting and mood the photography conveys, and any illustrative or decorative elements on the letter or add-in. Be specific enough that a photographer or art director could brief from this description directly. Ground the imagery in this cluster's demographics and geographic profile. If a Creative Direction was specified, the imagery must incorporate recognizable visual elements from that direction. Children are always depicted with dignity — hopeful, forward-looking, never in distress.
- Color Palette: if a Creative Direction was specified, choose colors that best serve that theme and audience — do NOT default to Boys Town blue and gold unless they genuinely fit the concept. If no Creative Direction was given, use Boys Town brand colors as the foundation. Establish the palette before selecting the add-in so that the add-in design can reference the campaign colors.
- Premium Add-In: Select the add-in by working through this priority order: (1) best qualified historical add-in test for this cluster, if available; (2) best-performer anchor from the appeal creative reference; (3) knowledge-base rules and psychographic fit. Only claim lift vs baseline when a real no-add-in baseline row exists. If no add-in row met the confidence threshold, say the choice is directional rather than historically proven.
- Envelope Teaser Options: write exactly 3 distinct teaser copy options for the outer envelope. Label them: **Curiosity-Led**, **Emotion-Led**, and **Benefit-Led**. Each is one line of copy only.
- Letter Opening: write a 3-4 sentence directional draft of the donor letter opening paragraph. First person voice, warm and personal. Lead with a specific child story or moment tied to the appeal theme. This is a directional draft, not final copy — label it clearly as such.
- Call to Action: use ONLY **${low}**, **${mid}**, and **${high}**. Keep those exact three amounts in ascending order. Each amount must have one concise thematic description line. Do not introduce any other ask amounts.
- Inspired By: Write exactly three labeled bullets. Historical Signal: Name the specific appeal(s) that drove the concept — include the appeal ID, name, and the key metric that justified it (response rate, average gift, ROI, or add-in performance). Explain what specific element was borrowed (theme, add-in type, imagery, timing). When referencing appeal RFM scores (R, F, M), these are appeal-level performance scores benchmarked within this cluster only — use them to explain why that appeal was chosen, not to describe donor quality. Directional Only: Identify any psychographic indexes, demographic signals, or data patterns that influenced creative decisions but are not verified performance signals. Any index cited must be 1.2 or above — do not cite 1.0 as directional support. If the cluster composite RFM score informed a statement about overall cluster health or donor quality, cite it here with the actual score. Fallback from General Rules: Identify any elements that defaulted to knowledge-base rules or general best practices because no cluster-specific data was available (e.g. gift ladder amounts, mail window, add-in selection).
- Target Cluster Summary: write 5-7 sentences. Include: (1) the age range, income level, and household composition of the cluster; (2) the dominant geography feel — urbanicity character (rural, suburban, urban, or mixed) with the largest urbanicity share called out, plus the top state or states when state concentration is geographically meaningful; (3) the top 2 psychographic indexes most relevant to the creative concept with their actual index values; (4) peak giving month and recommended mail drop window; (5) lapse risk level and what it implies for creative tone; (6) the single strongest creative implication that ties all of these signals together into the concept. Write interpretively in full sentences — do not use bullet points or restate raw numbers without context.
- Rationale: You MUST write exactly two paragraphs separated by a blank line. A single paragraph is incorrect and incomplete. Paragraph 1: explain why the creative concept fits this cluster — reference the specific psychographic signals, RFM context, or appeal history that drove the theme and add-in choice. If a Creative Direction was specified, state that it drove the concept and identify what data factors supported or complicated it. If a psychographic index was cited, it must be 1.2 or above — do not cite neutral 1.0 signals as support. Paragraph 2: explain the strategic decisions — what you rotated away from, how mail date or last package influenced the approach, and any cost or performance guardrails applied (e.g. underperforming cluster add-in restriction, directional vs. verified data).
- Testing Notes: write exactly 3 A/B test hypotheses. Format each as: **Variable** | Control: [what you would keep] vs. Test: [what you would change] | Expected outcome: [specific directional prediction]. Keep each hypothesis to one sentence.
- Appeal Package Image Prompt: Write a single detailed prompt for a flat-lay blueprint image of ALL mail components. Follow every instruction below precisely.
{IMAGE_PROMPT_STEPS}
"""

    ensure_vertex_ai()
    model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
    response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
    response_text = enforce_ask_ladder_consistency(response.text, low, mid, high)
    response_text = enforce_output_integrity(response_text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=addin_info.get("has_real_baseline", False))

    donor_count = int(best.get("cluster_donor_count") or 0)
    best_roi = roi_rows[0] if roi_rows else None
    cost_per_piece = _safe_float(best.get("COST"))
    total_mail_cost = round(cost_per_piece * donor_count, 2) if cost_per_piece is not None and donor_count else None
    economics_pieces = economics.get("pieces_mailed") if economics and economics.get("has_usable_costs") else None
    economics_cpp = economics.get("cost_per_piece") if economics and economics.get("has_usable_costs") else None
    economics_total_cost = economics.get("total_mail_cost") if economics and economics.get("has_usable_costs") else None
    real_net_return = _safe_float(best_roi.get("net_return")) if best_roi else None
    real_roi_pct = _safe_float(best_roi.get("roi_pct")) if best_roi else None
    real_pieces = _safe_int(best_roi.get("pieces_mailed")) if best_roi else None
    real_revenue = _safe_float(best_roi.get("total_revenue")) if best_roi else None
    real_cost = _safe_float(best_roi.get("total_mail_cost")) if best_roi else None

    top_psych = psych_ranked[0][0] if psych_ranked and psych_ranked[0][1] > 0 else None
    top_psych_idx = psych_ranked[0][1] if psych_ranked and psych_ranked[0][1] > 0 else None

    meta = {
        "cluster": cluster_name,
        "theme": custom_theme,
        "mail_date": mail_date,
        "last_package": last_package,
        "best_appeal": best["APPEAL_NAME"],
        "best_score": best["rfm_composite_score"],
        "avg_gift": avg,
        "response_rate_pct": response_rate,
        "response_rate_baseline_pct": round(cluster_response_baseline, 2) if cluster_response_baseline is not None else None,
        "lift_pct": lift_pct,
        "low": low, "mid": mid, "high": high,
        "ladder_source": ladder_source,
        "distribution_confidence": gift_dist.get("distribution_confidence") if gift_dist else None,
        "has_gift_distribution": bool(gift_dist),
        "worst_appeal": worst["APPEAL_NAME"],
        "worst_score": worst["rfm_composite_score"],
        "total_appeals": len(rows),
        "rule_555": rule_555,
        "underperforming": underperforming,
        "cluster_donor_count": donor_count,
        "anticipated_revenue": round(donor_count * (response_rate / 100) * avg, 2),
        "donors_responded_24mo": int(best.get("donors_responded_24mo") or 0),
        "cost_per_piece": cost_per_piece,
        "total_mail_cost": total_mail_cost,
        "real_net_return": real_net_return,
        "real_roi_pct": real_roi_pct,
        "real_pieces": real_pieces,
        "real_revenue": real_revenue,
        "real_cost": real_cost,
        "has_real_roi": bool(roi_rows),
        "has_economics": bool(economics),
        "economics_pieces": economics_pieces,
        "economics_cost_per_piece": economics_cpp,
        "economics_total_mail_cost": economics_total_cost,
        "gift_timing": gift_timing,
        "acquisition": acquisition,
        "appeal_r": int(best.get("r_score") or 0),
        "appeal_f": int(best.get("f_score") or 0),
        "appeal_m": int(best.get("m_score") or 0),
        "lapse_prob": lapse_prob,
        "lapse_label": lapse_label,
        "pct_predicted_lapse": pct_predicted_lapse,
        "upgrade_prob": upgrade_prob,
        "upgrade_label": upgrade_label,
        "cluster_upgrade_rate_pct": cluster_upgrade_rate_pct,
        "income": best.get("EstimatedHHIncomeAvg", "N/A"),
        "net_worth": best.get("EstimatedNetWorth", "N/A"),
        "urbanicity_rural": pct_number(best.get("UrbanicityRural")),
        "urbanicity_suburban": pct_number(best.get("UrbanicitySuburbsandTowns")),
        "urbanicity_urban": pct_number(best.get("UrbanicityCitiesandSurrounds")),
        "urbanicity_metro": pct_number(best.get("UrbanicityDowntownMetro")),
        "mail_responsiveness_idx": round(float(psych.get("idx_mail_responder") or 0), 2) if psych.get("idx_mail_responder") is not None else None,
        "top_psychographic": top_psych,
        "top_psychographic_idx": round(top_psych_idx, 2) if top_psych_idx is not None else None,
        "second_psychographic": psych_ranked[1][0] if len(psych_ranked) > 1 and psych_ranked[1][1] > 0 else None,
        "second_psychographic_idx": round(psych_ranked[1][1], 2) if len(psych_ranked) > 1 and psych_ranked[1][1] > 0 else None,
        "third_psychographic": psych_ranked[2][0] if len(psych_ranked) > 2 and psych_ranked[2][1] > 0 else None,
        "third_psychographic_idx": round(psych_ranked[2][1], 2) if len(psych_ranked) > 2 and psych_ranked[2][1] > 0 else None,
        "addin_override": addin_override,
        "imagery_override": imagery_override,
        "teaser_override": teaser_override,
        "envelope_format": envelope_format,
        "ladder_low": ladder_low,
        "ladder_mid": ladder_mid,
        "ladder_high": ladder_high,
        "ladder_override": bool(ladder_low or ladder_mid or ladder_high),
        "has_timing": bool(gift_timing),
        "has_geography": bool(geo_rows),
        "geo_top_state": (geo_rows[0].get("State_Abbr") if geo_rows else None),
        "geo_top_state_pct": (round(float(geo_rows[0].get("pct_of_cluster_donors") or 0), 2) if geo_rows else None),
        "geo_top3_concentration": round(sum(float(r.get("pct_of_cluster_donors") or 0) for r in (geo_rows[:3] if geo_rows else [])), 2),
        "has_psychographics": bool(psych),
        "has_roi": bool(roi_rows),
        "has_cohorts": bool(acquisition and not acquisition.get("insufficient_rows")),
        "has_rfm": True,
        "data_warnings": data_warnings,
        "addin_confidence_qualified": addin_info.get("qualified_count", 0) > 0,
        "addin_has_real_baseline": addin_info.get("has_real_baseline", False),
    }
    return response_text, meta, None


def refine(previous_output, instruction, meta):
    """Re-generate an appeal with a targeted refinement, preserving the original data context."""
    ensure_vertex_ai()

    low = meta.get('low', 25)
    mid = meta.get('mid', 50)
    high = meta.get('high', 100)
    cluster = meta.get('cluster', 'Unknown')
    theme = meta.get('theme', '')
    addin_override = meta.get('addin_override', '')
    imagery_override = meta.get('imagery_override', '')
    has_real_baseline = meta.get('addin_has_real_baseline', False)

    context_lines = [f"Cluster: {cluster}"]
    if theme:
        context_lines.append(f"Creative Direction: {theme}")
    if meta.get('mail_date'):
        context_lines.append(f"Mail Date: {meta['mail_date']}")
    if meta.get('last_package'):
        context_lines.append(f"Last Package: {meta['last_package']}")
    context_block = "\n".join(context_lines)

    prompt = f"""You previously generated the following Boys Town direct mail appeal concept:

--- PREVIOUS OUTPUT START ---
{previous_output}
--- PREVIOUS OUTPUT END ---

ORIGINAL CONTEXT:
{context_block}
Gift Ladder: ${low} / ${mid} / ${high} — do not change these amounts unless the refinement explicitly asks for it.

THE USER HAS REQUESTED THIS REFINEMENT:
"{instruction}"

Regenerate the FULL appeal incorporating this change. Keep everything else intact unless the change logically requires adjustments to other sections (e.g. changing the add-in should update the image prompt to match). Use EXACTLY these section headings in this order:

## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

The Appeal Package Image Prompt must reflect any changes made to the appeal sections above. Follow the same image prompt construction steps used in the original.

{IMAGE_PROMPT_STEPS}
"""

    model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
    try:
        response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
        text = enforce_ask_ladder_consistency(response.text, low, mid, high)
        text = enforce_output_integrity(text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=has_real_baseline)
        return text, None
    except Exception as e:
        print(f"REFINE_ERROR: {e}", flush=True)
        return None, str(e)

# ── HTML frontend ──────────────────────────────────────────────────────────────
HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Boys Town Appeal Generator</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Source+Sans+3:wght@300;400;600&display=swap" rel="stylesheet">
<style>
:root{--nv:#0d1b2a;--nm:#162840;--nl:#1e3653;--gd:#f3a914;--gl:#f3a914;--cr:#f5f0e8;--wh:#ffffff;--tx:#1a1a2e;--mu:#7a8899;--border:rgba(243,169,20,.22)}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Source Sans 3',sans-serif;background:var(--nv);color:var(--wh);min-height:100vh;font-size:16.5px;line-height:1.55}

/* ── Header ── */
header{background:linear-gradient(135deg,#0a1520,var(--nm));border-bottom:1px solid var(--border);padding:1.5rem 2.5rem;display:flex;align-items:center;gap:1.25rem}
.lb{width:44px;height:44px;background:var(--gd);border-radius:10px;display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-weight:900;font-size:1.1rem;color:#0a1520;flex-shrink:0;letter-spacing:-.02em}
header h1{font-family:'Playfair Display',serif;font-size:1.35rem;font-weight:700;color:var(--wh);letter-spacing:-.01em}
header p{font-size:.72rem;color:rgba(243,169,20,.7);margin-top:.15rem;font-weight:400;letter-spacing:.12em;text-transform:uppercase}

/* ── Tabs ── */
.tab-nav{display:flex;padding:0 2.5rem;background:var(--nm);border-bottom:1px solid var(--border)}
.tab-btn{padding:.82rem 1.3rem;background:none;border:none;border-bottom:2px solid transparent;color:var(--mu);font-family:'Source Sans 3',sans-serif;font-size:.76rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;cursor:pointer;transition:color .2s,border-color .2s;margin-bottom:-1px}
.tab-btn:hover{color:var(--wh)}
.tab-btn.active{color:var(--gd);border-bottom-color:var(--gd)}
.tab-pane{display:none}.tab-pane.active{display:block}

/* ── Main layout ── */
.main{max-width:1120px;margin:0 auto;padding:2rem 2rem 4rem}

/* ── Cluster selector ── */
.cluster-row{margin-bottom:0}
.cluster-lbl{font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--gd);margin-bottom:.54rem;display:block}
.cluster-field{max-width:400px}

/* ── Customize bar ── */
.cbar{background:var(--nm);border:1px solid var(--border);border-top:none;border-radius:0 0 12px 12px;padding:1.35rem 1.6rem 1.5rem;margin-bottom:2rem}
.cbar-note{font-size:.78rem;line-height:1.45;color:rgba(222,231,241,.82);margin:0 0 .95rem}
.cbar-row{display:flex;gap:1rem;align-items:flex-end;flex-wrap:wrap}
.cbar-row+.cbar-row{margin-top:1.1rem;padding-top:1.1rem;border-top:1px solid rgba(255,255,255,.06)}
.cbar-clusters{align-items:stretch}
.cbar-adv{margin-top:1.12rem;border:1px solid rgba(255,255,255,.08);border-radius:12px;background:rgba(255,255,255,.02);overflow:hidden}
.cbar-adv summary{cursor:pointer;list-style:none;display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.92rem 1.15rem;color:#e8eef6;font-size:.76rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;background:rgba(255,255,255,.025);transition:background .2s,color .2s}
.cbar-adv summary::-webkit-details-marker{display:none}
.cbar-adv summary:hover{background:rgba(255,255,255,.04);color:#f2f6fb}
.cbar-adv summary::after{content:'+';color:var(--gd);font-size:1rem;font-weight:700;font-family:'Source Sans 3',sans-serif}
.cbar-adv[open] summary::after{content:'−'}
.cbar-adv-body{padding:1.15rem 1.15rem 1.3rem}
.adv-sec-lbl{font-size:.62rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:rgba(243,169,20,.58);margin-bottom:.6rem}
.adv-sec-lbl em{font-style:normal;font-weight:400;letter-spacing:.04em;color:rgba(207,220,234,.38);text-transform:none;font-size:.6rem}
.adv-divider{height:1px;background:rgba(255,255,255,.06);margin:.85rem 0}
.adv-pkg-grid{display:grid;grid-template-columns:minmax(140px,170px) minmax(110px,130px) 72px 1fr;gap:.9rem .8rem;align-items:end}
.adv-bottom-row{display:flex;gap:2.2rem;align-items:flex-start}
.adv-divider-v{width:1px;background:rgba(255,255,255,.07);align-self:stretch;margin:0}
.adv-color-row{display:flex;gap:.44rem;align-items:flex-end}
.adv-cswatch{display:flex;flex-direction:column;gap:.28rem;align-items:center}
.adv-cswatch-lbl{font-size:.62rem;color:rgba(207,220,234,.45);letter-spacing:.06em;text-transform:uppercase}
.cf{display:flex;flex-direction:column;gap:.46rem;min-width:0}
.cf-wide{flex:2.5;min-width:220px}
.cf-med{flex:1.5;min-width:170px}
.cf-sm{flex:0 0 auto}
.cl{font-size:.68rem;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:rgba(232,238,246,.84);white-space:nowrap}
.cl em{font-style:normal;font-weight:500;color:rgba(188,200,216,.78);font-size:.95em}
.ci{padding:.68rem .9rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:var(--wh);font-family:'Source Sans 3',sans-serif;font-size:.92rem;width:100%;transition:border-color .2s,background .2s}
.ci:focus{outline:none;border-color:rgba(243,169,20,.6);background:rgba(255,255,255,.06)}
.ci::placeholder{color:rgba(220,228,238,.38)}
.ci-sel{appearance:none;cursor:pointer}
.sw{position:relative}
.sw::after{content:'▾';position:absolute;right:.7rem;top:50%;transform:translateY(-50%);color:var(--gd);font-size:.7rem;pointer-events:none}

/* ── Color swatches ── */
.color-group{display:flex;gap:.44rem;align-items:flex-start}
.cs{display:flex;flex-direction:column;align-items:center;gap:.24rem}
.cs-pick{width:36px;height:32px;border:1px solid rgba(255,255,255,.15);border-radius:6px;cursor:pointer;padding:0;background:none;overflow:hidden;flex-shrink:0;transition:border-color .2s}
.cs-pick:hover{border-color:var(--gd)}
.cs-pick input[type=color]{width:150%;height:150%;margin:-25% -25%;cursor:pointer;border:none;padding:0}
.cs-hex{width:62px;padding:.28rem .3rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:5px;color:rgba(236,242,248,.78);font-family:'Source Sans 3',sans-serif;font-size:.67rem;text-align:center;transition:border-color .2s,color .2s}
.cs-hex:focus{outline:none;border-color:rgba(243,169,20,.5);color:var(--wh)}
.cs-reset{background:none;border:1px solid rgba(255,255,255,.12);border-radius:6px;color:rgba(226,234,242,.58);cursor:pointer;font-size:.9rem;width:28px;height:32px;display:flex;align-items:center;justify-content:center;transition:all .2s;flex-shrink:0;align-self:flex-start;margin-left:.08rem}
.cs-reset:hover{border-color:var(--gd);color:var(--gd)}

/* ── Ladder inputs ── */
.ladder{display:flex;gap:.4rem}
.ladder input{width:60px;padding:.66rem .42rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:var(--wh);font-family:'Source Sans 3',sans-serif;font-size:.92rem;text-align:center;transition:border-color .2s}
.ladder input:focus{outline:none;border-color:rgba(243,169,20,.6)}
.ladder input::placeholder{color:rgba(224,231,239,.38);font-size:.78rem}

/* ── Mode toggles + Generate ── */
.cbar-actions{display:flex;gap:.5rem;align-items:center;justify-content:flex-start;flex-wrap:wrap}
.cbar-actions-spacer{flex:1 1 auto}
.cbar-actions-secondary{display:flex;gap:.5rem;align-items:center;flex-wrap:wrap}
.tog{padding:.68rem 1.05rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.12);border-radius:8px;color:rgba(233,239,246,.72);font-family:'Source Sans 3',sans-serif;font-size:.76rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;transition:all .2s;white-space:nowrap}
.tog:hover{background:rgba(255,255,255,.08);color:#f4f7fb;border-color:rgba(255,255,255,.22)}
.tog.on{background:rgba(243,169,20,.15);color:var(--gd);border-color:rgba(243,169,20,.4)}
.tog.on-red{background:rgba(239,68,68,.12);color:#f87171;border-color:rgba(239,68,68,.35)}
.genbtn{padding:.72rem 1.7rem;background:var(--gd);color:#0a1520;border:none;border-radius:8px;font-family:'Source Sans 3',sans-serif;font-size:.92rem;font-weight:700;cursor:pointer;letter-spacing:.04em;text-transform:uppercase;transition:all .2s;white-space:nowrap;flex-shrink:0}
.genbtn:hover{background:#ffbe40;transform:translateY(-1px);box-shadow:0 4px 16px rgba(243,169,20,.3)}
.genbtn:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none}

/* ── Cluster dropdown ── */
.dd-wrap{position:relative;width:100%}
.dd-btn{width:100%;padding:.92rem 1.05rem;background:rgba(255,255,255,.04);border:1px solid rgba(243,169,20,.35);border-top:1px solid rgba(243,169,20,.35);border-radius:12px 12px 0 0;color:var(--wh);font-family:'Source Sans 3',sans-serif;font-size:.98rem;cursor:pointer;display:flex;align-items:center;gap:.65rem;user-select:none;transition:border-color .2s}
.dd-btn:hover,.dd-btn.open{border-color:rgba(243,169,20,.7);background:rgba(255,255,255,.06)}
.dd-btn.open{border-radius:12px 12px 0 0}
.dd-label{flex:1;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}
.dd-arrow{font-size:.65rem;color:var(--gd);flex-shrink:0;transition:transform .2s}
.dd-btn.open .dd-arrow{transform:rotate(180deg)}
.dd-list{display:none;position:absolute;top:calc(100% + 2px);left:0;right:0;background:var(--nl);border:1px solid rgba(243,169,20,.45);border-radius:10px;max-height:300px;overflow-y:auto;z-index:999;box-shadow:0 12px 40px rgba(0,0,0,.6)}
.dd-sort{display:flex;margin:8px 8px 4px;border:1px solid rgba(243,169,20,.25);border-radius:6px;overflow:hidden}
.dd-sort-btn{flex:1;padding:.36rem .56rem;font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;border:none;background:transparent;color:var(--mu);transition:background .15s,color .15s}
.dd-sort-btn.active{background:var(--gd);color:#0a1520}
.dd-sort-btn:hover:not(.active){background:rgba(243,169,20,.1);color:var(--wh)}
.dd-list.open{display:block}
.dd-search{padding:.62rem .86rem;border-bottom:1px solid rgba(255,255,255,.06)}
.dd-search input{width:100%;padding:.48rem .76rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:5px;color:var(--wh);font-family:'Source Sans 3',sans-serif;font-size:.87rem}
.dd-search input:focus{outline:none;border-color:rgba(243,169,20,.4)}
.dd-search input::placeholder{color:rgba(255,255,255,.25)}
.dd-item{display:flex;align-items:center;gap:.74rem;padding:.66rem 1rem;cursor:pointer;transition:background .12s}
.dd-item:hover{background:rgba(243,169,20,.1)}
.dd-item.selected{background:rgba(243,169,20,.15)}
.dd-item-name{flex:1;font-size:.92rem;color:var(--wh)}
.dd-item-stars{font-size:.82rem;flex-shrink:0;color:var(--mu);white-space:nowrap}
.dd-special{border-bottom:1px solid rgba(255,255,255,.06);padding-bottom:6px!important;margin-bottom:2px}
.dd-special .dd-item-name{color:rgba(243,169,20,.8)!important;font-style:italic}
.dd-filters{display:flex;gap:.4rem;flex-wrap:wrap;padding:.5rem .8rem;border-bottom:1px solid rgba(255,255,255,.06)}
.dd-pill{padding:.32rem .6rem;border-radius:999px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:#b5c1cf;font-size:.67rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;transition:all .15s}
.dd-pill:hover{color:var(--wh);border-color:rgba(243,169,20,.3)}
.dd-pill.active{background:rgba(243,169,20,.13);border-color:rgba(243,169,20,.35);color:var(--gd)}
.dd-item-meta{display:flex;align-items:center;gap:.35rem;flex-wrap:wrap;justify-content:flex-end}
.dd-tag{padding:.14rem .42rem;border-radius:999px;font-size:.58rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border:1px solid rgba(255,255,255,.08);color:#9fb0c3;background:rgba(255,255,255,.04)}
.dd-tag.warn{color:#fda4af;border-color:rgba(248,113,113,.25);background:rgba(239,68,68,.09)}
.dd-tag.good{color:#86efac;border-color:rgba(110,231,183,.25);background:rgba(110,231,183,.08)}
.dd-tag.info{color:#7dd3fc;border-color:rgba(125,211,252,.25);background:rgba(125,211,252,.08)}

/* ── Loading ── */
.ld{display:none;text-align:center;padding:3rem;color:var(--gd)}
.ld.on{display:block}
.sp{width:44px;height:44px;border:2px solid rgba(243,169,20,.15);border-top-color:var(--gd);border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 1rem}
@keyframes spin{to{transform:rotate(360deg)}}
.ld p{font-size:.96rem;color:var(--gd);font-weight:600;margin-bottom:.3rem}
.ld .st{font-size:.78rem;color:var(--mu);margin-top:.3rem;min-height:1.2em;transition:opacity .3s}
.ld-bar-wrap{width:260px;height:4px;background:rgba(243,169,20,.12);border-radius:2px;margin:.9rem auto 0;overflow:hidden}
.ld-bar{height:100%;width:0%;background:var(--gd);border-radius:2px;transition:width .6s ease}
@keyframes genbtnpulse{0%,100%{opacity:1}50%{opacity:.65}}
.genbtn.generating{animation:genbtnpulse 1.4s ease-in-out infinite;cursor:not-allowed}
.rs{display:none}.rs.on{display:block}

/* ── Results layout ── */
.result-tabs{display:flex;gap:.55rem;margin-bottom:1rem}
.result-tab{padding:.68rem 1.05rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:9px;color:var(--mu);font-family:'Source Sans 3',sans-serif;font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;transition:all .2s}
.result-tab:hover{color:var(--wh);border-color:rgba(243,169,20,.35)}
.result-tab.active{background:rgba(243,169,20,.14);border-color:rgba(243,169,20,.4);color:var(--gd)}
.result-pane{display:none}
.result-pane.active{display:block}

/* ── Summary band ── */
.ms{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem;margin-bottom:1rem}
.ms-col{background:var(--nl);border:1px solid var(--border);border-radius:14px;padding:1.28rem 1.32rem;min-width:0}
.ms-title{font-size:.69rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--gd);margin-bottom:.92rem}
.ms-cluster{font-family:'Playfair Display',serif;font-size:1.08rem;color:var(--wh);font-weight:700;line-height:1.2;margin-bottom:.25rem}
.ms-sub{font-size:.78rem;color:var(--mu);margin-bottom:.76rem;line-height:1.45}
.ms-badges{display:flex;gap:.4rem;flex-wrap:wrap;margin:.65rem 0 .2rem}
.ms-row{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.62rem;gap:.82rem}
.ms-row:last-child{margin-bottom:0}
.ms-key{font-size:.7rem;color:#7f8da0;text-transform:uppercase;letter-spacing:.07em;white-space:nowrap}
.ms-val{font-size:.95rem;color:var(--wh);font-weight:600;text-align:right;line-height:1.32}
.ms-val.hi{color:var(--gl);font-size:1rem}
.ms-val.ldr{font-size:1.06rem;color:var(--gl);font-weight:700;letter-spacing:.02em}
.ms-val.pos{color:#6ee7b7}.ms-val.neg{color:#f87171}
.ms-val.cd{color:#a8d4b8;font-style:italic;font-size:.84rem;text-align:right;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ms-val.sm{font-size:.83rem;color:#90a1b5;font-weight:400}

/* ── Metadata tooltips ── */
.ms-key{position:relative;cursor:default}
.ms-key.tip{border-bottom:1px dotted rgba(127,141,160,.45)}
.ms-key.tip::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 7px);left:0;width:220px;background:#0d1b2a;border:1px solid rgba(243,169,20,.28);color:#c8d6e5;font-size:.72rem;font-weight:400;letter-spacing:.01em;text-transform:none;line-height:1.5;padding:.55rem .7rem;border-radius:7px;white-space:normal;pointer-events:none;opacity:0;transition:opacity .15s;z-index:999;box-shadow:0 4px 18px rgba(0,0,0,.45)}
.ms-key.tip:hover::after{opacity:1}
.bg{display:inline-block;padding:.18rem .55rem;border-radius:999px;font-size:.63rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase}
.bg-g{background:rgba(243,169,20,.15);color:var(--gd);border:1px solid rgba(243,169,20,.35)}
.bg-r{background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.3)}
.bg-t{background:rgba(110,231,183,.1);color:#6ee7b7;border:1px solid rgba(110,231,183,.25)}
.bg-m{background:rgba(196,181,253,.12);color:#c4b5fd;border:1px solid rgba(196,181,253,.25)}

/* ── Recommendation + provenance ── */
.why-box,.prov-strip{background:var(--nl);border:1px solid var(--border);border-radius:14px;padding:1.08rem 1.22rem;margin-bottom:1rem}
.why-title,.prov-title{font-size:.69rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--gd);margin-bottom:.76rem}
.why-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.64rem 1.06rem;list-style:none;padding:0;margin:0}
.why-list li{font-size:.93rem;color:#e6edf5;line-height:1.5;display:flex;gap:.54rem}
.why-list li::before{content:'•';color:var(--gd);font-weight:700}
.prov-chips{display:flex;flex-wrap:wrap;gap:.56rem}
.prov-chip{padding:.36rem .7rem;border-radius:999px;font-size:.71rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;border:1px solid rgba(255,255,255,.1);color:#708196;background:rgba(255,255,255,.04)}
.prov-chip.on{background:rgba(243,169,20,.12);border-color:rgba(243,169,20,.3);color:var(--gd)}

/* ── Appeal output ── */
.ao{background:var(--cr);color:var(--tx);border-radius:14px;padding:1.48rem 1.48rem 1.2rem;line-height:1.78}
.refine-bar{display:none;background:var(--nm);border:1px solid var(--border);border-radius:12px;padding:1rem 1.2rem;margin-bottom:1rem}
.refine-bar.on{display:flex;gap:.75rem;align-items:flex-end}
.refine-bar .cf{flex:1}
.refine-bar .ci{font-size:.88rem;padding:.62rem .8rem}
.refine-bar .refine-btn{align-self:flex-start;margin-top:1.42rem;padding:.62rem 1.3rem;background:var(--gd);color:#0a1520;border:none;border-radius:8px;font-family:'Source Sans 3',sans-serif;font-size:.82rem;font-weight:700;cursor:pointer;letter-spacing:.04em;text-transform:uppercase;transition:all .2s;white-space:nowrap;flex-shrink:0}
.refine-bar .refine-btn:hover{background:#ffbe40}
.refine-bar .refine-btn:disabled{opacity:.4;cursor:not-allowed}
.refine-bar .refine-hint{font-size:.7rem;color:var(--mu);margin-top:.3rem}
.ao-acc{border:1px solid #e6dccd;border-radius:12px;background:#fcfaf6;margin-bottom:.9rem;overflow:hidden}
.ao-acc summary{cursor:pointer;list-style:none;padding:1.08rem 1.22rem;font-weight:700;color:#1f2937;display:flex;align-items:center;justify-content:space-between;font-family:'Playfair Display',serif;font-size:1.08rem}
.ao-acc summary::-webkit-details-marker{display:none}
.ao-acc summary::after{content:'+';color:#8a6a2f;font-size:1.08rem;font-family:'Source Sans 3',sans-serif}
.ao-acc[open] summary::after{content:'−'}
.ao-acc-body{padding:0 1.22rem 1.08rem}
.ao-block+.ao-block{margin-top:1.22rem;padding-top:1.08rem;border-top:1px solid #eadfce}
.ao h3{font-family:'Playfair Display',serif;font-size:1.08rem;color:#1a1a2e;margin:0 0 .5rem}
.ao p{margin-bottom:.78rem;color:#2d3748;font-size:.98rem;line-height:1.72}.ao p+p{margin-top:.78rem}
.ao ul{padding-left:1.38rem;margin-bottom:.98rem}
.ao li{margin-bottom:.4rem;color:#2d3748;font-size:.97rem;line-height:1.68}
.ao strong{color:#0f172a}
.ao-muted-note{font-size:.82rem;color:#7c6f60;margin-bottom:.68rem;line-height:1.5}
.pw{background:var(--nm);border:1px solid var(--border);border-radius:14px;padding:1.8rem 2rem;display:none}
.pw h3{font-family:'Playfair Display',serif;font-size:1rem;color:var(--gl);margin-bottom:.35rem;padding-bottom:.35rem;border-bottom:1px solid var(--border)}
.wf{font-size:.79rem;color:var(--mu);margin-bottom:1.2rem;font-style:italic;line-height:1.5}
.pb{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:1.1rem 1.3rem;margin-bottom:.9rem;position:relative}
.pb.m{border-color:rgba(243,169,20,.4);margin-bottom:1.1rem}
.pb.b{border-color:rgba(110,231,183,.25)}
.pl{font-size:.69rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--gd);margin-bottom:.6rem;display:block}
.pl.ml{color:var(--gl)}
.pl.bl{color:#6ee7b7}
.pt{font-family:'Source Sans 3',sans-serif;font-size:.9rem;color:#c4b8a0;line-height:1.72;padding-right:5rem}
.cb{position:absolute;top:.85rem;right:.85rem;padding:.32rem .84rem;background:var(--gd);color:#0a1520;border:none;border-radius:5px;font-size:.72rem;font-weight:700;cursor:pointer;letter-spacing:.05em;text-transform:uppercase;transition:background .2s}
.cb:hover{background:#ffbe40}
.cb.ok{background:#2d6a4f;color:#fff}
.ab{display:flex;gap:.75rem;margin-top:1.4rem;justify-content:flex-end}
.bo{padding:.66rem 1.36rem;background:transparent;color:var(--gd);border:1px solid rgba(243,169,20,.4);border-radius:8px;font-family:'Source Sans 3',sans-serif;font-size:.88rem;font-weight:600;cursor:pointer;transition:all .2s}
.bo:hover{background:rgba(243,169,20,.08);border-color:var(--gd)}
.btn2{padding:.66rem 1.46rem;background:var(--gd);color:#0a1520;border:none;border-radius:8px;font-family:'Source Sans 3',sans-serif;font-size:.88rem;font-weight:700;cursor:pointer;letter-spacing:.04em;text-transform:uppercase;transition:all .2s}
.btn2:hover{background:#ffbe40}
.er{display:none;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:1rem 1.3rem;color:#f87171;margin-bottom:1.2rem;font-size:.88rem}
.er.on{display:block}

/* ── Data Sources tab ── */
.ds-wrap{max-width:1000px;margin:2rem auto;padding:0 2rem}
.ds-wrap h2{font-family:'Playfair Display',serif;font-size:1.3rem;color:var(--gl);margin-bottom:.3rem}
.ds-wrap .ds-sub{font-size:.8rem;color:var(--mu);margin-bottom:1.8rem}
.ds-table{width:100%;border-collapse:collapse;font-size:.8rem}
.ds-table th{text-align:left;padding:.55rem 1rem;font-size:.63rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--gd);border-bottom:1px solid var(--border)}
.ds-table td{padding:.72rem 1rem;border-bottom:1px solid rgba(255,255,255,.04);color:#b0bec5;vertical-align:top;line-height:1.5}
.ds-table tr:last-child td{border-bottom:none}
.ds-table td:first-child{color:var(--wh);font-weight:600;width:240px}
.ds-table td:nth-child(2){color:var(--mu);width:110px}
.ds-badge{display:inline-block;padding:.12rem .45rem;border-radius:4px;font-size:.6rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.ds-badge.live{background:rgba(110,231,183,.12);color:#6ee7b7;border:1px solid rgba(110,231,183,.25)}
.ds-badge.model{background:rgba(243,169,20,.12);color:var(--gd);border:1px solid rgba(243,169,20,.25)}
.ds-badge.derived{background:rgba(148,163,184,.1);color:#94a3b8;border:1px solid rgba(148,163,184,.2)}
.ds-badge.local{background:rgba(180,83,9,.12);color:#fdba74;border:1px solid rgba(180,83,9,.25)}
.ds-badge.rules{background:rgba(59,130,246,.12);color:#93c5fd;border:1px solid rgba(59,130,246,.25)}

@media(max-width:1100px){.adv-pkg-grid{grid-template-columns:minmax(140px,1fr) minmax(110px,1fr) 72px}.adv-pkg-grid .cf:last-child{grid-column:1 / -1}}
@media(max-width:980px){.ms{grid-template-columns:1fr}.why-list{grid-template-columns:1fr}.cluster-field{max-width:none}.cbar-row{align-items:stretch}.adv-pkg-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.adv-bottom-row{flex-direction:column;gap:1.2rem}.adv-divider-v{display:none}.cbar-actions{justify-content:space-between}}
@media(max-width:760px){.main{padding:1.25rem 1rem 3rem}.result-tabs{flex-wrap:wrap}.cbar-row{flex-direction:column}.adv-pkg-grid{grid-template-columns:1fr}.cbar-adv summary{align-items:flex-start}.cbar-actions,.cbar-actions-secondary{width:100%}.cbar-actions{justify-content:flex-start}.genbtn{width:100%}}

/* ═══════════════════════════════════════════════════════════════
   PRESENTATION MODE — high-contrast light theme for projectors
   Toggle via body.presentation-mode class. Dark mode unchanged.
   ═══════════════════════════════════════════════════════════════ */
.pm-toggle{display:flex;align-items:center;gap:.52rem;padding:.44rem 1rem;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.18);border-radius:6px;color:rgba(220,228,238,.78);font-family:'Source Sans 3',sans-serif;font-size:.72rem;font-weight:700;letter-spacing:.09em;text-transform:uppercase;cursor:pointer;transition:all .2s;white-space:nowrap}
.pm-toggle:hover{background:rgba(255,255,255,.13);color:#fff;border-color:rgba(255,255,255,.35)}
.pm-toggle .pm-icon{font-size:.9rem;line-height:1}
.pm-toggle .pm-dot{width:28px;height:16px;border-radius:8px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.22);position:relative;transition:background .25s,border-color .25s;flex-shrink:0}
.pm-toggle .pm-dot::after{content:'';position:absolute;top:2px;left:2px;width:10px;height:10px;border-radius:50%;background:#fff;opacity:.45;transition:left .2s,opacity .2s}
body.presentation-mode .pm-toggle{background:rgba(0,48,135,.12);border-color:rgba(0,48,135,.45);color:#003087}
body.presentation-mode .pm-toggle:hover{background:rgba(0,48,135,.2)}
body.presentation-mode .pm-toggle .pm-dot{background:#003087;border-color:#003087}
body.presentation-mode .pm-toggle .pm-dot::after{left:14px;opacity:1}
body.presentation-mode{background:#eef3f7;color:#16324f;font-size:17.5px}
body.presentation-mode header{background:#ffffff;border-bottom:2px solid #b8c7d6;box-shadow:0 2px 12px rgba(22,50,79,.1)}
body.presentation-mode header h1{color:#003087}
body.presentation-mode header p{color:#f3a914}
body.presentation-mode .lb{background:#f3a914;color:#003087}
body.presentation-mode .signout-link{color:#516579 !important;border-color:#b8c7d6 !important}
body.presentation-mode .signout-link:hover{color:#003087 !important;border-color:#003087 !important}
body.presentation-mode .tab-nav{background:#f5f8fb;border-bottom:2px solid #b8c7d6}
body.presentation-mode .tab-btn{color:#516579}
body.presentation-mode .tab-btn:hover{color:#003087}
body.presentation-mode .tab-btn.active{color:#003087;border-bottom-color:#003087}
body.presentation-mode .cbar{background:#ffffff;border:1px solid #b8c7d6;border-top:none}
body.presentation-mode .cbar-note{color:#516579}
body.presentation-mode .cbar-row+.cbar-row{border-top:1px solid #dce8f0}
body.presentation-mode .cbar-adv{border:1px solid #b8c7d6;background:#f5f8fb}
body.presentation-mode .cbar-adv summary{background:#eef3f7;color:#003087}
body.presentation-mode .cbar-adv summary:hover{background:#dce8f0;color:#003087}
body.presentation-mode .cbar-adv summary::after{color:#f3a914}
body.presentation-mode .adv-sec-lbl{color:#003087;opacity:.7}
body.presentation-mode .adv-divider{background:#dce8f0}
body.presentation-mode .cl{color:#003087}
body.presentation-mode .cl em{color:#516579}
body.presentation-mode .cluster-lbl{color:#003087}
body.presentation-mode .adv-cswatch-lbl{color:#516579}
body.presentation-mode label{color:#003087;font-weight:700;font-size:.74rem;letter-spacing:.1em;text-transform:uppercase}
body.presentation-mode .ci{background:#ffffff;border:1.5px solid #b8c7d6;color:#16324f}
body.presentation-mode .ci:focus{border-color:#003087;background:#ffffff;box-shadow:0 0 0 3px rgba(0,48,135,.1)}
body.presentation-mode .ci::placeholder{color:#a0b4c4}
body.presentation-mode .ladder input{background:#ffffff;border:1.5px solid #b8c7d6;color:#16324f}
body.presentation-mode .ladder input:focus{border-color:#003087}
body.presentation-mode .ladder input::placeholder{color:#a0b4c4}
body.presentation-mode .cs-pick{border:1.5px solid #b8c7d6}
body.presentation-mode .cs-hex{background:#ffffff;border:1px solid #b8c7d6;color:#16324f}
body.presentation-mode .cs-hex:focus{border-color:#003087;color:#003087}
body.presentation-mode .cs-reset{border-color:#b8c7d6;color:#516579}
body.presentation-mode .cs-reset:hover{border-color:#003087;color:#003087}
body.presentation-mode .tog{background:#ffffff;border:1.5px solid #b8c7d6;color:#516579}
body.presentation-mode .tog:hover{background:#f5f8fb;color:#003087;border-color:#003087}
body.presentation-mode .tog.on{background:rgba(243,169,20,.12);color:#b07a00;border-color:#f3a914}
body.presentation-mode .tog.on-red{background:rgba(185,28,28,.07);color:#b91c1c;border-color:rgba(185,28,28,.35)}
body.presentation-mode .dd-btn{background:#ffffff;border:1.5px solid #b8c7d6;color:#16324f}
body.presentation-mode .dd-btn:hover,body.presentation-mode .dd-btn.open{background:#f5f8fb;border-color:#003087}
body.presentation-mode .dd-arrow{color:#003087}
body.presentation-mode .dd-list{background:#ffffff;border:1.5px solid #b8c7d6;box-shadow:0 8px 32px rgba(22,50,79,.15)}
body.presentation-mode .dd-sort{border-color:#b8c7d6}
body.presentation-mode .dd-sort-btn{color:#516579}
body.presentation-mode .dd-sort-btn:hover:not(.active){background:rgba(0,48,135,.07);color:#003087}
body.presentation-mode .dd-sort-btn.active{background:#003087;color:#fff}
body.presentation-mode .dd-search{border-bottom:1px solid #dce8f0}
body.presentation-mode .dd-search input{background:#f5f8fb;border:1px solid #b8c7d6;color:#16324f}
body.presentation-mode .dd-search input::placeholder{color:#a0b4c4}
body.presentation-mode .dd-item-name{color:#16324f}
body.presentation-mode .dd-item:hover{background:rgba(0,48,135,.06)}
body.presentation-mode .dd-item.selected{background:rgba(0,48,135,.1)}
body.presentation-mode .dd-item-stars{color:#516579}
body.presentation-mode .dd-special{border-bottom:1px solid #dce8f0}
body.presentation-mode .dd-special .dd-item-name{color:#003087 !important}
body.presentation-mode .dd-filters{border-bottom:1px solid #dce8f0}
body.presentation-mode .dd-pill{border-color:#b8c7d6;background:#f5f8fb;color:#516579}
body.presentation-mode .dd-pill:hover{color:#003087;border-color:#7699bc}
body.presentation-mode .dd-pill.active{background:rgba(0,48,135,.1);border-color:rgba(0,48,135,.4);color:#003087}
body.presentation-mode .dd-tag{color:#516579;border-color:#c8d8e8;background:#eef3f7}
body.presentation-mode .dd-tag.warn{color:#b91c1c;border-color:rgba(185,28,28,.3);background:rgba(185,28,28,.06)}
body.presentation-mode .dd-tag.good{color:#166534;border-color:rgba(22,101,52,.3);background:rgba(22,101,52,.06)}
body.presentation-mode .dd-tag.info{color:#1d4ed8;border-color:rgba(29,78,216,.25);background:rgba(29,78,216,.06)}
body.presentation-mode .genbtn{background:#f3a914;color:#0a1520}
body.presentation-mode .genbtn:hover{background:#e09912}
body.presentation-mode .ld{color:#003087}
body.presentation-mode .sp{border-color:rgba(0,48,135,.15);border-top-color:#003087}
body.presentation-mode .ld p{color:#003087}
body.presentation-mode .ld .st{color:#516579}
body.presentation-mode .ld-bar-wrap{background:rgba(0,48,135,.1)}
body.presentation-mode .ld-bar{background:#003087}
body.presentation-mode .result-tab{background:#ffffff;border:1.5px solid #b8c7d6;color:#516579}
body.presentation-mode .result-tab:hover{color:#003087;border-color:#7699bc}
body.presentation-mode .result-tab.active{background:rgba(243,169,20,.12);border-color:#f3a914;color:#b07a00}
body.presentation-mode .ms-col{background:#ffffff;border:1.5px solid #b8c7d6;box-shadow:0 2px 10px rgba(22,50,79,.08)}
body.presentation-mode .ms-title{color:#003087;font-size:.73rem}
body.presentation-mode .ms-cluster{color:#003087}
body.presentation-mode .ms-sub{color:#516579}
body.presentation-mode .ms-key{color:#516579;font-size:.73rem}
body.presentation-mode .ms-val{color:#16324f;font-size:.97rem}
body.presentation-mode .ms-val.hi,body.presentation-mode .ms-val.ldr{color:#b07a00}
body.presentation-mode .ms-val.pos{color:#166534}
body.presentation-mode .ms-val.neg{color:#b91c1c}
body.presentation-mode .ms-val.cd{color:#2d6a4f}
body.presentation-mode .ms-val.sm{color:#516579}
body.presentation-mode .bg-g{background:rgba(243,169,20,.15);color:#b07a00;border-color:#f3a914}
body.presentation-mode .bg-r{background:rgba(185,28,28,.08);color:#b91c1c;border-color:rgba(185,28,28,.3)}
body.presentation-mode .bg-t{background:rgba(22,101,52,.08);color:#166534;border-color:rgba(22,101,52,.25)}
body.presentation-mode .bg-m{background:rgba(109,40,217,.08);color:#6d28d9;border-color:rgba(109,40,217,.22)}
body.presentation-mode .ms-key.tip{border-bottom:1px dotted #a0b4c4}
body.presentation-mode .ms-key.tip::after{background:#ffffff;border:1.5px solid #b8c7d6;color:#16324f;box-shadow:0 4px 18px rgba(22,50,79,.15)}
body.presentation-mode .why-box,body.presentation-mode .prov-strip{background:#ffffff;border:1.5px solid #b8c7d6;box-shadow:0 2px 10px rgba(22,50,79,.08)}
body.presentation-mode .why-title,body.presentation-mode .prov-title{color:#003087;font-size:.73rem}
body.presentation-mode .why-list li{color:#16324f}
body.presentation-mode .why-list li::before{color:#f3a914}
body.presentation-mode .prov-chip{border-color:#b8c7d6;color:#516579;background:#f5f8fb}
body.presentation-mode .prov-chip.on{background:rgba(0,48,135,.1);border-color:rgba(0,48,135,.4);color:#003087}
body.presentation-mode .ao{background:#f9f6ef;color:#16324f}
body.presentation-mode .refine-bar{background:#e8e3d9;border-color:#d5ccba}
body.presentation-mode .refine-bar .ci{background:#f5f0e8;border-color:#d5ccba;color:#16324f}
body.presentation-mode .refine-bar .cl{color:#16324f}
body.presentation-mode .ao-acc{background:#ffffff;border-color:#c8d4e0}
body.presentation-mode .ao-acc summary{color:#003087;font-size:1.12rem}
body.presentation-mode .ao-acc summary::after{color:#003087}
body.presentation-mode .ao-block+.ao-block{border-top-color:#c8d4e0}
body.presentation-mode .ao h3{color:#003087;font-size:1.1rem}
body.presentation-mode .ao p,body.presentation-mode .ao li{color:#16324f;font-size:1rem}
body.presentation-mode .ao strong{color:#003087}
body.presentation-mode .ao-muted-note{color:#516579}
body.presentation-mode .pw{background:#ffffff;border:1.5px solid #b8c7d6;box-shadow:0 2px 10px rgba(22,50,79,.08)}
body.presentation-mode .pw h3{color:#003087;border-bottom-color:#b8c7d6}
body.presentation-mode .wf{color:#516579}
body.presentation-mode .pb{background:#f5f8fb;border:1.5px solid #b8c7d6}
body.presentation-mode .pb.m{border-color:#f3a914}
body.presentation-mode .pb.b{border-color:#166534}
body.presentation-mode .pl{color:#003087;font-size:.72rem}
body.presentation-mode .pl.ml{color:#b07a00}
body.presentation-mode .pl.bl{color:#166534}
body.presentation-mode .pt{color:#16324f;font-size:.94rem;line-height:1.8}
body.presentation-mode .bo{color:#003087;border-color:rgba(0,48,135,.45)}
body.presentation-mode .bo:hover{background:rgba(0,48,135,.07);border-color:#003087}
body.presentation-mode .btn2{background:#f3a914;color:#0a1520}
body.presentation-mode .btn2:hover{background:#e09912}
body.presentation-mode .er{background:rgba(185,28,28,.06);border-color:rgba(185,28,28,.35);color:#b91c1c}
body.presentation-mode .ds-wrap h2{color:#003087}
body.presentation-mode .ds-wrap .ds-sub{color:#516579}
body.presentation-mode .ds-table th{color:#003087;border-bottom:1.5px solid #b8c7d6}
body.presentation-mode .ds-table td{border-bottom:1px solid #dce8f0;color:#516579}
body.presentation-mode .ds-table td:first-child{color:#16324f}
body.presentation-mode .ds-table td:nth-child(2){color:#516579}
body.presentation-mode .ds-badge.live{background:rgba(22,101,52,.1);color:#166534;border-color:rgba(22,101,52,.3)}
body.presentation-mode .ds-badge.model{background:rgba(243,169,20,.12);color:#b07a00;border-color:#f3a914}
body.presentation-mode .ds-badge.derived{background:#eef3f7;color:#516579;border-color:#b8c7d6}
body.presentation-mode .ds-badge.local{background:rgba(180,83,9,.08);color:#92400e;border-color:rgba(180,83,9,.25)}
body.presentation-mode .ds-badge.rules{background:rgba(29,78,216,.08);color:#1d4ed8;border-color:rgba(29,78,216,.25)}

</style>
</head>
<body>
<header style="justify-content:space-between;">
  <div style="display:flex;align-items:center;gap:1.25rem;">
    <div class="lb">BT</div>
    <div>
      <h1>Boys Town Appeal Generator</h1>
      <p>Data-Driven Donor Appeal Concepts &mdash; Informed by Donor, Cluster, and Campaign Data</p>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:.75rem;">
    <button class="pm-toggle" id="pmToggle" onclick="togglePresentationMode()" title="Toggle high-contrast mode for projectors">
      <span class="pm-icon">&#9788;</span>
      <span>Presentation Mode</span>
      <span class="pm-dot"></span>
    </button>
    <a href="/logout" class="signout-link" style="font-size:.75rem;font-weight:600;color:#8899aa;letter-spacing:.08em;text-transform:uppercase;text-decoration:none;padding:.4rem .9rem;border:1px solid #2a3a4a;border-radius:5px;transition:color .2s,border-color .2s;" onmouseover="this.style.color='#fff';this.style.borderColor='#fff'" onmouseout="this.style.color='#8899aa';this.style.borderColor='#2a3a4a'">Sign Out</a>
  </div>
</header>

<nav class="tab-nav">
  <button class="tab-btn active" onclick="switchTab('generator')">&#9997; Appeal Generator</button>
  <button class="tab-btn" onclick="switchTab('datasources')">&#128200; Data Sources</button>
</nav>

<div id="tab-generator" class="tab-pane active">
<div class="main">

  <!-- Cluster selector row -->
  <div class="cluster-row">
    <div class="cluster-field">
      <label>Personicx Cluster</label>
      <div class="dd-wrap" id="ddWrap">
        <div class="dd-btn" id="ddBtn" onclick="toggleDD()">
          <span class="dd-label" id="ddLabel">Elite Earners</span>
          <span id="ddBtnStars" style="font-size:.82rem;letter-spacing:1px;margin-left:auto;margin-right:.4rem"></span>
          <span class="dd-arrow">&#9660;</span>
        </div>
        <div class="dd-list" id="ddList">
          <div class="dd-sort">
            <button class="dd-sort-btn active" id="sortRank" onclick="setSort('rank')">&#9733; Ranking</button>
            <button class="dd-sort-btn" id="sortAlpha" onclick="setSort('alpha')">A&#8211;Z</button>
          </div>
          <div class="dd-search"><input type="text" id="ddSearch" placeholder="Search clusters..." oninput="filterDD()"></div>
          <div class="dd-filters" id="ddFilters">
            <button class="dd-pill active" data-filter="all" onclick="setFilter('all')">All</button>
            <button class="dd-pill" data-filter="top" onclick="setFilter('top')">Top Ranked</button>
            <button class="dd-pill" data-filter="under" onclick="setFilter('under')">Underperforming</button>
            <button class="dd-pill" data-filter="highincome" onclick="setFilter('highincome')">High Income</button>
            <button class="dd-pill" data-filter="rural" onclick="setFilter('rural')">Rural</button>
            <button class="dd-pill" data-filter="urban" onclick="setFilter('urban')">Urban</button>
            <button class="dd-pill" data-filter="acq" onclick="setFilter('acq')">Acquisition-Friendly</button>
          </div>
          <div class="dd-item dd-special" data-value="__none__" onclick="selectCluster(this)">
            <span class="dd-item-name">&#10022; Creative Direction Only &mdash; No Cluster</span>
          </div>
          <div id="ddItems"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── Customize bar ── -->
  <div class="cbar">
    <p class="cbar-note">Optional creative overrides. Leave fields blank to let the model choose.</p>

    <!-- Row 1: Creative inputs -->
    <div class="cbar-row cbar-clusters">
      <div class="cf cf-wide">
        <span class="cl">Creative Direction <em>(optional)</em></span>
        <input type="text" class="ci" id="theme" placeholder="e.g. Easter, winter urgency, donor upgrade" maxlength="200">
      </div>
      <div class="cf cf-med">
        <span class="cl">Premium Add-In <em>(override)</em></span>
        <input type="text" class="ci" id="addinOverride" placeholder="e.g. Seed packet, prayer journal" maxlength="300">
      </div>
      <div class="cf cf-med">
        <span class="cl">Imagery Style <em>(override)</em></span>
        <input type="text" class="ci" id="imageryOverride" placeholder="e.g. Warm autumn, rural farmhouse" maxlength="300">
      </div>
    </div>

    <!-- Row 2: Advanced options -->
    <details class="cbar-adv">
      <summary>Advanced Options</summary>
      <div class="cbar-adv-body">

        <!-- Package row -->
        <div class="adv-sec-lbl">Package</div>
        <div class="adv-pkg-grid">
          <div class="cf cf-sm">
            <span class="cl">Envelope <em>optional</em></span>
            <div class="sw">
              <select class="ci ci-sel" id="envelopeFormat">
                <option value="">AI selects</option>
                <option value="9.5x4.125in #10 standard">#10 Standard</option>
                <option value="6x9 envelope">6×9 Envelope</option>
                <option value="9x12 flat mailer">9×12 Flat Mailer</option>
                <option value="7.5x3.875in Monarch">Monarch</option>
              </select>
            </div>
          </div>
          <div class="cf cf-sm">
            <span class="cl">Mail Month <em>optional</em></span>
            <div class="sw">
              <select class="ci ci-sel" id="mailMonth">
                <option value="">Month</option>
                <option>January</option><option>February</option><option>March</option>
                <option>April</option><option>May</option><option>June</option>
                <option>July</option><option>August</option><option>September</option>
                <option>October</option><option>November</option><option>December</option>
              </select>
            </div>
          </div>
          <div class="cf cf-sm">
            <span class="cl">Year</span>
            <input type="text" class="ci" id="mailYear" placeholder="2026" maxlength="4">
          </div>
          <div class="cf cf-med">
            <span class="cl">Last Package <em>optional</em></span>
            <input type="text" class="ci" id="lastPkg" placeholder="e.g. Floral calendar, Jan 2025" maxlength="200">
          </div>
        </div>

        <div class="cf" style="margin-top:.9rem;">
          <span class="cl">Envelope Teaser <em>(override)</em></span>
          <input type="text" class="ci" id="teaserOverride" placeholder="e.g. A gift inside — for a child who needs a home." maxlength="200">
        </div>

        <div class="adv-divider"></div>

        <!-- Color palette + Ask ladder -->
        <div class="adv-bottom-row">

          <div>
            <div class="adv-sec-lbl">Color palette <em>overrides brand defaults</em></div>
            <div class="adv-color-row">
              <div class="adv-cswatch">
                <span class="adv-cswatch-lbl">Primary</span>
                <div class="cs-pick"><input type="color" id="cp1" value="#003087" oninput="syncColor(1)"></div>
                <input type="text" class="cs-hex" id="ch1" value="#003087" oninput="syncHex(1)" maxlength="7" aria-label="Primary color hex">
              </div>
              <div class="adv-cswatch">
                <span class="adv-cswatch-lbl">Secondary</span>
                <div class="cs-pick"><input type="color" id="cp2" value="#f3a914" oninput="syncColor(2)"></div>
                <input type="text" class="cs-hex" id="ch2" value="#f3a914" oninput="syncHex(2)" maxlength="7" aria-label="Secondary color hex">
              </div>
              <div class="adv-cswatch">
                <span class="adv-cswatch-lbl">Accent</span>
                <div class="cs-pick"><input type="color" id="cp3" value="#FAF6F0" oninput="syncColor(3)"></div>
                <input type="text" class="cs-hex" id="ch3" value="#FAF6F0" oninput="syncHex(3)" maxlength="7" aria-label="Accent color hex">
              </div>
              <button class="cs-reset" onclick="resetColors()" title="Reset to Boys Town brand">&#8635;</button>
            </div>
          </div>

          <div class="adv-divider-v"></div>

          <div>
            <div class="adv-sec-lbl">Ask ladder <em>overrides data-driven amounts</em></div>
            <div class="ladder">
              <input type="text" id="ladderLow" placeholder="Low" maxlength="6">
              <input type="text" id="ladderMid" placeholder="Mid" maxlength="6">
              <input type="text" id="ladderHigh" placeholder="High" maxlength="6">
            </div>
          </div>

        </div>

      </div>
    </details>

    <div class="cbar-actions" style="margin-top:1rem">
      <button class="tog" id="norulesBtn" onclick="toggleMode('norules')" title="Remove all brand guardrails">⚠ No Rules</button>
      <button class="tog" id="clearBtn" onclick="clearAll()" title="Clear all inputs and output">✕ Clear</button>
      <div class="cbar-actions-spacer"></div>
      <button class="genbtn" id="genBtn" onclick="runGenerate()">Generate Appeal</button>
    </div>
  </div><!-- /cbar -->

  <div class="er" id="er"></div>

  <div class="ld" id="ld">
    <div class="sp"></div>
    <p>Generating appeal for <span id="lc"></span>...</p>
    <p class="st" id="ls">Fetching RFM data from BigQuery...</p>
    <div class="ld-bar-wrap"><div class="ld-bar" id="ldBar"></div></div>
  </div>

  <div class="rs" id="rs">
    <div class="result-tabs">
      <button class="result-tab active" id="resultTabBrief" onclick="switchResultTab('brief')">Appeal Brief</button>
      <button class="result-tab" id="resultTabWorkflow" onclick="switchResultTab('workflow')">Image Workflow</button>
    </div>
    <div class="result-pane active" id="resultPaneBrief">
      <div class="ms" id="ms"></div>
      <div class="why-box" id="whyBox" style="display:none"></div>
      <div class="prov-strip" id="provStrip" style="display:none"></div>
      <div class="refine-bar" id="refineBar">
        <div class="cf" style="flex:1">
          <label class="cl">Refine This Appeal</label>
          <input class="ci" type="text" id="refineInput" placeholder="e.g. switch the add-in to a seed packet, make the letter warmer, use a Christmas theme..." maxlength="500">
          <div class="refine-hint">Describe what to change — everything else stays intact</div>
        </div>
        <button class="refine-btn" id="refineBtn" onclick="runRefine()">Refine</button>
      </div>
      <div class="ao" id="ao"></div>
    </div>
    <div class="result-pane" id="resultPaneWorkflow">
      <div class="pw" id="pw">
        <h3>&#127912; Image Workflow</h3>
        <p class="wf">Use the brief tab for executive review, then use this workflow tab to copy the final package blueprint prompt and generate the image.</p>
        <div class="pb m">
          <span class="pl ml">Step 1 &mdash; Master Persona Prompt</span>
          <button class="cb" id="mb" onclick="copyM()">Copy</button>
          <div class="pt" id="mt">You are Boys Town's senior direct mail creative director with 30 years of experience producing award-winning fundraising packages for national nonprofits. You now work exclusively for Boys Town. When generating appeal package images, you produce detailed flat-lay package blueprints showing every component of the mail piece — outer envelope, donor letter, reply card, and premium add-in — arranged together and annotated with approximate dimensions so the Boys Town marketing team can brief a print vendor or designer directly from the image. Your work is precise, production-ready, and always reflects the dignity and mission of Boys Town.</div>
        </div>
        <div class="pb b" id="bb" style="display:none">
          <span class="pl bl">Step 2 &mdash; Appeal Package Blueprint Prompt</span>
          <button class="cb" id="bb2" onclick="copyB()">Copy</button>
          <div class="pt" id="bt"></div>
        </div>
      </div>
    </div>
    <div class="ab">
      <button class="bo" onclick="dlA()">Download .txt</button>
      <button class="btn2" onclick="runGenerate()">Regenerate</button>
    </div>
  </div>
</div>

<script>
/* ── Presentation Mode ── */
function togglePresentationMode(){
  var on=document.body.classList.toggle('presentation-mode');
  localStorage.setItem('btPresentationMode', on ? '1' : '0');
}
(function(){
  if(localStorage.getItem('btPresentationMode')==='1'){
    document.body.classList.add('presentation-mode');
  }
})();
function switchTab(id){
  document.querySelectorAll('.tab-btn').forEach(function(b,i){b.classList.toggle('active',['generator','datasources'][i]===id);});
  document.querySelectorAll('.tab-pane').forEach(function(p){p.classList.toggle('active',p.id==='tab-'+id);});
}
function switchResultTab(id){
  currentResultTab=id;
  document.getElementById('resultTabBrief').classList.toggle('active',id==='brief');
  document.getElementById('resultTabWorkflow').classList.toggle('active',id==='workflow');
  document.getElementById('resultPaneBrief').classList.toggle('active',id==='brief');
  document.getElementById('resultPaneWorkflow').classList.toggle('active',id==='workflow');
}
var M=null, T=null, BP='';
var NL=String.fromCharCode(10);
var selectedCluster='Elite Earners';
var ALL_CLUSTERS=[];
var CLUSTER_RFM={};
var CLUSTER_SCORES={"Diligent Duos":5,"Active Guardians":5,"Digitally Kinetic":5,"Prosperous Metropolitans":4.8,"Fortuned Estates":4.6,"Receptive Recreationers":4.6,"Lifelong Learners":4.6,"Skillful Strivers":4.6,"Simply Soloists":4.6,"Onward & Upward":4.6,"Finding Home":4.6,"Restless Lessees":4.4,"Healthy Investors":4.4,"Settled Self-Supporters":4.2,"Sunset Stability":4.2,"Ascending Affluents":4.2,"Flourishing Professionals":4,"Rustic Adventurers":4,"Comfortable Commercials":4,"Settled Couples":3.8,"Countryside Keepers":3.8,"Elite Earners":3.8,"Rural Pragmatists":3.8,"Heyday Duos":3.6,"Untethered Aspirations":3.6,"Gilt-Edged Guardians":3.6,"Singular Fulfillment":3.6,"Multimedia Parents":3.6,"Nesting Nomads":3.4,"Pastoral Prosperity":3.4,"Moneyed Multi-Gens":3.4,"Houseproud Connectors":3.4,"Astute City Elders":3.4,"Seasoned Outdoorsfolk":3.4,"Two-To-Play":3.2,"Country Connections":3.2,"Independent Seniors":3,"Green City Roots":3,"Conscientiously Comfortable":2.8,"Urban Owners":2.8,"Domestic Voyagers":2.8,"Active Twilight":2.6,"Solo and Switched On":2.6,"Digital Devotees":2.4,"Golden Guardians":2.4,"Communities & Connections":2.4,"Fresh Air Families":2.2,"Digital Startups":2.2,"Settled Success":2.2,"Self-Reliant Renters":2.2,"Downtown Duos":2.2,"Mature Insights":2,"Well-Funded Families":2,"Traditionalist Travelers":2,"Cultured Parents":2,"Metro Mobility":1.8,"Sporting Metro":1.8,"Modest Midlifers":1.6,"Rural Renters":1.6,"Energetic Achievers":1.6,"Lively Balance":1.4,"Metro Mature":1.4,"Metro Spirit":1.2,"Collaborative Custodians":1.2,"Country Convenience":1,"Single Providers":1,"Maturing Singles":1,"Urban Twenties":1,"In The Now":1,"Balanced Budgeters":1,"Tech Country":1};

function scoreLabel(name){
  var sc=CLUSTER_SCORES[name];
  if(!sc) return '';
  return sc.toFixed(1)+' <span style="color:#f3a914;font-size:.9rem;">&#9733;</span>';
}

var currentSort='rank';
var currentFilter='all';
var currentResultTab='brief';

function getSorted(){
  if(currentSort==='alpha'){
    return ALL_CLUSTERS.slice().sort(function(a,b){return a.localeCompare(b);});
  }
  var ranked=Object.keys(CLUSTER_SCORES).sort(function(a,b){return CLUSTER_SCORES[b]-CLUSTER_SCORES[a];});
  var unranked=ALL_CLUSTERS.filter(function(c){return !CLUSTER_SCORES[c];});
  return ranked.concat(unranked);
}

function inferTags(name){
  var score=CLUSTER_SCORES[name]||0, lower=String(name).toLowerCase(), tags=[];
  if(score>=4.2) tags.push({label:'Top Ranked',cls:'good'});
  if(score>0&&score<3.0) tags.push({label:'Underperforming',cls:'warn'});
  if(/affluent|earner|estates|funded|moneyed|prosperous|investor|commercials|guardians/.test(lower)) tags.push({label:'High Income',cls:'info'});
  if(/rural|country|countryside|pastoral|rustic|outdoorsfolk/.test(lower)) tags.push({label:'Rural',cls:''});
  if(/metro|urban|downtown|city|metropolitans/.test(lower)) tags.push({label:'Urban',cls:''});
  if(score>=3.6 && /digital|urban|metro|startup|striver|aspirations|kinetic|mobility|twenties|solo/.test(lower)) tags.push({label:'Acquisition-Friendly',cls:'good'});
  return tags;
}

function matchesFilter(name){
  var score=CLUSTER_SCORES[name]||0, lower=String(name).toLowerCase();
  if(currentFilter==='all') return true;
  if(currentFilter==='top') return score>=4.2;
  if(currentFilter==='under') return score>0 && score<3.0;
  if(currentFilter==='highincome') return /affluent|earner|estates|funded|moneyed|prosperous|investor|commercials|guardians/.test(lower);
  if(currentFilter==='rural') return /rural|country|countryside|pastoral|rustic|outdoorsfolk/.test(lower);
  if(currentFilter==='urban') return /metro|urban|downtown|city|metropolitans/.test(lower);
  if(currentFilter==='acq') return score>=3.6 && /digital|urban|metro|startup|striver|aspirations|kinetic|mobility|twenties|solo/.test(lower);
  return true;
}

function buildDropdown(){
  var sorted=getSorted();
  var container=document.getElementById('ddItems');
  var html='';
  for(var i=0;i<sorted.length;i++){
    var name=sorted[i];
    if(!matchesFilter(name)) continue;
    var lbl=scoreLabel(name);
    var tags=inferTags(name).slice(0,3).map(function(t){
      return '<span class="dd-tag'+(t.cls?' '+t.cls:'')+'">'+escH(t.label)+'</span>';
    }).join('');
    html+='<div class="dd-item" data-value="'+escH(name)+'" onclick="selectCluster(this)">';
    html+='<span class="dd-item-name">'+escH(name)+'</span>';
    html+='<span class="dd-item-meta">'+tags+'<span class="dd-item-stars">'+lbl+'</span></span>';
    html+='</div>';
  }
  container.innerHTML=html;
  updateBtn(selectedCluster);
}

function setSort(mode){
  currentSort=mode;
  document.getElementById('sortRank').classList.toggle('active', mode==='rank');
  document.getElementById('sortAlpha').classList.toggle('active', mode==='alpha');
  buildDropdown();
}

function setFilter(mode){
  currentFilter=mode;
  document.querySelectorAll('.dd-pill').forEach(function(el){el.classList.toggle('active', el.getAttribute('data-filter')===mode);});
  buildDropdown();
}

function init(){
  fetch('/clusters')
  .then(function(r){return r.json();})
  .then(function(d){ALL_CLUSTERS=d;buildDropdown();});
  fetch('/cluster_rfm')
  .then(function(r){return r.json();})
  .then(function(d){CLUSTER_RFM=d;})
  .catch(function(){console.warn('cluster_rfm failed — star ratings and filters unavailable.');});
}
init();

function updateBtn(clusterName){
  var items=document.querySelectorAll('.dd-item');
  for(var i=0;i<items.length;i++){
    items[i].classList.toggle('selected', items[i].getAttribute('data-value')===clusterName);
  }
  document.getElementById('ddLabel').textContent=clusterName==='__none__'?'Creative Direction Only':clusterName;
  document.getElementById('ddBtnStars').innerHTML=clusterName==='__none__'?'<span style="font-size:.75rem;color:#a8d4b8;font-style:italic">No Cluster</span>':scoreLabel(clusterName);
}

function selectCluster(el){
  selectedCluster=el.getAttribute('data-value');
  updateBtn(selectedCluster);
  closeDD();
}

function toggleDD(){
  var btn=document.getElementById('ddBtn');
  var list=document.getElementById('ddList');
  var isOpen=list.classList.contains('open');
  if(isOpen){ closeDD(); }
  else {
    btn.classList.add('open');
    list.classList.add('open');
    document.getElementById('ddSearch').value='';
    filterDD();
    document.getElementById('ddSearch').focus();
  }
}

function closeDD(){
  document.getElementById('ddBtn').classList.remove('open');
  document.getElementById('ddList').classList.remove('open');
}

function filterDD(){
  var q=document.getElementById('ddSearch').value.toLowerCase();
  var items=document.querySelectorAll('.dd-item');
  for(var i=0;i<items.length;i++){
    if(items[i].classList.contains('dd-special')){items[i].style.display='flex';continue;}
    items[i].style.display=items[i].getAttribute('data-value').toLowerCase().indexOf(q)>=0?'flex':'none';
  }
}

document.addEventListener('click',function(e){
  if(!document.getElementById('ddWrap').contains(e.target)) closeDD();
});
document.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!document.getElementById('genBtn').disabled) runGenerate();
});

var ST=['Fetching RFM data from BigQuery...','Loading psychographic profile...','Retrieving add-in performance history...','Pulling gift timing and economics data...','Searching appeal knowledge base...','Building prompt with verified cluster data...','Generating appeal with Gemini 2.5 Flash...','Enforcing creative rules and formatting output...'];

var activeMode={norules:false};
function toggleMode(m){
  activeMode[m]=!activeMode[m];
  var id='norulesBtn';
  var cls=m==='norules'?'on-red':'on';
  document.getElementById(id).className='tog'+(activeMode[m]?' '+cls:'');
}
function syncColor(n){document.getElementById('ch'+n).value=document.getElementById('cp'+n).value;}
function syncHex(n){var v=document.getElementById('ch'+n).value;if(/^#[0-9a-fA-F]{6}$/.test(v))document.getElementById('cp'+n).value=v;}
function resetColors(){
  var def=['#003087','#f3a914','#FAF6F0'];
  for(var i=1;i<=3;i++){document.getElementById('cp'+i).value=def[i-1];document.getElementById('ch'+i).value=def[i-1];}
}
function getColors(){
  var def=['#003087','#f3a914','#FAF6F0'],changed=false,cols=[];
  for(var i=1;i<=3;i++){var v=document.getElementById('ch'+i).value;cols.push(v);if(v.toLowerCase()!==def[i-1].toLowerCase())changed=true;}
  return changed?cols:null;
}
function clearAll(){
  document.getElementById('theme').value='';
  document.getElementById('addinOverride').value='';
  document.getElementById('imageryOverride').value='';
  document.getElementById('mailMonth').value='';
  document.getElementById('mailYear').value='2026';
  document.getElementById('lastPkg').value='';
  document.getElementById('ladderLow').value='';
  document.getElementById('ladderMid').value='';
  document.getElementById('ladderHigh').value='';
  document.getElementById('envelopeFormat').value='';
  document.getElementById('teaserOverride').value='';
  if(activeMode.norules){ toggleMode('norules'); }
  document.getElementById('ao').innerHTML='';
  document.getElementById('ms').innerHTML='';
  document.getElementById('whyBox').innerHTML='';
  document.getElementById('whyBox').style.display='none';
  document.getElementById('provStrip').innerHTML='';
  document.getElementById('provStrip').style.display='none';
  document.getElementById('pw').style.display='none';
  document.getElementById('bb').style.display='none';
  document.getElementById('er').textContent='';
  document.getElementById('er').className='er';
  document.getElementById('rs').className='rs';
  document.getElementById('refineBar').className='refine-bar';
  document.getElementById('refineInput').value='';
  T=null; M=null; BP='';
  switchResultTab('brief');
  resetColors();
}

function validateInputs(){
  var lLow=document.getElementById('ladderLow').value.trim();
  var lMid=document.getElementById('ladderMid').value.trim();
  var lHigh=document.getElementById('ladderHigh').value.trim();
  if(lLow||lMid||lHigh){
    if(!(lLow&&lMid&&lHigh)) return 'Ask ladder override requires Low, Mid, and High.';
    var a=[lLow,lMid,lHigh].map(function(v){return parseInt(String(v).replace(/[^0-9]/g,''),10);});
    if(a.some(function(v){return !Number.isFinite(v)||v<=0;})||!(a[0]<a[1]&&a[1]<a[2])){
      return 'Ask ladder must use valid ascending amounts.';
    }
  }
  var colors=getColors();
  if(colors){
    for(var i=0;i<colors.length;i++){
      if(!/^#[0-9a-fA-F]{6}$/.test(colors[i])) return 'Color override must use valid 6-digit hex values.';
    }
  }
  return '';
}

function runGenerate(){
  var cl=selectedCluster;
  var th=document.getElementById('theme').value.trim();
  var mo=document.getElementById('mailMonth').value;
  var yr=document.getElementById('mailYear').value;
  var mailDate=(mo&&yr)?mo+' '+yr:(mo||yr||'');
  var lastPkg=document.getElementById('lastPkg').value.trim();
  var addinOvr=document.getElementById('addinOverride').value.trim();
  var imageryOvr=document.getElementById('imageryOverride').value.trim();
  var envFmt=document.getElementById('envelopeFormat').value;
  var teaserOvr=document.getElementById('teaserOverride').value.trim();
  var lLow=document.getElementById('ladderLow').value.trim();
  var lMid=document.getElementById('ladderMid').value.trim();
  var lHigh=document.getElementById('ladderHigh').value.trim();
  var colors=getColors();
  var validationError=validateInputs();
  if(validationError){
    var e=document.getElementById('er');
    e.textContent=validationError; e.className='er on';
    return;
  }
  var btn=document.getElementById('genBtn');
  var bar=document.getElementById('ldBar');
  btn.disabled=true;
  btn.textContent='Generating...';
  btn.classList.add('generating');
  document.getElementById('ld').className='ld on';
  document.getElementById('rs').className='rs';
  document.getElementById('er').className='er';
  document.getElementById('pw').style.display='none';
  document.getElementById('bb').style.display='none';
  var isNoCluster=(cl==='__none__');
  var ST_USE=isNoCluster?['Searching appeal rules knowledge base...','Building creative direction prompt...','Generating appeal with Gemini 2.5 Flash...','Formatting output...']:ST;
  document.getElementById('lc').textContent=isNoCluster?'Creative Direction Only'+(th?' — '+th:''):cl+(th?' — '+th:'');
  // Progress bar — fills over 38s to ~88%, snaps to 100% on completion
  var totalMs=38000, steps=ST_USE.length, stepMs=Math.floor(totalMs/steps);
  var pct=0, barTarget=88;
  if(bar){bar.style.width='0%';}
  var si=0, sEl=document.getElementById('ls');
  var tm=setInterval(function(){
    if(si<ST_USE.length){sEl.style.opacity='0';setTimeout(function(){sEl.textContent=ST_USE[si++];sEl.style.opacity='1';},150);}
    pct=Math.min(barTarget, Math.round((si/steps)*barTarget));
    if(bar) bar.style.width=pct+'%';
  },stepMs);
  function finishLoad(){
    clearInterval(tm);
    if(bar){bar.style.transition='width .25s ease';bar.style.width='100%';}
    setTimeout(function(){
      document.getElementById('ld').className='ld';
      btn.disabled=false;
      btn.textContent='Generate Appeal';
      btn.classList.remove('generating');
      if(bar){bar.style.width='0%';}
    },300);
  }
  fetch('/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cluster:cl,theme:th,mail_date:mailDate,last_package:lastPkg,no_rules:activeMode.norules,addin_override:addinOvr,imagery_override:imageryOvr,envelope_format:envFmt,teaser_override:teaserOvr,ladder_low:lLow,ladder_mid:lMid,ladder_high:lHigh,colors:colors})})
  .then(function(r){return r.json();})
  .then(function(d){
    finishLoad();
    if(d.error){
      var e=document.getElementById('er');
      e.textContent=d.error; e.className='er on';
    } else {
      T=d.full_text||d.text; M=d.meta;
      renderM(d.meta); renderA(d.text, d.image_prompt);
      switchResultTab('brief');
      document.getElementById('rs').className='rs on';
      document.getElementById('refineBar').className='refine-bar on';
      document.getElementById('refineInput').value='';
    }
  })
  .catch(function(e){
    finishLoad();
    var er=document.getElementById('er');
    er.textContent='Request failed: '+e.message; er.className='er on';
  });
}

function runRefine(){
  var instruction=document.getElementById('refineInput').value.trim();
  if(!instruction){document.getElementById('refineInput').focus();return;}
  if(!T||!M){return;}
  var btn=document.getElementById('refineBtn');
  var bar=document.getElementById('ldBar');
  btn.disabled=true;btn.textContent='Refining...';
  document.getElementById('ld').className='ld on';
  document.getElementById('er').className='er';
  var RST=['Sending refinement to Gemini 2.5 Flash...','Applying changes to appeal concept...','Running enforcement checks...','Formatting output...'];
  var totalMs=30000,steps=RST.length,stepMs=Math.floor(totalMs/steps);
  var pct=0,barTarget=88;
  if(bar){bar.style.width='0%';}
  var si=0,sEl=document.getElementById('ls');
  document.getElementById('lc').textContent='Refining: '+instruction.substring(0,60)+(instruction.length>60?'...':'');
  var tm=setInterval(function(){
    if(si<RST.length){sEl.style.opacity='0';setTimeout(function(){sEl.textContent=RST[si++];sEl.style.opacity='1';},150);}
    pct=Math.min(barTarget,Math.round((si/steps)*barTarget));
    if(bar) bar.style.width=pct+'%';
  },stepMs);
  function finishRefine(){
    clearInterval(tm);
    if(bar){bar.style.transition='width .25s ease';bar.style.width='100%';}
    setTimeout(function(){
      document.getElementById('ld').className='ld';
      btn.disabled=false;btn.textContent='Refine';
      if(bar){bar.style.width='0%';}
    },300);
  }
  fetch('/refine',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({previous_output:T,instruction:instruction,meta:M})})
  .then(function(r){return r.json();})
  .then(function(d){
    finishRefine();
    if(d.error){
      var e=document.getElementById('er');
      e.textContent=d.error;e.className='er on';
    } else {
      T=d.full_text||d.text;M=d.meta;
      renderM(d.meta);renderA(d.full_text||d.text,d.image_prompt);
      switchResultTab('brief');
      document.getElementById('rs').className='rs on';
      document.getElementById('refineInput').value='';
      document.getElementById('refineInput').placeholder='Refined \u2714 \u2014 enter another change or generate a new appeal';
    }
  })
  .catch(function(e){
    finishRefine();
    var er=document.getElementById('er');
    er.textContent='Refinement failed: '+e.message;er.className='er on';
  });
}
document.addEventListener('DOMContentLoaded',function(){
  var ri=document.getElementById('refineInput');
  if(ri) ri.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();runRefine();}});
});

function bold(t){
  var p=escH(String(t==null?'':t)).split('**'), r='';
  for(var i=0;i<p.length;i++) r+=i%2===1?'<strong>'+p[i]+'</strong>':p[i];
  return r;
}

function renderM(m){
  if(!m||Object.keys(m).length===0){document.getElementById('ms').style.display='none';return;}
  document.getElementById('ms').style.display='';

  function fmtMoney(v){return v==null?'N/A':'$'+Math.round(parseFloat(v)).toLocaleString();}
  function fmtMoney2(v){return v==null?'N/A':'$'+parseFloat(v).toFixed(2);}  
  function posture(){
    if(m.no_cluster) return {label:'Mixed',cls:'bg-m'};
    var conv1=m.acquisition&&m.acquisition.weighted_year1_conversion!=null?parseFloat(m.acquisition.weighted_year1_conversion):null;
    var conv2=m.acquisition&&m.acquisition.weighted_year2_conversion!=null?parseFloat(m.acquisition.weighted_year2_conversion):null;
    var ltv=m.acquisition&&m.acquisition.weighted_lifetime_value!=null?parseFloat(m.acquisition.weighted_lifetime_value):null;
    var score=CLUSTER_SCORES[m.cluster]||0;
    if((conv1!=null&&conv1>=0.28)||(conv2!=null&&conv2>=0.20)||(ltv!=null&&ltv>=250)||(/digital|startup|twenties|striver|metro|urban|kinetic|aspirations|solo/i.test(m.cluster)&&score>=3.6)) return {label:'Acquisition-capable',cls:'bg-t'};
    if(m.underperforming||(m.lapse_prob!=null&&parseFloat(m.lapse_prob)>=0.55)) return {label:'Retention-led',cls:'bg-r'};
    return {label:'Mixed',cls:'bg-m'};
  }
  function dominantGeo(){
    var rows=[['Rural',m.urbanicity_rural],['Suburban',m.urbanicity_suburban],['Urban',m.urbanicity_urban],['Metro',m.urbanicity_metro]].filter(function(x){return x[1]!=null;});
    rows.sort(function(a,b){return b[1]-a[1];});
    return rows.length?rows[0][0]:'N/A';
  }
  function benchmarkTag(){
    var tags=[]; if(m.has_real_roi) tags.push('ROI'); if(m.has_economics) tags.push('Economics'); if(m.acquisition) tags.push('Cohort');
    return tags.length?tags.join(' / '):'RFM';
  }

  var p=posture();
  var timingNote=(m.gift_timing&&m.gift_timing.peak&&m.gift_timing.peak.month_name)?'Historical timing from ClusterGiftTimingProfile':'No timing row available';
  var revenuePerPiece=(m.has_real_roi&&m.real_revenue&&m.real_pieces)?(parseFloat(m.real_revenue)/parseFloat(m.real_pieces)):null;
  var netPerPiece=(m.has_real_roi&&m.real_net_return!==null&&m.real_pieces)?(parseFloat(m.real_net_return)/parseFloat(m.real_pieces)):null;

  function tip(label, text){ return '<span class="ms-key tip" data-tip="'+text+'">'+label+'</span>'; }

  var s='';
  // ── Column 1: Cluster Intelligence ──────────────────────────────────────
  s+='<div class="ms-col">';
  s+='<div class="ms-title">Cluster Intelligence</div>';
  if(m.no_cluster){
    s+='<div class="ms-cluster">Creative Direction Only</div><div class="ms-sub">No cluster selected — theme-led generation</div>';
  } else {
    s+='<div class="ms-cluster">'+escH(m.cluster)+'</div>';
    s+='<div class="ms-sub">'+dominantGeo()+'-leaning cluster · '+(m.total_appeals||0)+' appeals analyzed</div>';
    s+='<div class="ms-badges">';
    s+='<span class="bg '+p.cls+'" title="'+(p.label==='Acquisition-capable'?'Cohort data shows year-1 conversion ≥28%, year-2 ≥20%, or LTV ≥$250. This cluster has meaningful new-donor pipeline potential.':p.label==='Retention-led'?'All appeal scores below 3.0, or average lapse probability ≥55%. Prioritize retention and renewal creative over acquisition.':'Neither strong acquisition signal nor high lapse risk. Standard renewal creative applies.')+'">'+p.label+'</span>';
    if(m.rule_555) s+='<span class="bg bg-g" title="The best appeal for this cluster scored 5 on Recency, Frequency, AND Monetary simultaneously. Use it as the creative blueprint but introduce meaningful differentiation.">555 Active</span>';
    if(m.underperforming) s+='<span class="bg bg-r" title="All appeal scores are below 3.0 for this cluster. Do not anchor to past creative — generate a net-new concept using proven cross-cluster themes.">Net-New Ideation</span>';
    s+='</div>';
    if(CLUSTER_SCORES[m.cluster]) s+='<div class="ms-row">'+tip('Cluster RFM','Composite RFM health score from the ClusterRFM table. Formula: (R×0.20)+(F×0.40)+(M×0.40). Scale 1–5. Benchmarked across all clusters — reflects how well this cluster responds to Boys Town appeals overall. F and M carry 80% of the weight.')+'<span class="ms-val hi">'+CLUSTER_SCORES[m.cluster].toFixed(1)+' ★</span></div>';
    if(m.top_psychographic) s+='<div class="ms-row">'+tip('Top signal','The highest-indexing psychographic interest for this cluster from ClusterPsychographicProfile. A value of 2.0x means donors in this cluster show twice the interest of the average Boys Town file. Values above 1.5x are strong creative anchors.')+'<span class="ms-val">'+escH(m.top_psychographic)+' '+(m.top_psychographic_idx?m.top_psychographic_idx.toFixed(2)+'x':'')+'</span></div>';
    s+='<div class="ms-row">'+tip('Peak giving month','The calendar month with the highest share of annual giving for this cluster, from ClusterGiftTimingProfile. Mailing 6–8 weeks before this month maximizes the chance of capturing peak generosity.')+'<span class="ms-val">'+(m.gift_timing&&m.gift_timing.peak&&m.gift_timing.peak.month_name?escH(String(m.gift_timing.peak.month_name)):'N/A')+'</span></div>';
    s+='<div class="ms-row">'+tip('Recommended drop','Calculated mail window 6–8 weeks before the peak giving month. Dropping in this window gives the appeal time to arrive, be read, and prompt a gift before the cluster\'s natural giving peak.')+'<span class="ms-val sm">'+(m.gift_timing&&m.gift_timing.recommended&&m.gift_timing.recommended.window?escH(String(m.gift_timing.recommended.window)):'Use selected mail date')+'</span></div>';
    s+='<div class="ms-row">'+tip('Timing source','Whether historical giving timing is available for this cluster. When available, timing comes from ClusterGiftTimingProfile. When unavailable, use the mail date you specified or a seasonally neutral concept.')+'<span class="ms-val sm">'+timingNote+'</span></div>';
    if(m.has_geography && m.geo_top_state){
      var geoConc = (m.geo_top3_concentration != null && m.geo_top3_concentration >= 50) ? 'Regional' : 'Diffuse';
      s+='<div class="ms-row">'+tip('Top state','Largest state by donor count for this cluster, from ClusterGeographicProfile. When top 3 states concentrate 50% or more of the cluster, regional creative cues are appropriate. Below 50% stays nationally neutral.')+'<span class="ms-val">'+escH(m.geo_top_state)+' ('+m.geo_top_state_pct.toFixed(1)+'%) '+geoConc+'</span></div>';
    }
    if(m.lapse_prob!=null) s+='<div class="ms-row">'+tip('Lapse risk','Average lapse probability across all donors in this cluster, from DonorLapseScores. High = avg ≥70%. Medium = avg ≥45%. Low = avg below 45%. Higher risk means more donors are likely to stop giving — consider retention-forward creative.')+'<span class="ms-val sm">'+(parseFloat(m.lapse_prob)*100).toFixed(1)+'%</span></div>';
    if(m.upgrade_prob!=null) s+='<div class="ms-row">'+tip('Upgrade potential','Average upgrade probability across donors in this cluster, from DonorUpgradeScores. Measures the likelihood that a donor can be motivated to increase their gift amount. High = avg ≥70%. Use impact and legacy framing when potential is strong.')+'<span class="ms-val sm">'+(parseFloat(m.upgrade_prob)*100).toFixed(2)+'%</span></div>';
  }
  s+='</div>';

  // ── Column 2: Strategy & Benchmarks ─────────────────────────────────────
  s+='<div class="ms-col">';
  s+='<div class="ms-title">Strategy &amp; Benchmarks</div>';
  if(m.no_cluster){
    s+='<div class="ms-row">'+tip('Benchmark mode','No cluster was selected. The appeal is generated using Boys Town appeal rules from the knowledge base and any creative direction you specified — not tied to historical cluster RFM performance.')+'<span class="ms-val sm">Rules + creative KB</span></div>';
    s+='<div class="ms-row">'+tip('Gift ladder','The three ask amounts shown on the reply card. In no-cluster mode these default to $25 / $50 / $100 unless you specified a custom ladder override.')+'<span class="ms-val ldr">$'+m.low+' / $'+m.mid+' / $'+m.high+'</span></div>';
  } else {
    s+='<div class="ms-row">'+tip('Best benchmark appeal','The appeal with the highest RFM composite score for this cluster in AppealClusterPerformance_AgentReady. Used as the primary creative and financial reference point. RFM formula: (R×0.20)+(F×0.40)+(M×0.40), scored 1–5 within this cluster only.')+'<span class="ms-val">'+escH(m.best_appeal)+'</span></div>';
    s+='<div class="ms-row">'+tip('Benchmark type','Which financial data sources are available for this cluster. ROI = verified revenue and net return from AppealClusterROI. Economics = mailing cost and volume from AppealMailingEconomics. Cohort = donor lifecycle data from DonorAcquisitionCohorts. More sources = higher financial confidence.')+'<span class="ms-val sm">'+benchmarkTag()+'</span></div>';
    if(m.ladder_source){
      var ladderLabel = (m.ladder_source === 'mean_fallback') ? 'Mean-based (fallback)' : 'Percentile-based ('+(m.distribution_confidence||'')+' conf.)';
      s+='<div class="ms-row">'+tip('Ladder source','How the gift ladder amounts were calculated. Percentile-based = p25 / p50 / p75 from ClusterGiftAmountDistribution when 30+ transactions are available. Mean-based = 0.5x / 1x / 2x of avg gift amount, used as a fallback when distribution data is sparse.')+'<span class="ms-val sm">'+ladderLabel+'</span></div>';
    }
    if((m.has_economics&&m.economics_pieces!=null)||m.has_real_roi){
      s+='<div class="ms-row">'+tip('Cost per piece','The per-unit printing and mailing cost for the benchmark appeal. Source: AppealMailingEconomics when available (preferred), otherwise the COST field from AppealClusterPerformance_AgentReady. Used to estimate total campaign cost.')+'<span class="ms-val">'+fmtMoney2(m.has_economics&&m.economics_pieces!=null?m.economics_cost_per_piece:m.cost_per_piece)+'</span></div>';
      s+='<div class="ms-row">'+tip('Mail quantity','Number of pieces mailed for the benchmark appeal. Source: AppealMailingEconomics when available, otherwise AppealClusterROI. Reflects the actual cluster donor pool that received the appeal.')+'<span class="ms-val sm">'+(m.has_economics&&m.economics_pieces?m.economics_pieces.toLocaleString():(m.has_real_roi&&m.real_pieces?m.real_pieces.toLocaleString():'N/A'))+'</span></div>';
      s+='<div class="ms-row">'+tip('Total mail cost','Estimated total cost to mail the benchmark appeal to this cluster. Source: AppealMailingEconomics when cost fields are valid. If Economics data is unavailable, falls back to AppealClusterROI total_mail_cost. Zero or blank Economics rows are excluded.')+'<span class="ms-val">'+fmtMoney(m.has_economics&&m.economics_pieces!=null?m.economics_total_mail_cost:(m.has_real_roi?m.real_cost:m.total_mail_cost))+'</span></div>';
      s+='<div class="ms-row">'+tip('Revenue / piece','Total verified revenue divided by pieces mailed for the benchmark appeal. Source: AppealClusterROI. A directional efficiency metric — how much revenue each mailed piece generated on average.')+'<span class="ms-val sm">'+(revenuePerPiece!=null?fmtMoney2(revenuePerPiece):'N/A')+'</span></div>';
      s+='<div class="ms-row">'+tip('Net / piece','Net return (revenue minus total mail cost) divided by pieces mailed. Source: AppealClusterROI. The clearest single measure of appeal profitability per piece. Positive = profitable campaign.')+'<span class="ms-val sm">'+(netPerPiece!=null?fmtMoney2(netPerPiece):'N/A')+'</span></div>';
    } else {
      s+='<div class="ms-row">'+tip('Economics','Mailing economics are not shown for this cluster. The benchmark appeal had fewer than 50 pieces mailed, which is below the minimum threshold for reliable cost and revenue data.')+'<span class="ms-val sm" style="color:var(--mu);font-style:italic;">Suppressed — fewer than 50 pieces mailed</span></div>';
    }
    if(m.acquisition&&(m.acquisition.weighted_year1_conversion!=null||m.acquisition.weighted_year2_conversion!=null||m.acquisition.weighted_lifetime_value!=null)){
      if(m.acquisition.weighted_year1_conversion!=null) s+='<div class="ms-row">'+tip('Year-1 conversion','Of donors acquired by this cluster\'s top acquisition appeal, the share who made a second gift within year 1. Source: DonorAcquisitionCohorts. A higher rate means the cluster retains new donors well in their first year.')+'<span class="ms-val sm">'+(parseFloat(m.acquisition.weighted_year1_conversion)*100).toFixed(1)+'%</span></div>';
      if(m.acquisition.weighted_year2_conversion!=null) s+='<div class="ms-row">'+tip('Year-2 conversion','Of donors acquired by this cluster\'s top acquisition appeal, the share who gave again in year 2. Source: DonorAcquisitionCohorts. Measures longer-term loyalty. Year-2 rates above 20% indicate strong multi-year retention.')+'<span class="ms-val sm">'+(parseFloat(m.acquisition.weighted_year2_conversion)*100).toFixed(1)+'%</span></div>';
      if(m.acquisition.weighted_lifetime_value!=null) s+='<div class="ms-row">'+tip('Weighted cohort LTV','Weighted average lifetime giving value per donor in the acquisition cohort. Source: DonorAcquisitionCohorts. Reflects the total revenue a new donor from this cluster is expected to generate over their giving lifetime. Only shown when 30+ donor rows are available.')+'<span class="ms-val sm">'+fmtMoney(m.acquisition.weighted_lifetime_value)+'</span></div>';
    } else if(!m.no_cluster){
      s+='<div class="ms-row">'+tip('Cohort data','Donor acquisition cohort data is not shown for this cluster. Fewer than 30 donor rows are available, which is below the minimum threshold for reliable conversion and lifetime value estimates.')+'<span class="ms-val sm" style="color:var(--mu);font-style:italic;">Suppressed — fewer than 30 donor rows</span></div>';
    }
  }
  s+='</div>';

  // ── Column 3: User Inputs ────────────────────────────────────────────────
  s+='<div class="ms-col">';
  s+='<div class="ms-title">Your Inputs</div>';
  s+='<div class="ms-row">'+tip('Cluster','The Personicx cluster selected for this generation. Clusters are demographic and behavioral segments. Each has its own historical appeal performance, psychographic profile, and giving patterns in the BigQuery data.')+'<span class="ms-val">'+escH(m.cluster||'No Cluster')+'</span></div>';
  s+='<div class="ms-row">'+tip('Creative direction','Optional theme or concept you entered to guide the appeal. Influences the theme, imagery, color palette, and copy tone. Can be a season, university, cause, or any creative concept. Leave blank to let RFM data drive all creative decisions.')+'<span class="ms-val cd">'+(m.theme?escH(m.theme):'Not specified')+'</span></div>';
  s+='<div class="ms-row">'+tip('Mail date','The month and year you entered for when this appeal will mail. Informs seasonal creative direction, surface props, copy urgency, and whether the drop date aligns with the cluster\'s historical peak giving window.')+'<span class="ms-val sm">'+(m.mail_date?escH(m.mail_date):'Not specified')+'</span></div>';
  s+='<div class="ms-row">'+tip('Last package','The most recent appeal sent to this segment that you entered. The app uses this to avoid repeating the same add-in type, color palette, or theme in the new concept. Noted explicitly in the Rationale section of the brief.')+'<span class="ms-val sm">'+(m.last_package?escH(m.last_package):'Not specified')+'</span></div>';
  var ov=[]; if(m.addin_override) ov.push('Add-in'); if(m.imagery_override) ov.push('Imagery'); if(m.envelope_format) ov.push('Envelope'); if(m.teaser_override) ov.push('Teaser'); if(m.ladder_override) ov.push('Gift ladder');
  s+='<div class="ms-row">'+tip('Overrides active','Manual overrides you set in the Advanced Options panel. Add-in = specific premium insert forced. Imagery = specific visual direction forced. Envelope = specific format forced. Gift ladder = specific ask amounts forced. Overrides take priority over data-driven recommendations.')+'<span class="ms-val sm">'+(ov.length?escH(ov.join(', ')):'None')+'</span></div>';
  s+='<div class="ms-row">'+tip('Gift ladder','The three ask amounts shown on the reply card in ascending order. Percentile-based by default: Low = p25, Mid = p50 (median), High = p75 of cluster gift amounts from ClusterGiftAmountDistribution. Falls back to mean-based math (0.5x / 1x / 2x of avg gift) when fewer than 30 transactions are available. Overridden if you entered custom amounts in the Ask Ladder fields.')+'<span class="ms-val ldr">$'+m.low+' / $'+m.mid+' / $'+m.high+'</span></div>';
  s+='</div>';

  document.getElementById('ms').innerHTML=s;
  renderWhyBox(m,p.label,revenuePerPiece,netPerPiece,benchmarkTag());
  renderProvenance(m);
}

function escH(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderWhyBox(m, postureLabel, revenuePerPiece, netPerPiece, benchmarkTag){
  var el=document.getElementById('whyBox');
  if(!m||!el){return;}
  var items=[];
  if(!m.no_cluster && m.best_appeal) items.push('Best benchmark appeal: '+m.best_appeal+' ('+benchmarkTag+')');
  if(!m.no_cluster && m.gift_timing && m.gift_timing.recommended && m.gift_timing.recommended.window) items.push('Timing recommendation: drop in '+m.gift_timing.recommended.window+' ahead of the '+m.gift_timing.peak.month_name+' peak');
  if(m.top_psychographic && m.top_psychographic_idx && m.top_psychographic_idx>=1.2) items.push('Creative anchor: '+m.top_psychographic+' at '+m.top_psychographic_idx.toFixed(2)+'x supports the concept direction');
  if(!m.no_cluster && (m.has_economics || m.has_real_roi)) items.push('Economics signal: '+(netPerPiece!=null?'net per piece $'+netPerPiece.toFixed(2):(revenuePerPiece!=null?'revenue per piece $'+revenuePerPiece.toFixed(2):'mailing cost grounded in historical economics')));
  if(!m.no_cluster && m.acquisition && (m.acquisition.weighted_year1_conversion!=null || m.acquisition.weighted_year2_conversion!=null || m.acquisition.weighted_lifetime_value!=null)) {
    var cohortBits=[];
    if(m.acquisition.weighted_year1_conversion!=null) cohortBits.push((parseFloat(m.acquisition.weighted_year1_conversion)*100).toFixed(1)+'% year-1 conversion');
    if(m.acquisition.weighted_year2_conversion!=null) cohortBits.push((parseFloat(m.acquisition.weighted_year2_conversion)*100).toFixed(1)+'% year-2 conversion');
    if(m.acquisition.weighted_lifetime_value!=null) cohortBits.push('$'+Math.round(parseFloat(m.acquisition.weighted_lifetime_value)).toLocaleString()+' weighted LTV');
    items.push('Cohort signal: '+cohortBits.join(' · '));
  }
  if(!m.no_cluster) items.push('Posture: '+postureLabel+' based on cluster score, timing, and cohort retention/acquisition signal');
  if(!m.no_cluster && m.lapse_prob!=null) items.push('Lapse risk: '+(parseFloat(m.lapse_prob)*100).toFixed(1)+'% — '+(parseFloat(m.lapse_prob)>=0.7?'high-value add-in prioritized to retain at-risk donors':parseFloat(m.lapse_prob)>=0.4?'moderate retention risk factored into concept':'low lapse risk — loyalty reinforcement appropriate'));
  items=items.slice(0,6);
  if(!items.length){el.style.display='none';el.innerHTML='';return;}
  el.style.display='block';
  el.innerHTML='<div class="why-title">Why this recommendation</div><ul class="why-list">'+items.map(function(x){return '<li>'+escH(x)+'</li>';}).join('')+'</ul>';
}

function renderProvenance(m){
  var el=document.getElementById('provStrip');
  if(!m||!el){return;}
  var chips=[['RFM',!!m.has_rfm],['Psychographics',!!m.has_psychographics],['Timing',!!m.has_timing],['Economics',!!m.has_economics],['Cohorts',!!m.has_cohorts],['ROI',!!m.has_roi]];
  el.style.display='block';
  el.innerHTML='<div class="prov-title">Data provenance</div><div class="prov-chips">'+chips.map(function(c){return '<span class="prov-chip'+(c[1]?' on':'')+'">'+c[0]+'</span>';}).join('')+'</div>';
}

function renderA(text, imagePrompt){
  var normalized=String(text||'')
    .replace(/\r?\n/g,'\n')
    .replace(/([^\n])\s+(##\s+)/g,'$1\n$2')
    .replace(/([^\n])(\*\*Curiosity-Led\*\*:|\*\*Emotion-Led\*\*:|\*\*Benefit-Led\*\*:|\*DIRECTIONAL DRAFT\*|\*\(Directional Draft\)\*)/g,'$1\n$2')
    .replace(/([^\n])(Package format:)/g,'$1\n$2')
    .replace(/(?:^|\n)\s*(?:##\s*)?Appeal Package Image Prompt\s*:?\s*/gi,'\n## Appeal Package Image Prompt\n');
  var sections=[], current=null, ln=normalized.split(NL);
  BP='';
  function pushCurrent(){ if(current) sections.push(current); }
  for(var i=0;i<ln.length;i++){
    var l=ln[i];
    if(l.indexOf('## ')===0){ pushCurrent(); current={heading:l.slice(3).trim(),lines:[]}; continue; }
    if(current) current.lines.push(l);
  }
  pushCurrent();

  var imageSectionIndex=-1;
  for(var i=0;i<sections.length;i++){
    var normalizedHeading=String(sections[i].heading||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    if(normalizedHeading==='appeal package image prompt'){
      imageSectionIndex=i;
      break;
    }
  }

  if(imageSectionIndex>0){
    var prevJoined=sections[imageSectionIndex-1].lines.join(NL)
      .replace(/\s*Package format:\s*[\s\S]*$/i,'')
      .replace(/\s+$/,'');
    sections[imageSectionIndex-1].lines=prevJoined?prevJoined.split(NL):[];
  } else {
    for(var si=0;si<sections.length;si++){
      var joined=sections[si].lines.join(NL);
      var headingMatch=joined.match(/(?:^|\n)\s*(?:##\s*)?Appeal Package Image Prompt\s*:?\s*\n?([\s\S]*)$/i);
      if(headingMatch){
        var beforeHeading=joined.slice(0, headingMatch.index).replace(/\s+$/,'');
        sections[si].lines=beforeHeading?beforeHeading.split(NL):[];
        sections.push({heading:'Appeal Package Image Prompt',lines:headingMatch[1].split(NL)});
        break;
      }
      var packageMatch=joined.match(/(?:^|\n)\s*(Package format:\s*[\s\S]*?(?:Professional product photography, photorealistic\.?|$))/i);
      if(packageMatch){
        var beforePackage=joined.slice(0, packageMatch.index).replace(/\s+$/,'');
        sections[si].lines=beforePackage?beforePackage.split(NL):[];
        sections.push({heading:'Appeal Package Image Prompt',lines:packageMatch[1].split(NL)});
        break;
      }
    }
  }

  var NO_BULLET_SECTIONS=['Envelope Teaser Options'];
  function stripBulletPrefix(l){
    if(l.length>1&&(l[0]==='*'||l[0]==='-')&&l[1]===' ') return l.slice(2).replace(/^•\s*/,'');
    if(l.length>1&&l[0]==='•'&&l[1]===' ') return l.slice(2);
    if(l.trim()==='•') return '';
    return l;
  }
  function renderLines(lines, noBullets){
    var html='', inL=false;
    for(var i=0;i<lines.length;i++){
      var l=lines[i];
      if(noBullets){
        var stripped=stripBulletPrefix(l);
        if(stripped.trim()==='') continue;
        html+='<p>'+bold(stripped)+'</p>';
        continue;
      }
      if(l.trim()==='•'){ continue; }
      if(l.length>1&&(l[0]==='*'||l[0]==='-')&&l[1]===' '){
        if(!inL){html+='<ul>';inL=true;}
        var content=l.slice(2).replace(/^•\s*/,'');
        html+='<li>'+bold(content)+'</li>';
      } else if(l.length>1&&l[0]==='•'&&l[1]===' '){
        if(!inL){html+='<ul>';inL=true;}
        html+='<li>'+bold(l.slice(2))+'</li>';
      } else if(l.trim()===''){
        if(inL){html+='</ul>';inL=false;}
      } else {
        if(inL){html+='</ul>';inL=false;}
        html+='<p>'+bold(l)+'</p>';
      }
    }
    if(inL) html+='</ul>';
    return html;
  }
  function normalizeHeading(name){ return String(name||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim(); }
  function sectionByName(name){
    var target=normalizeHeading(name);
    for(var i=0;i<sections.length;i++) if(normalizeHeading(sections[i].heading)===target) return sections[i];
    return null;
  }
  function extractImagePromptFallback(rawText){
    var raw=String(rawText||'').replace(/\r?\n/g,'\n');
    var match=raw.match(/(?:^|\n)##\s*Appeal Package Image Prompt\s*\n([\s\S]*?)(?=\n##\s+|$)/i);
    if(match&&match[1].trim()) return match[1].trim();
    match=raw.match(/(Package format:[\s\S]*?Professional product photography, photorealistic\.?)/i);
    return match&&match[1]?match[1].trim():'';
  }
  function renderGroup(title, names, openByDefault, note){
    var inner='';
    for(var i=0;i<names.length;i++){
      var sec=sectionByName(names[i]);
      if(!sec) continue;
      var nb=NO_BULLET_SECTIONS.indexOf(sec.heading)!==-1;
      inner+='<div class="ao-block"><h3>'+escH(sec.heading)+'</h3>'+renderLines(sec.lines,nb)+'</div>';
    }
    if(!inner) return '';
    return '<details class="ao-acc"'+(openByDefault?' open':'')+'><summary>'+title+'</summary><div class="ao-acc-body">'+(note?'<div class="ao-muted-note">'+note+'</div>':'')+inner+'</div></details>';
  }

  var html='';
  html+=renderGroup('Creative Concept',['Theme','Imagery','Color Palette','Premium Add-In'],true,'');
  html+=renderGroup('Copy Direction',['Envelope Teaser Options','Letter Opening','Call to Action'],true,'');
  html+=renderGroup('Strategy Brief',['Inspired By','Target Cluster Summary','Rationale','Testing Notes'],true,'');
  document.getElementById('ao').innerHTML=html;

  var suppliedImagePrompt=String(imagePrompt||'').trim();
  var imageSec=sectionByName('Appeal Package Image Prompt');
  BP=suppliedImagePrompt || (imageSec?imageSec.lines.filter(function(x){return x.trim();}).join(' '):extractImagePromptFallback(text));
  BP=String(BP||'').replace(/\*\*/g,'').trim();
  document.getElementById('pw').style.display='block';
  if(BP){
    document.getElementById('bt').textContent=BP;
    document.getElementById('bb').style.display='block';
  } else {
    document.getElementById('bt').textContent='';
    document.getElementById('bb').style.display='none';
  }
}

function copyM(){doCopy('mb','mt');}
function copyB(){doCopy('bb2','bt');}
function doCopy(bi,ti){
  var t=document.getElementById(ti).textContent;
  var b=document.getElementById(bi);
  navigator.clipboard.writeText(t).then(function(){
    b.textContent='Copied!'; b.className='cb ok';
    setTimeout(function(){b.textContent='Copy';b.className='cb';},2000);
  });
}

function dlA(){
  if(!T||!M) return;
  var c='Boys Town Appeal Generator'+NL;
  c+='Cluster: '+M.cluster+NL;
  if(M.mail_date) c+='Mail Date: '+M.mail_date+NL;
  if(M.last_package) c+='Last Package: '+M.last_package+NL;
  if(M.theme) c+='Creative Direction: '+M.theme+NL;
  if(!M.no_cluster){
    c+='Best Performer: '+M.best_appeal+NL;
    c+='RFM Score: '+M.best_score+NL;
    if(M.gift_timing && M.gift_timing.peak && M.gift_timing.peak.month_name) c+='Peak giving month: '+M.gift_timing.peak.month_name+NL;
    if(M.gift_timing && M.gift_timing.recommended && M.gift_timing.recommended.window) c+='Recommended drop: '+M.gift_timing.recommended.window+NL;
    if(M.has_economics && M.economics_pieces) c+='Pieces mailed (economics): '+M.economics_pieces.toLocaleString()+NL;
    if(M.has_economics && M.economics_cost_per_piece!=null) c+='Cost per piece (economics): $'+parseFloat(M.economics_cost_per_piece).toFixed(2)+NL;
    if(M.has_economics && M.economics_total_mail_cost!=null) c+='Mail cost (economics): $'+Math.round(parseFloat(M.economics_total_mail_cost)).toLocaleString()+NL;
    if(!M.has_economics && M.cost_per_piece) c+='Cost per piece: $'+M.cost_per_piece.toFixed(2)+NL;
    if(M.has_real_roi && M.real_pieces) c+='Pieces mailed (verified): '+M.real_pieces.toLocaleString()+NL;
    if(M.has_real_roi && M.real_cost) c+='Mail cost (verified): $'+Math.round(M.real_cost).toLocaleString()+NL;
    if(M.has_real_roi && M.real_revenue) c+='Revenue (verified): $'+Math.round(M.real_revenue).toLocaleString()+NL;
    if(M.has_real_roi && M.real_net_return!==null) c+='Net return (verified): $'+Math.round(M.real_net_return).toLocaleString()+NL;
    if(M.has_real_roi && M.real_roi_pct!==null) c+='ROI (verified): '+Math.round(M.real_roi_pct)+'%'+NL;
  }
  if(M.acquisition && M.acquisition.weighted_year1_conversion!=null) c+='Year-1 conversion: '+(parseFloat(M.acquisition.weighted_year1_conversion)*100).toFixed(1)+'%'+NL;
  if(M.acquisition && M.acquisition.weighted_lifetime_value!=null) c+='Weighted cohort LTV: $'+Math.round(parseFloat(M.acquisition.weighted_lifetime_value)).toLocaleString()+NL;
  c+='Ladder: $'+M.low+' / $'+M.mid+' / $'+M.high+NL+NL;
  var cleanT=T;
  var imgMarker='## Appeal Package Image Prompt';
  var firstIdx=cleanT.indexOf(imgMarker);
  var secondIdx=cleanT.indexOf(imgMarker, firstIdx+1);
  if(secondIdx>-1) cleanT=cleanT.substring(0,secondIdx).trimEnd();
  c+=cleanT;
  var b=new Blob([c],{type:'text/plain'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(b);
  a.download='appeal_'+(M.no_cluster?'creative_direction':M.cluster.replace(/ /g,'_'))+'.txt';
  a.click();
}
</script>
</div><!-- /main -->
</div><!-- /tab-generator -->

<div id="tab-datasources" class="tab-pane">
<div class="ds-wrap">
  <h2>Data Sources &amp; Model Lineage</h2>
  <p class="ds-sub">Every recommendation this platform makes is traceable to a specific BigQuery table and methodology.</p>
  <table class="ds-table">
    <thead><tr><th>Table</th><th>Type</th><th>What It Powers</th></tr></thead>
    <tbody>
      <tr><td>AppealClusterPerformance_AgentReady</td><td><span class="ds-badge live">Historical</span></td><td>RFM scores, response rates, and avg gift amounts per appeal per cluster. Powers best/worst performer selection, gift ladder defaults, the 555 creative rule, and the underperforming cluster rule (best appeal score &lt;3.0 triggers net-new ideation).</td></tr>
      <tr><td>ClusterRFM</td><td><span class="ds-badge derived">Derived</span></td><td>Global cluster health scores (R×0.20 + F×0.40 + M×0.40). Powers the Cluster Composite star rating and dropdown ranking. Clusters with rfm_composite_score &lt;3.0 are flagged Underperforming in the filter pills.</td></tr>
      <tr><td>AppealClusterROI</td><td><span class="ds-badge live">Historical</span></td><td>Verified historical financial outcomes by appeal and cluster. Primary source for realized revenue, net return, and ROI when a matching row exists.</td></tr>
      <tr><td>AddInClusterPerformance</td><td><span class="ds-badge derived">Derived</span></td><td>Observed add-in test results by cluster. The app only treats rows with at least 200 targeted and 5 distinct appeals as stronger evidence. Baseline lift is shown only when a real no-add-in row exists.</td></tr>
      <tr><td>ClusterPsychographicProfile</td><td><span class="ds-badge live">Historical</span></td><td>Behavioral interest indexes and household indicators by cluster. Meaningful nulls are preserved. Powers creative anchoring and caution zones for low-index interests.</td></tr>
      <tr><td>ClusterGiftTimingProfile</td><td><span class="ds-badge derived">Derived</span></td><td>Monthly giving distribution by cluster. Used to identify peak giving months and suggest a historical mail window 6–8 weeks before peak when timing data exists.</td></tr>
      <tr><td>ClusterGiftAmountDistribution</td><td><span class="ds-badge derived">Derived</span></td><td>Per-cluster gift amount distribution (mean, median, p25, p75, p90) from transaction data in the 24-month window. Drives the gift ladder (p25 / p50 / p75) when distribution confidence is high or medium (30+ transactions). Low-confidence clusters fall back to the mean-based ladder math.</td></tr>
      <tr><td>ClusterGeographicProfile</td><td><span class="ds-badge derived">Derived</span></td><td>State-level donor concentration and active giving rates per cluster. Surfaces top states by donor count, concentration vs. diffuse creative guidance (top-3 states &ge;50% triggers regional imagery), and an under-responsive market flag for states with high donor counts but below-average active rates.</td></tr>
      <tr><td>DonorLapseScores</td><td><span class="ds-badge model">Predictive</span></td><td>Donor-level lapse scores aggregated up to the cluster. The app uses average lapse probability as the primary metric and percent predicted-lapse as support — never a single donor row as cluster truth.</td></tr>
      <tr><td>DonorUpgradeScores</td><td><span class="ds-badge model">Predictive</span></td><td>Donor-level upgrade scores aggregated up to the cluster. Used as supporting signal only; it does not override weak historical appeal performance.</td></tr>
      <tr><td>AppealMailingEconomics</td><td><span class="ds-badge live">Historical</span></td><td>Mailed volume and cost context by appeal and cluster. Zero or unusable cost rows are not treated as ROI evidence. This table supports piece-count and cost context only.</td></tr>
      <tr><td>DonorAcquisitionCohorts</td><td><span class="ds-badge derived">Derived</span></td><td>Donor-level acquisition cohort table. Aggregated lightly into weighted year-1/year-2 conversion and lifetime value metrics, and only surfaced when at least 30 donor rows exist.</td></tr>
      <tr><td>Discovery Engine / Knowledge Base</td><td><span class="ds-badge rules">Rules</span></td><td>General appeal rules, proven creative references, and fallback guidance. Optional but used whenever available, especially in no-cluster or degraded-data scenarios.</td></tr>
      <tr><td>appeal_creative_library_complete.txt</td><td><span class="ds-badge local">Local</span></td><td>Optional local creative reference file loaded at startup when present. Used to enrich top-performer and worst-performer creative pattern analysis.</td></tr>
    </tbody>
  </table>
  <div class="ds-note"><strong style="color:var(--gl)">Data caveats:</strong> Response rates in this app are historical cluster/appeal signals and should be interpreted in the context of the source table windows rather than as guaranteed forward performance. Add-in results below 200 targeted or 5 distinct appeals are treated as directional only. Acquisition cohorts are suppressed below 30 donor rows. AppealMailingEconomics zero-cost rows are not used to imply ROI. Verified financial recommendations come from AppealClusterROI, while Discovery Engine and the local creative library provide fallback rules and creative context when hard historical support is thin.</div>
</div>
</div><!-- /tab-datasources -->

</body>
</html>"""

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        password = request.form.get('password', '')
        if _BT_PASSWORD and password == _BT_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            error = 'Incorrect password. Please try again.'
    return render_template_string(LOGIN_HTML, error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Boys Town Appeal Generator — Login</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #0d1b2a;
    font-family: 'Segoe UI', system-ui, sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .login-card {
    background: #1a2a3a;
    border: 1px solid #2a3a4a;
    border-radius: 12px;
    padding: 48px 40px 40px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  }
  .logo-row {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 32px;
  }
  .logo-box {
    width: 44px;
    height: 44px;
    background: #f5a623;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 18px;
    color: #0d1b2a;
    flex-shrink: 0;
  }
  .logo-text h1 {
    font-size: 16px;
    font-weight: 700;
    color: #ffffff;
    line-height: 1.2;
  }
  .logo-text p {
    font-size: 10px;
    color: #f5a623;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    margin-top: 2px;
  }
  .login-card h2 {
    font-size: 20px;
    font-weight: 600;
    color: #ffffff;
    margin-bottom: 8px;
  }
  .login-card .subtitle {
    font-size: 13px;
    color: #8899aa;
    margin-bottom: 28px;
  }
  label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: #aabbcc;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    margin-bottom: 8px;
  }
  input[type=password] {
    width: 100%;
    background: #0d1b2a;
    border: 1px solid #2a3a4a;
    border-radius: 6px;
    padding: 12px 14px;
    font-size: 15px;
    color: #ffffff;
    outline: none;
    transition: border-color 0.2s;
    margin-bottom: 20px;
  }
  input[type=password]:focus { border-color: #f5a623; }
  .error-msg {
    background: rgba(220,53,69,0.15);
    border: 1px solid rgba(220,53,69,0.4);
    border-radius: 6px;
    color: #ff6b7a;
    font-size: 13px;
    padding: 10px 14px;
    margin-bottom: 20px;
  }
  button[type=submit] {
    width: 100%;
    background: #f5a623;
    color: #0d1b2a;
    border: none;
    border-radius: 6px;
    padding: 13px;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    cursor: pointer;
    transition: background 0.2s;
  }
  button[type=submit]:hover { background: #e09510; }
</style>
</head>
<body>
<div class="login-card">
  <div class="logo-row">
    <div class="logo-box">BT</div>
    <div class="logo-text">
      <h1>Boys Town Appeal Generator</h1>
      <p>AI-Powered Donor Appeals</p>
    </div>
  </div>
  <h2>Welcome back</h2>
  <p class="subtitle">Enter your team password to continue.</p>
  {% if error %}<div class="error-msg">{{ error }}</div>{% endif %}
  <form method="POST">
    <label for="password">Password</label>
    <input type="password" id="password" name="password" autofocus placeholder="Enter password">
    <button type="submit">Sign In</button>
  </form>
</div>
</body>
</html>"""

@app.route('/clusters')
@require_login
def clusters_endpoint():
    return jsonify(CLUSTERS)

@app.route('/')
@require_login
def index():
    return render_template_string(HTML, clusters=CLUSTERS)

@app.route('/cluster_rfm')
@require_login
def cluster_rfm_endpoint():
    try:
        stats = fetch_cluster_stats()
        rfm_map = {}
        for row in stats:
            rfm_map[row['cluster']] = {'r': int(row.get('r_score') or 0), 'f': int(row.get('f_score') or 0), 'm': int(row.get('m_score') or 0)}
        return jsonify(rfm_map)
    except Exception:
        return jsonify({'error': 'Unable to load cluster RFM data right now.'}), 500

@app.route('/cluster_stats')
@require_login
def cluster_stats_endpoint():
    try:
        stats = fetch_cluster_stats()
        return jsonify(stats)
    except Exception:
        return jsonify({'error': 'Unable to load cluster stats right now.'}), 500

def split_generated_output(text):
    raw = str(text or '').strip()
    if not raw:
        return '', '', ''

    heading_match = re.search(r'(?im)^\s*##\s*Appeal Package Image Prompt\s*(?:\n|$)', raw)
    if heading_match:
        appeal_text = raw[:heading_match.start()].rstrip()
        image_prompt = raw[heading_match.end():].strip()
    else:
        fallback_match = re.search(
            r'(?is)(Package format:\s*[\s\S]*?Flat-lay product photography blueprint[\s\S]*)$',
            raw,
        )
        if fallback_match:
            appeal_text = raw[:fallback_match.start()].rstrip()
            image_prompt = fallback_match.group(1).strip()
        else:
            appeal_text = raw
            image_prompt = ''

    appeal_text = re.sub(
        r'(?is)\s*Package format:\s*[^\n]+?\s+Rationale:\s*[^\n]+(?=\s*$)',
        '',
        appeal_text,
    ).rstrip()
    return appeal_text, image_prompt, raw

@app.route('/generate', methods=['POST'])
@require_login
def generate_endpoint():
    data = request.get_json(silent=True)
    if data is None:
        data = {}
    if not isinstance(data, dict):
        return jsonify({'error': 'Request body must be a JSON object.', 'error_code': 'invalid_payload'}), 400
    cluster = data.get('cluster', '')
    theme = clean_text_input(data.get('theme', ''), 140)
    mail_date = clean_text_input(data.get('mail_date', ''), 40)
    last_package = clean_text_input(data.get('last_package', ''), 140)
    no_rules = normalize_bool(data.get('no_rules', False))
    addin_override = clean_text_input(data.get('addin_override', ''), 120)
    imagery_override = clean_text_input(data.get('imagery_override', ''), 300)
    envelope_format = clean_text_input(data.get('envelope_format', ''), 40)
    teaser_override = clean_text_input(data.get('teaser_override', ''), 200)
    ladder_low = clean_text_input(data.get('ladder_low', ''), 8)
    ladder_mid = clean_text_input(data.get('ladder_mid', ''), 8)
    ladder_high = clean_text_input(data.get('ladder_high', ''), 8)
    colors = data.get('colors', None)

    if cluster is None:
        return jsonify({'error': 'No cluster specified', 'error_code': 'invalid_payload'}), 400

    parsed_low, parsed_mid, parsed_high, ladder_ok = parse_ladder_override(ladder_low, ladder_mid, ladder_high)
    if any([ladder_low, ladder_mid, ladder_high]) and not ladder_ok:
        return jsonify({'error': 'Ask ladder must include valid Low, Mid, and High amounts in ascending order.', 'error_code': 'invalid_ladder_override'}), 400
    if colors is not None and normalize_color_triplet(colors) is None:
        return jsonify({'error': 'Color override must contain exactly three valid hex colors.', 'error_code': 'invalid_color_override'}), 400

    try:
        text, meta, error = generate(
            cluster, theme, mail_date, last_package,
            no_rules=no_rules,
            addin_override=addin_override, imagery_override=imagery_override,
            envelope_format=envelope_format, teaser_override=teaser_override,
            ladder_low=ladder_low, ladder_mid=ladder_mid, ladder_high=ladder_high,
            colors=colors
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"GENERATE_ENDPOINT_ERROR: {e}", flush=True)
        return jsonify({'error': 'Generation failed due to a temporary backend or model error.', 'error_code': 'backend_or_model_failure'}), 500

    if error:
        return jsonify({'error': error, 'error_code': 'generation_failed'}), 500
    appeal_text, image_prompt, full_text = split_generated_output(text)
    return jsonify({'text': appeal_text, 'image_prompt': image_prompt, 'full_text': full_text, 'meta': meta})

@app.route('/refine', methods=['POST'])
@require_login
def refine_endpoint():
    data = request.get_json(silent=True)
    if data is None:
        data = {}
    previous_output = data.get('previous_output', '')
    instruction = clean_text_input(data.get('instruction', ''), 500)
    meta = data.get('meta', {})

    if not previous_output or not instruction:
        return jsonify({'error': 'Refinement requires both a previous output and an instruction.', 'error_code': 'invalid_payload'}), 400

    try:
        text, error = refine(previous_output, instruction, meta)
    except Exception as e:
        print(f"REFINE_ENDPOINT_ERROR: {e}", flush=True)
        return jsonify({'error': 'Refinement failed due to a temporary backend or model error.', 'error_code': 'backend_or_model_failure'}), 500

    if error:
        return jsonify({'error': error, 'error_code': 'refinement_failed'}), 500
    appeal_text, image_prompt, full_text = split_generated_output(text)
    return jsonify({'text': appeal_text, 'image_prompt': image_prompt, 'full_text': full_text, 'meta': meta})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)
