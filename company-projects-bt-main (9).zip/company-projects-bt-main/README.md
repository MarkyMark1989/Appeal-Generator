# Boys Town Appeal Generator

An AI-powered direct mail fundraising appeal generator built for Boys Town, a national nonprofit dedicated to saving children and healing families. Developed as a capstone project for the OSU Master of Science in Business Analytics and Data Science (BAnDS) program.

---

## What It Does

Generates complete, data-driven direct mail appeal concepts in under 60 seconds. Select a Personicx donor cluster, optionally add a creative direction and mail date, and the app produces a full creative brief including:

- Campaign theme and imagery direction
- Color palette with hex codes
- Premium add-in recommendation (backed by historical A/B test data)
- Envelope teaser copy (3 options)
- Donor letter opening paragraph
- Gift ask ladder (data-driven from RFM performance)
- A/B testing hypotheses
- Flat-lay package image prompt for Vertex AI Studio

---

## Tech Stack

- **Backend:** Python / Flask
- **AI Model:** Gemini 2.5 Flash via Vertex AI
- **Data:** Google BigQuery (10 tables including RFM scores, psychographic profiles, gift timing, lapse/upgrade predictions, and mailing economics)
- **Knowledge Base:** Vertex AI Discovery Engine
- **Infrastructure:** Google Cloud Platform (Project: `bt25-468018`, Region: `us-central1`)

---

## Data Sources

| Table | What It Powers |
|---|---|
| AppealClusterPerformance_AgentReady | RFM scores, response rates, gift ladder defaults, 555 rule, underperforming cluster flag |
| ClusterRFM | Global cluster health scores and dropdown ranking |
| AppealClusterROI | Verified historical revenue and net return |
| AddInClusterPerformance | Historical add-in test results by cluster |
| ClusterPsychographicProfile | Behavioral interest indexes |
| ClusterGiftTimingProfile | Peak giving month and mail window recommendations |
| DonorLapseScores | Lapse risk by cluster |
| DonorUpgradeScores | Upgrade potential by cluster |
| AppealMailingEconomics | Mailing cost and volume context |
| DonorAcquisitionCohorts | Year-1/Year-2 conversion and lifetime value |

---

## Setup & Running the App

### 1. Clone the repo and install dependencies

```bash
git clone https://github.com/OSU-MSBAnDS/company-projects-bt.git
cd company-projects-bt
pip install -r requirements.txt
```

### 2. Authenticate with Google Cloud

```bash
gcloud auth application-default login
gcloud config set project bt25-468018
```

Run `gcloud auth application-default login` at the start of every Cloud Shell session — credentials expire frequently.

### 3. Set environment variables

```bash
export GOOGLE_CLOUD_PROJECT=bt25-468018
export BT_PASSWORD="your-shared-password-here"
export SECRET_KEY="your-secret-key-here"
unset GOOGLE_APPLICATION_CREDENTIALS
```

`BT_PASSWORD` controls login to the web app. `SECRET_KEY` secures Flask sessions — use any long random string. Contact the project team for the current password.

### 4. Start the app

```bash
python3 refactored/app.py
```

### 5. Open in browser

In Google Cloud Shell, click the **Web Preview** button (top-right of the terminal) and select **Preview on port 8080**. You will be prompted to log in with the password set in `BT_PASSWORD`.

> **Note:** The app runs in Google Cloud Shell. The preview URL changes each session and is only accessible while the Cloud Shell session is active.

---

## Login

The app requires a shared password set via the `BT_PASSWORD` environment variable. Contact the project team for the current password.

---

## Running Tests

```bash
cd ~/company-projects-bt
python3 -m pytest test_appeal_generator.py -v
python3 -m pytest test_integration.py -v
```

---

## Repository Structure

```
company-projects-bt/
├── refactored/                  # Primary maintained version (source of truth)
│   ├── app.py
│   ├── queries.py
│   ├── prompts.py
│   ├── enforcement.py
│   ├── utils.py
│   ├── templates/
│   │   └── index.html
│   └── tests/
├── boys-town-appeal-generator.py   # Legacy single-file backup (reference only)
├── requirements.txt
├── appeal_rules_lean.txt           # Knowledge base source — upload to Discovery Engine
├── appeal_creative_library_complete.txt
└── README.md
```

---

## Team

OSU MSBAnDS Graduate Capstone Team — Spring 2026

---

## Version Notes

The `refactored/` directory is the primary maintained version and source of truth. The single-file `boys-town-appeal-generator.py` is kept in sync as a backup and is patched alongside the refactored version in every commit.
