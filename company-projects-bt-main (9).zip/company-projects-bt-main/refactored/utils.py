import re
import logging

logger = logging.getLogger(__name__)

PROVEN_ADDIN_LIBRARY = [
    "wall calendar", "desk calendar", "old farmer's almanac", "almanac",
    "hardcover journal", "journal", "prayer journal", "prayer cards",
    "devotional note cards", "note card set", "seasonal note card set",
    "recipe card set", "recipe cards", "small cookbook", "cookbook",
    "address label sheets", "address labels", "notepad", "seed packet",
    "gift tags", "ornament", "puzzle cards", "bookmark",
    "magnetic bookmark", "calendar bookmark", "ruler bookmark",
    "wallet calendar card", "pocket notebook", "planner",
    "certificate of acknowledgment", "socks", "gloves"
]

VALID_ENVELOPE_FORMATS = {
    "9x12 flat mailer": "9x12 flat mailer",
    "9x12 flat": "9x12 flat mailer",
    "9x12 flat (9 x 12in)": "9x12 flat mailer",
    "6x9 envelope": "6x9 envelope",
    "6x9 booklet": "6x9 envelope",
    "6x9 booklet (6 x 9in)": "6x9 envelope",
    "7.5x3.875in monarch": "7.5x3.875in Monarch",
    "monarch": "7.5x3.875in Monarch",
    "monarch (3.875 x 7.5in)": "7.5x3.875in Monarch",
    "9.5x4.125in #10 standard": "9.5x4.125in #10 standard",
    "#10 standard": "9.5x4.125in #10 standard",
    "#10 standard (4.125 x 9.5in)": "9.5x4.125in #10 standard",
}

def extract_code(appeal_name):
    match = re.search(r'54120\s*-\s*(\d{4})\s*-', str(appeal_name))
    return match.group(1) if match else None

def fmt_pct(value, digits=1):
    if value is None or value == "":
        return "N/A"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "N/A"
    if abs(v) <= 1:
        v *= 100
    return f"{v:.{digits}f}%"

def pct_number(value):
    if value is None or value == "":
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if abs(v) <= 1:
        v *= 100
    return v

def _safe_float(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

def _safe_int(value):
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None

def _clean_key(value):
    return re.sub(r"[^a-z0-9]", "", str(value).lower())

def _first_present(row, *candidates):
    if not row:
        return None
    normalized = {_clean_key(k): v for k, v in row.items()}
    for candidate in candidates:
        key = _clean_key(candidate)
        if key in normalized and normalized[key] not in (None, ""):
            return normalized[key]
    return None

def clean_text_input(value, max_len=160):
    if value is None:
        return ""
    value = re.sub(r"\s+", " ", str(value)).strip()
    value = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", value)
    return value[:max_len]

def normalize_hex_color(value):
    value = clean_text_input(value, max_len=7)
    if not value:
        return ""
    if not value.startswith('#'):
        value = '#' + value
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
        return value.upper()
    return ""

def normalize_color_triplet(colors):
    if not isinstance(colors, list) or len(colors) != 3:
        return None
    normalized = [normalize_hex_color(c) for c in colors]
    if all(normalized):
        return normalized
    return None

def normalize_envelope_format(value):
    value = clean_text_input(value, max_len=40)
    if not value:
        return ""
    return VALID_ENVELOPE_FORMATS.get(value.lower(), "")

def normalize_addin_override(value):
    value = clean_text_input(value, max_len=300)
    if not value:
        return ""
    lowered = value.lower()
    for item in sorted(PROVEN_ADDIN_LIBRARY, key=len, reverse=True):
        if item in lowered:
            return item.title().replace("'S", "'s")
    return value

def normalize_ladder_value(value):
    value = clean_text_input(value, max_len=8)
    if not value:
        return None
    digits = re.sub(r"[^0-9]", "", value)
    if not digits:
        return None
    amount = int(digits)
    if amount <= 0 or amount > 10000:
        return None
    return amount

def parse_ladder_override(low, mid, high):
    raw_values = [clean_text_input(low, 8), clean_text_input(mid, 8), clean_text_input(high, 8)]
    if not any(raw_values):
        return None, None, None, False
    amounts = [normalize_ladder_value(v) for v in raw_values]
    if None in amounts:
        return None, None, None, False
    if not (amounts[0] < amounts[1] < amounts[2]):
        return None, None, None, False
    return amounts[0], amounts[1], amounts[2], True

def normalize_bool(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(value, (int, float)):
        return bool(value)
    return False

