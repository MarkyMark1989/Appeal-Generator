import re
import logging

from google.cloud import bigquery
from google.cloud import discoveryengine_v1 as discoveryengine
import vertexai

try:
    from .utils import _safe_float, _safe_int, _clean_key, _first_present
except ImportError:
    from utils import _safe_float, _safe_int, _clean_key, _first_present

logger = logging.getLogger(__name__)

PROJECT = "bt25-468018"
LOCATION = "us-central1"

_VERTEX_INITIALIZED = False

_BQ_CLIENT = None

_SEARCH_CLIENT = None

_TABLE_COLUMNS_CACHE = {}

def ensure_vertex_ai():
    global _VERTEX_INITIALIZED
    if not _VERTEX_INITIALIZED:
        vertexai.init(project=PROJECT, location=LOCATION)
        _VERTEX_INITIALIZED = True

def get_bq_client():
    global _BQ_CLIENT
    if _BQ_CLIENT is None:
        _BQ_CLIENT = bigquery.Client(project=PROJECT)
    return _BQ_CLIENT

def get_search_client():
    global _SEARCH_CLIENT
    if _SEARCH_CLIENT is None:
        _SEARCH_CLIENT = discoveryengine.SearchServiceClient()
    return _SEARCH_CLIENT

def fetch_rfm(cluster_name):
    client = get_bq_client()
    query = """
        SELECT Personicx_Cluster_Name, APPEALID, APPEAL_NAME,
               rfm_composite_score, rfm_score_3digit, r_score, f_score, m_score,
               avg_gift_amount, response_rate_pct, donors_responded_24mo,
               total_gift_amount, most_recent_gift_date, recency_days_24mo,
               Age_Range, MaritalStatus,
               HomeOwnership, Children, EstimatedHHIncomeAvg, EstimatedNetWorth,
               UrbanicityRural, UrbanicitySuburbsandTowns,
               UrbanicityCitiesandSurrounds, UrbanicityDowntownMetro,
               cluster_donor_count, COST
        FROM `bt25-468018.Boystown.AppealClusterPerformance_AgentReady`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
              AND UPPER(APPEAL_NAME) NOT LIKE '%ACKNOWLEDGEMENT%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%ACKNOWLEDGMENT%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%MARKETING%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%TEST%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%ADMIN%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%HOUSE FILE%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%DO NOT USE%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%DO NOT MAIL%'
              AND UPPER(APPEAL_NAME) NOT LIKE '%LAPSED%'
        ORDER BY rfm_composite_score DESC
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_cluster_stats():
    client = get_bq_client()
    query = """
        SELECT
            Personicx_Cluster_Name AS cluster,
            rfm_composite_score,
            r_score, f_score, m_score
        FROM `bt25-468018.Boystown.ClusterRFM`
        ORDER BY rfm_composite_score DESC
    """
    return [dict(r) for r in client.query(query).result()]

def classify_lapse_risk(avg_lapse_prob):
    if avg_lapse_prob is None:
        return None
    if avg_lapse_prob >= 0.70:
        return "High"
    if avg_lapse_prob >= 0.45:
        return "Medium"
    return "Low"

def classify_upgrade_potential(avg_upgrade_prob):
    if avg_upgrade_prob is None:
        return None
    if avg_upgrade_prob >= 0.70:
        return "High"
    if avg_upgrade_prob >= 0.45:
        return "Medium"
    return "Low"

def fetch_cluster_intelligence(cluster_name):
    """Fetch aggregated lapse risk and upgrade potential for the cluster."""
    client = get_bq_client()
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    lapse_rows = [dict(r) for r in client.query("""
        SELECT
            AVG(lapse_probability) AS avg_lapse_prob,
            AVG(CASE WHEN predicted_lapse_flag = 1 THEN 1.0 ELSE 0.0 END) AS pct_predicted_lapse,
            COUNT(*) AS donor_count
        FROM `bt25-468018.Boystown.DonorLapseScores`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
    """, job_config=job_config).result()]
    upgrade_rows = [dict(r) for r in client.query("""
        SELECT
            AVG(upgrade_probability) AS avg_upgrade_prob,
            AVG(cluster_upgrade_rate_pct) AS avg_cluster_upgrade_rate_pct,
            COUNT(*) AS donor_count
        FROM `bt25-468018.Boystown.DonorUpgradeScores`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
    """, job_config=job_config).result()]

    lapse_row = lapse_rows[0] if lapse_rows else {}
    upgrade_row = upgrade_rows[0] if upgrade_rows else {}
    lapse = _safe_float(lapse_row.get("avg_lapse_prob"))
    pct_predicted_lapse = _safe_float(lapse_row.get("pct_predicted_lapse"))
    upgrade = _safe_float(upgrade_row.get("avg_upgrade_prob"))
    cluster_upgrade_rate_pct = _safe_float(upgrade_row.get("avg_cluster_upgrade_rate_pct"))

    return {
        "lapse_prob": round(lapse, 3) if lapse is not None else None,
        "pct_predicted_lapse": round(pct_predicted_lapse, 3) if pct_predicted_lapse is not None else None,
        "lapse_label": classify_lapse_risk(lapse),
        "upgrade_prob": round(upgrade, 4) if upgrade is not None else None,
        "cluster_upgrade_rate_pct": round(cluster_upgrade_rate_pct, 4) if cluster_upgrade_rate_pct is not None else None,
        "upgrade_label": classify_upgrade_potential(upgrade),
    }

def fetch_psychographics(cluster_name):
    client = get_bq_client()
    query = """
        SELECT *
        FROM `bt25-468018.Boystown.ClusterPsychographicProfile`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows[0] if rows else {}

def fetch_program_affinity(cluster_name):
    client = get_bq_client()
    query = """
        SELECT program, fund, unique_donors, total_giving, avg_gift, pct_of_cluster_giving
        FROM `bt25-468018.Boystown.ClusterProgramAffinity`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND program != 'Unknown'
        ORDER BY total_giving DESC
        LIMIT 5
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_roi(cluster_name, best_appeal_name=None):
    """Fetch verified ROI for the RFM top performer appeal, as a projection baseline for the new appeal."""
    client = get_bq_client()

    if best_appeal_name:
        query = """
            SELECT APPEAL_NAME, pieces_mailed, cost_per_piece, total_mail_cost,
                   total_revenue, net_return, roi_pct, revenue_to_cost_ratio
            FROM `bt25-468018.Boystown.AppealClusterROI`
            WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
              AND LOWER(APPEAL_NAME) = LOWER(@appeal_name)
            LIMIT 1
        """
        job_config = bigquery.QueryJobConfig(query_parameters=[
            bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name),
            bigquery.ScalarQueryParameter("appeal_name", "STRING", best_appeal_name)
        ])
        rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
        if rows:
            return rows
    # Fallback: if best appeal not in ROI table, use highest RFM-adjacent appeal by rfm score
    query = """
        SELECT r.APPEAL_NAME, m.pieces_mailed, m.cost_per_piece, m.total_mail_cost,
               m.total_revenue, m.net_return, m.roi_pct, m.revenue_to_cost_ratio
        FROM `bt25-468018.Boystown.AppealClusterPerformance_AgentReady` r
        JOIN `bt25-468018.Boystown.AppealClusterROI` m
            ON LOWER(r.APPEALID) = LOWER(m.APPEALID)
            AND LOWER(r.Personicx_Cluster_Name) = LOWER(m.Personicx_Cluster_Name)
        WHERE LOWER(r.Personicx_Cluster_Name) = LOWER(@cluster_name)
        ORDER BY r.rfm_composite_score DESC
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def fetch_addin_performance(cluster_name):
    """Fetch observed add-in response rates for a cluster."""
    client = get_bq_client()
    query = """
        SELECT addin_category, response_rate_pct, avg_gift_when_responded,
               total_targeted, total_responded, distinct_appeals
        FROM `bt25-468018.Boystown.AddInClusterPerformance`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND addin_category NOT IN ('Other/Unclassified')
        ORDER BY response_rate_pct DESC
        LIMIT 8
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows

def fetch_gift_distribution(cluster_name):
    """Fetch per-cluster gift amount percentiles for ladder calibration."""
    client = get_bq_client()
    query = """
        SELECT txn_count_24mo, mean_gift, median_gift, p25_gift, p75_gift,
               p90_gift, mean_to_median_ratio, distribution_confidence
        FROM `bt25-468018.Boystown.ClusterGiftAmountDistribution`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows[0] if rows else None


def fetch_gift_distribution(cluster_name):
    """Fetch per-cluster gift amount percentiles for ladder calibration."""
    client = get_bq_client()
    query = """
        SELECT txn_count_24mo, mean_gift, median_gift, p25_gift, p75_gift,
               p90_gift, mean_to_median_ratio, distribution_confidence
        FROM `bt25-468018.Boystown.ClusterGiftAmountDistribution`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    rows = [dict(r) for r in client.query(query, job_config=job_config).result()]
    return rows[0] if rows else None

def fetch_geographic_profile(cluster_name):
    """Fetch top states by donor count for a cluster, with active rate and giving share."""
    client = get_bq_client()
    query = """
        SELECT State_Abbr, donor_count, active_donors_24mo, active_rate_pct,
               pct_of_cluster_donors, pct_of_cluster_revenue_24mo, avg_gift_amount
        FROM `bt25-468018.Boystown.ClusterGeographicProfile`
        WHERE LOWER(Personicx_Cluster_Name) = LOWER(@cluster_name)
          AND donor_count >= 50
        ORDER BY donor_count DESC
        LIMIT 5
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def get_table_columns(table_name):
    global _TABLE_COLUMNS_CACHE
    if table_name in _TABLE_COLUMNS_CACHE:
        return _TABLE_COLUMNS_CACHE[table_name]
    client = get_bq_client()
    query = """
        SELECT column_name
        FROM `bt25-468018.Boystown.INFORMATION_SCHEMA.COLUMNS`
        WHERE table_name = @table_name
        ORDER BY ordinal_position
    """
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("table_name", "STRING", table_name)
    ])
    cols = [r["column_name"] for r in client.query(query, job_config=job_config).result()]
    _TABLE_COLUMNS_CACHE[table_name] = cols
    return cols

def find_table_column(table_name, candidates):
    cols = get_table_columns(table_name)
    norm = {_clean_key(c): c for c in cols}
    for candidate in candidates:
        key = _clean_key(candidate)
        if key in norm:
            return norm[key]
    return None

def fetch_rows_by_cluster(table_name, cluster_name, limit=None, order_by=None):
    client = get_bq_client()
    cluster_col = find_table_column(table_name, [
        "Personicx_Cluster_Name", "personicx_cluster_name", "cluster", "cluster_name",
        "PersonicxClusterName", "Personicx Cluster Name"
    ])
    if not cluster_col:
        return []
    query = f"SELECT * FROM `bt25-468018.Boystown.{table_name}` WHERE LOWER(CAST(`{cluster_col}` AS STRING)) = LOWER(@cluster_name)"
    if order_by:
        query += f" ORDER BY {order_by}"
    if limit:
        query += f" LIMIT {int(limit)}"
    job_config = bigquery.QueryJobConfig(query_parameters=[
        bigquery.ScalarQueryParameter("cluster_name", "STRING", cluster_name)
    ])
    return [dict(r) for r in client.query(query, job_config=job_config).result()]

def _month_num_name(value):
    if value in (None, ""):
        return None, None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None, None
        try:
            month_num = int(float(raw))
            if 1 <= month_num <= 12:
                names = [None, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                return month_num, names[month_num]
        except ValueError:
            lowered = raw.lower()
            names = {
                "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
                "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12
            }
            for name, num in names.items():
                if lowered.startswith(name[:3]) or lowered == name:
                    return num, name.title()
            return None, raw.title()
    month_num = _safe_int(value)
    if month_num and 1 <= month_num <= 12:
        names = [None, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        return month_num, names[month_num]
    return None, None

def _relative_month_label(month_num, weeks_before):
    import datetime as _dt
    if not month_num:
        return None
    peak_date = _dt.date(_dt.date.today().year, month_num, 1)
    target = peak_date - _dt.timedelta(weeks=weeks_before)
    return target.strftime("%B %d")

def fetch_cluster_gift_timing(cluster_name):
    rows = fetch_rows_by_cluster("ClusterGiftTimingProfile", cluster_name, limit=36)
    if not rows:
        return None

    def _row_peak_tuple(row):
        row_month_num, row_month_name = _month_num_name(
            _first_present(row, "month_name", "month", "month_num", "month_number", "gift_month", "calendar_month")
        )
        row_pct = _safe_float(_first_present(row, "pct_of_annual_giving", "percent_of_annual_giving", "monthly_pct_of_annual", "share_of_annual_giving"))
        row_total = _safe_float(_first_present(row, "total_giving", "gift_amount", "monthly_total_giving", "month_total"))
        row_is_peak = _first_present(row, "is_peak_month", "peak_month_flag", "is_peak")
        if isinstance(row_is_peak, str):
            row_is_peak = row_is_peak.strip().lower() in {"true", "t", "1", "yes", "y"}
        else:
            row_is_peak = bool(row_is_peak)
        return {
            "month_num": row_month_num,
            "month_name": row_month_name,
            "pct": row_pct,
            "total": row_total,
            "is_peak": row_is_peak,
        }

    normalized_rows = [_row_peak_tuple(row) for row in rows if row]
    normalized_rows = [row for row in normalized_rows if row["month_name"]]

    if not normalized_rows:
        return None

    explicit_peaks = [row for row in normalized_rows if row["is_peak"]]
    candidate_rows = explicit_peaks if explicit_peaks else normalized_rows
    candidate_rows.sort(
        key=lambda row: (
            row["pct"] if row["pct"] is not None else float("-inf"),
            row["total"] if row["total"] is not None else float("-inf"),
            -(row["month_num"] or 99),
        ),
        reverse=True,
    )
    best_row = candidate_rows[0]

    month_num = best_row["month_num"]
    month_name = best_row["month_name"]
    pct = best_row["pct"]
    total = best_row["total"]

    if not month_name:
        return None

    mail_start = _relative_month_label(month_num, 8)
    mail_end = _relative_month_label(month_num, 6)
    return {
        "peak": {
            "month_num": month_num,
            "month_name": month_name,
            "pct_of_annual_giving": pct,
            "total_giving": total,
        },
        "recommended": {
            "label": f"Drop 6–8 weeks before the {month_name} peak",
            "window": f"{mail_start} to {mail_end}" if mail_start and mail_end else None,
        },
    }

def fetch_appeal_mailing_economics(cluster_name, best_row):
    rows = fetch_rows_by_cluster("AppealMailingEconomics", cluster_name, limit=200)
    if not rows:
        return None

    target_name = str(best_row.get("APPEAL_NAME") or "").strip().lower()
    target_id = str(best_row.get("APPEALID") or "").strip().lower()
    matched = None
    for row in rows:
        row_name = str(_first_present(row, "APPEAL_NAME", "appeal_name", "appeal") or "").strip().lower()
        row_id = str(_first_present(row, "APPEALID", "appeal_id") or "").strip().lower()
        if target_name and row_name and row_name == target_name:
            matched = row
            break
        if target_id and row_id and row_id == target_id:
            matched = row
            break
    if matched is None:
        matched = rows[0]

    pieces = _safe_int(_first_present(matched, "pieces_mailed", "mail_quantity", "piece_count", "quantity_mailed", "pieces", "unique_donors_mailed"))
    cpp = _safe_float(_first_present(matched, "cost_per_piece", "cpp", "mail_cost_per_piece", "unit_cost", "cost"))
    total_cost = _safe_float(_first_present(matched, "total_mail_cost", "mail_cost", "total_cost", "campaign_cost"))
    if total_cost is None and pieces is not None and cpp is not None and cpp > 0:
        total_cost = round(pieces * cpp, 2)

    usable_costs = bool((cpp is not None and cpp > 0) and (total_cost is not None and total_cost > 0) and (pieces is not None and pieces >= 50))
    return {
        "appeal_name": _first_present(matched, "APPEAL_NAME", "appeal_name", "appeal") or best_row.get("APPEAL_NAME"),
        "pieces_mailed": pieces,
        "cost_per_piece": cpp,
        "total_mail_cost": total_cost,
        "has_usable_costs": usable_costs,
        "row_count": len(rows),
    }

def fetch_acquisition_cohorts(cluster_name, best_row):
    rows = fetch_rows_by_cluster("DonorAcquisitionCohorts", cluster_name, limit=5000)
    if not rows:
        return None

    donor_rows = [row for row in rows if _first_present(row, "constituentid", "constituent_id") not in (None, "")]
    row_count = len(donor_rows) if donor_rows else len(rows)
    if row_count < 30:
        return {
            "source_row_count": row_count,
            "insufficient_rows": True,
        }

    yr1_numer = 0.0
    yr2_numer = 0.0
    total_ltv = 0.0
    giving_lifetime_after_first = 0.0
    first_gift_total = 0.0
    gifts_yr1_total = 0.0
    gifts_yr2_total = 0.0
    valid_ltv_rows = 0
    valid_after_first_rows = 0
    valid_first_gift_rows = 0
    appeal_counts = {}
    segment_counts = {}

    for row in donor_rows or rows:
        converted_yr1 = _safe_float(_first_present(row, "converted_yr1"))
        converted_yr2 = _safe_float(_first_present(row, "converted_yr2"))
        total_ltv_value = _safe_float(_first_present(row, "total_ltv"))
        giving_after_first = _safe_float(_first_present(row, "giving_lifetime_after_first"))
        first_gift_amount = _safe_float(_first_present(row, "first_gift_amount"))
        gifts_yr1 = _safe_float(_first_present(row, "gifts_yr1"))
        gifts_yr2 = _safe_float(_first_present(row, "gifts_yr2"))
        appeal_name = str(_first_present(row, "acquisition_appeal_name") or "").strip()
        acquisition_segment = str(_first_present(row, "acquisition_segment") or "").strip()

        if converted_yr1 is not None:
            yr1_numer += converted_yr1
        if converted_yr2 is not None:
            yr2_numer += converted_yr2
        if total_ltv_value is not None:
            total_ltv += total_ltv_value
            valid_ltv_rows += 1
        if giving_after_first is not None:
            giving_lifetime_after_first += giving_after_first
            valid_after_first_rows += 1
        if first_gift_amount is not None:
            first_gift_total += first_gift_amount
            valid_first_gift_rows += 1
        if gifts_yr1 is not None:
            gifts_yr1_total += gifts_yr1
        if gifts_yr2 is not None:
            gifts_yr2_total += gifts_yr2
        if appeal_name:
            appeal_counts[appeal_name] = appeal_counts.get(appeal_name, 0) + 1
        if acquisition_segment:
            segment_counts[acquisition_segment] = segment_counts.get(acquisition_segment, 0) + 1

    top_appeal = max(appeal_counts.items(), key=lambda item: item[1])[0] if appeal_counts else None
    top_segment = max(segment_counts.items(), key=lambda item: item[1])[0] if segment_counts else None

    return {
        "source_row_count": row_count,
        "insufficient_rows": False,
        "weighted_year1_conversion": round(yr1_numer / row_count, 4),
        "weighted_year2_conversion": round(yr2_numer / row_count, 4),
        "weighted_lifetime_value": round(total_ltv / valid_ltv_rows, 2) if valid_ltv_rows else None,
        "weighted_lifetime_after_first": round(giving_lifetime_after_first / valid_after_first_rows, 2) if valid_after_first_rows else None,
        "avg_first_gift_amount": round(first_gift_total / valid_first_gift_rows, 2) if valid_first_gift_rows else None,
        "avg_gifts_yr1": round(gifts_yr1_total / row_count, 2),
        "avg_gifts_yr2": round(gifts_yr2_total / row_count, 2),
        "top_acquisition_appeal_name": top_appeal,
        "top_acquisition_segment": top_segment,
    }

