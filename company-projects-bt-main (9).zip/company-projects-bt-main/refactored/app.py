import os
from functools import wraps
import secrets as _secrets
import logging
import re

from flask import Flask, render_template, request, jsonify, session, redirect, url_for

try:
    from .prompts import CLUSTERS, generate, refine
    from .queries import fetch_cluster_stats
    from .utils import clean_text_input, normalize_bool, normalize_color_triplet, parse_ladder_override
except ImportError:
    from prompts import CLUSTERS, generate, refine
    from queries import fetch_cluster_stats
    from utils import clean_text_input, normalize_bool, normalize_color_triplet, parse_ladder_override

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# ── Auth configuration ───────────────────────────────────────────────────────
app.secret_key = os.environ.get('SECRET_KEY') or _secrets.token_hex(32)
_BT_PASSWORD = os.environ.get('BT_PASSWORD')
if not os.environ.get('SECRET_KEY'):
    logger.warning("SECRET_KEY env var not set — using a random key. Sessions will not survive restarts.")
if not _BT_PASSWORD:
    raise RuntimeError("BT_PASSWORD env var is required.")

# ── Auth decorator ──────────────────────────────────────────────────────────
def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        session['logged_in'] = True  # LOGIN TEMPORARILY DISABLED
        return f(*args, **kwargs)
    return decorated


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        password = request.form.get('password', '')
        if _BT_PASSWORD and password == _BT_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            error = 'Incorrect password. Please try again.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/clusters')
@require_login
def clusters_endpoint():
    return jsonify(CLUSTERS)

@app.route('/')
@require_login
def index():
    return render_template('index.html', clusters=CLUSTERS)

@app.route('/cluster_rfm')
@require_login
def cluster_rfm_endpoint():
    try:
        stats = fetch_cluster_stats()
        rfm_map = {}
        for row in stats:
            rfm_map[row['cluster']] = {'r': int(row.get('r_score') or 0), 'f': int(row.get('f_score') or 0), 'm': int(row.get('m_score') or 0)}
        return jsonify(rfm_map)
    except Exception:
        return jsonify({'error': 'Unable to load cluster RFM data right now.'}), 500

@app.route('/cluster_stats')
@require_login
def cluster_stats_endpoint():
    try:
        stats = fetch_cluster_stats()
        return jsonify(stats)
    except Exception:
        return jsonify({'error': 'Unable to load cluster stats right now.'}), 500

def split_generated_output(text):
    raw = str(text or '').strip()
    if not raw:
        return '', '', ''

    heading_match = re.search(r'(?im)^\s*##\s*Appeal Package Image Prompt\s*(?:\n|$)', raw)
    if heading_match:
        appeal_text = raw[:heading_match.start()].rstrip()
        image_prompt = raw[heading_match.end():].strip()
    else:
        fallback_match = re.search(
            r'(?is)(Package format:\s*[\s\S]*?Flat-lay product photography blueprint[\s\S]*)$',
            raw,
        )
        if fallback_match:
            appeal_text = raw[:fallback_match.start()].rstrip()
            image_prompt = fallback_match.group(1).strip()
        else:
            appeal_text = raw
            image_prompt = ''

    appeal_text = re.sub(
        r'(?is)\s*Package format:\s*[^\n]+?\s+Rationale:\s*[^\n]+(?=\s*$)',
        '',
        appeal_text,
    ).rstrip()
    return appeal_text, image_prompt, raw

@app.route('/generate', methods=['POST'])
@require_login
def generate_endpoint():
    data = request.get_json(silent=True)
    if data is None:
        data = {}
    if not isinstance(data, dict):
        return jsonify({'error': 'Request body must be a JSON object.', 'error_code': 'invalid_payload'}), 400
    cluster = data.get('cluster', '')
    theme = clean_text_input(data.get('theme', ''), 140)
    mail_date = clean_text_input(data.get('mail_date', ''), 40)
    last_package = clean_text_input(data.get('last_package', ''), 140)
    no_rules = normalize_bool(data.get('no_rules', False))
    addin_override = clean_text_input(data.get('addin_override', ''), 120)
    imagery_override = clean_text_input(data.get('imagery_override', ''), 300)
    envelope_format = clean_text_input(data.get('envelope_format', ''), 40)
    teaser_override = clean_text_input(data.get('teaser_override', ''), 200)
    ladder_low = clean_text_input(data.get('ladder_low', ''), 8)
    ladder_mid = clean_text_input(data.get('ladder_mid', ''), 8)
    ladder_high = clean_text_input(data.get('ladder_high', ''), 8)
    colors = data.get('colors', None)

    if cluster is None:
        return jsonify({'error': 'No cluster specified', 'error_code': 'invalid_payload'}), 400

    parsed_low, parsed_mid, parsed_high, ladder_ok = parse_ladder_override(ladder_low, ladder_mid, ladder_high)
    if any([ladder_low, ladder_mid, ladder_high]) and not ladder_ok:
        return jsonify({'error': 'Ask ladder must include valid Low, Mid, and High amounts in ascending order.', 'error_code': 'invalid_ladder_override'}), 400
    if colors is not None and normalize_color_triplet(colors) is None:
        return jsonify({'error': 'Color override must contain exactly three valid hex colors.', 'error_code': 'invalid_color_override'}), 400

    try:
        text, meta, error = generate(
            cluster, theme, mail_date, last_package,
            no_rules=no_rules,
            addin_override=addin_override, imagery_override=imagery_override,
            envelope_format=envelope_format, teaser_override=teaser_override,
            ladder_low=ladder_low, ladder_mid=ladder_mid, ladder_high=ladder_high,
            colors=colors
        )
    except Exception as e:
        logger.exception("GENERATE_ENDPOINT_ERROR: %s", e)
        return jsonify({'error': 'Generation failed due to a temporary backend or model error.', 'error_code': 'backend_or_model_failure'}), 500

    if error:
        return jsonify({'error': error, 'error_code': 'generation_failed'}), 500
    appeal_text, image_prompt, full_text = split_generated_output(text)
    return jsonify({'text': appeal_text, 'image_prompt': image_prompt, 'full_text': full_text, 'meta': meta})

@app.route('/refine', methods=['POST'])
@require_login
def refine_endpoint():
    data = request.get_json(silent=True)
    if data is None:
        data = {}
    previous_output = data.get('previous_output', '')
    instruction = clean_text_input(data.get('instruction', ''), 500)
    meta = data.get('meta', {})

    if not previous_output or not instruction:
        return jsonify({'error': 'Refinement requires both a previous output and an instruction.', 'error_code': 'invalid_payload'}), 400

    try:
        text, error = refine(previous_output, instruction, meta)
    except Exception as e:
        logger.exception("REFINE_ENDPOINT_ERROR: %s", e)
        return jsonify({'error': 'Refinement failed due to a temporary backend or model error.', 'error_code': 'backend_or_model_failure'}), 500

    if error:
        return jsonify({'error': error, 'error_code': 'refinement_failed'}), 500
    appeal_text, image_prompt, full_text = split_generated_output(text)
    return jsonify({'text': appeal_text, 'image_prompt': image_prompt, 'full_text': full_text, 'meta': meta})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)
