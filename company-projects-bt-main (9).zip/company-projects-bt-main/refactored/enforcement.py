import re
import logging

try:
    from .utils import clean_text_input
except ImportError:
    from utils import clean_text_input

logger = logging.getLogger(__name__)

def split_sections(text):
    sections = []
    current_heading = None
    current_lines = []
    for line in _normalize_generated_layout(text).splitlines():
        if line.startswith("## "):
            if current_heading is not None:
                sections.append((current_heading, current_lines))
            current_heading = line[3:].strip()
            current_lines = []
        else:
            current_lines.append(line)
    if current_heading is not None:
        sections.append((current_heading, current_lines))
    return sections

def join_sections(sections):
    out = []
    for heading, lines in sections:
        out.append(f"## {heading}")
        out.extend(lines)
    return "\n".join(out).strip()
def _repair_missing_rationale_heading(text):
    if re.search(r"(?im)^##\s*Rationale\s*$", text):
        return text
    match = re.search(
        r"(?ims)^##\s*Target Cluster Summary\s*\n(?P<body>[\s\S]*?)(?=^##\s*(?:Testing Notes|Appeal Package Image Prompt)\s*$|\nPackage format:|\Z)",
        text,
    )
    if not match:
        return text
    body = match.group("body").strip()
    markers = [
        r"The creative concept",
        r"This creative concept",
        r"This concept",
        r"This appeal",
        r"We are rotating",
        r"Strategically",
        r"Mailing this package",
        r"By offering",
        r"The recommended mail window",
    ]
    split_at = None
    for marker in markers:
        cue = re.search(r"(?is)(?<=\.|\?|!)\s+(?=" + marker + r")", body)
        if cue:
            prefix = body[:cue.start()].strip()
            if len(re.findall(r"[.!?](?:\s|$)", prefix)) >= 4:
                split_at = cue.start()
                break
    if split_at is None:
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", body) if s.strip()]
        if len(sentences) >= 8:
            split_at = len(" ".join(sentences[:6]))
    if split_at is None:
        return text
    summary = body[:split_at].strip()
    rationale = body[split_at:].strip()
    if not summary or not rationale:
        return text
    replacement = f"## Target Cluster Summary\n{summary}\n## Rationale\n{rationale}\n"
    return text[:match.start()] + replacement + text[match.end():]

def _repair_missing_image_prompt_heading(text):
    if re.search(r"(?im)^##\s*Appeal Package Image Prompt\s*$", text) or "Package format:" not in text:
        return text
    return re.sub(r"\n(Package format:\s*)", r"\n## Appeal Package Image Prompt\n\1", text, count=1)

def _normalize_generated_layout(text):
    normalized = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    normalized = re.sub(r"([^\n])\s+(##\s+)", r"\1\n\2", normalized)
    normalized = re.sub(
        r"([^\n])(\*\*Curiosity-Led\*\*:|\*\*Emotion-Led\*\*:|\*\*Benefit-Led\*\*:|\*DIRECTIONAL DRAFT\*|\*\(Directional Draft\)\*)",
        r"\1\n\2",
        normalized,
    )
    normalized = re.sub(r"([^\n])(Package format:)", r"\1\n\2", normalized)
    normalized = _repair_missing_rationale_heading(normalized)
    normalized = _repair_missing_image_prompt_heading(normalized)
    return normalized.strip()
def enforce_cta_lines(lines, low, mid, high):
    nonblank = [ln for ln in lines if ln.strip()]
    targets = [low, mid, high]
    updated = []
    replaced = 0
    for line in nonblank:
        if replaced < 3 and re.search(r"\$\s*\d+", line):
            line = re.sub(r"\*\*\$\s*\d+[\d,]*\*\*|\$\s*\d+[\d,]*", f"**${targets[replaced]}**", line, count=1)
            replaced += 1
        updated.append(line)
    while replaced < 3:
        fallback = [
            f"**${low}** — Put care into motion for one child.",
            f"**${mid}** — Deepen steady support that helps a child grow.",
            f"**${high}** — Create lasting impact through sustained guidance and opportunity.",
        ][replaced]
        updated.append(fallback)
        replaced += 1
    return updated


def _swatch_instruction(palette):
    return (
        f'⑥ Color swatch strip along the right edge — render a single vertical column of solid rectangular swatches, using exactly one swatch for each UNIQUE approved campaign color and preserving the exact palette order already specified. '
        f'If the Color Palette contains three colors, render exactly three swatches; if it contains five colors, render exactly five swatches. Never repeat a color, never duplicate a hex code, never create a second swatch column, and never invent extra palette labels such as Primary, Secondary, or Accent unless those exact words already appear in the approved Color Palette. '
        f'Each swatch must contain the color name and hex code centered INSIDE the color block in clean sans-serif text, using high-contrast text for legibility (white text on dark swatches, deep charcoal text on light swatches). '
        f'Do not use bullets, no labels outside the swatches, no detached legend, and no separate annotation strip. Use only the exact palette already specified here: {palette}.'
    )

def enforce_rationale_lines(lines):
    paragraphs = [p.strip() for p in re.split(r'\n\s*\n+', '\n'.join(lines or [])) if p.strip()]
    if len(paragraphs) == 2:
        return [paragraphs[0], '', paragraphs[1]]
    if len(paragraphs) > 2:
        first = _normalize_single_line(paragraphs[0])
        second = _normalize_single_line(' '.join(paragraphs[1:]))
        return [first, '', second]

    collapsed = _normalize_single_line(' '.join([ln.strip() for ln in (lines or []) if ln and ln.strip()]))
    if not collapsed:
        return lines

    strategic_markers = [
        r'(?=\bStrategically\b)',
        r'(?=\bStrategic(?:ally)?\b)',
        r'(?=\bThis approach\b)',
        r'(?=\bWithout specific\b)',
        r'(?=\bMailing this package\b)',
        r'(?=\bWe rotated away\b)',
        r'(?=\bThe mail date\b)',
    ]
    for pattern in strategic_markers:
        match = re.search(pattern, collapsed)
        if match and match.start() > 80 and len(collapsed[match.start():]) > 80:
            first = collapsed[:match.start()].strip()
            second = collapsed[match.start():].strip()
            return [first, '', second]

    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', collapsed) if s.strip()]
    if len(sentences) >= 4:
        split_idx = max(2, len(sentences) // 2)
        if len(sentences) - split_idx < 2:
            split_idx = len(sentences) - 2
        first = ' '.join(sentences[:split_idx]).strip()
        second = ' '.join(sentences[split_idx:]).strip()
        return [first, '', second]
    if len(sentences) >= 2:
        return [' '.join(sentences[:1]).strip(), '', ' '.join(sentences[1:]).strip()]
    return [collapsed]

def _normalize_single_line(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()

def _section_map_from_sections(sections):
    return {heading: _normalize_single_line(" ".join(lines or [])) for heading, lines in sections}

def _extract_emotion_led_teaser(envelope_text):
    raw = str(envelope_text or "")
    patterns = [
        r"Emotion-Led\*\*\s*[:\-]\s*(.+?)(?=\*\*[A-Za-z]|$)",
        r"Emotion-Led\s*[:\-]\s*(.+?)(?=(?:\*\*)?(?:Benefit-Led|Curiosity-Led)|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw, flags=re.IGNORECASE)
        if match:
            return _normalize_single_line(match.group(1).strip(" *"))
    return ""

def _extract_theme_headline(theme_text):
    raw = str(theme_text or "")
    for line in raw.splitlines():
        line = line.strip()
        if line:
            return line
    raw = _normalize_single_line(raw)
    return raw.split(". ")[0].strip() if raw else "the campaign theme"

def _infer_package_format(addin_text, cluster_summary_text, original_text):
    original = str(original_text or "")
    addin_raw = str(addin_text or "")
    cluster_raw = str(cluster_summary_text or "")
    combined = f"{addin_raw} {cluster_raw}".lower()

    dims = []
    for a, b in re.findall(r"(\d+(?:\.\d+)?)\s*x\s*(\d+(?:\.\d+)?)", addin_raw):
        dims.append(tuple(sorted((float(a), float(b)))))
    max_short = max((d[0] for d in dims), default=0.0)
    max_long = max((d[1] for d in dims), default=0.0)

    multi_insert = bool(
        re.search(r"\(1\)|\(2\)|\(3\)|\(4\)|multi[- ]insert|set of\s+\d+|matching envelopes|sheet of personalized return address labels", combined)
    )

    bulky_terms = ["wall calendar", "large almanac", "old farmer's almanac", "bulky", "multiple books"]
    premium_terms = ["desk calendar", "hardcover journal", "journal", "note card", "note cards", "greeting card", "greeting cards", "recipe card set", "seed packet", "seed packets", "bookmark", "bookmarks", "labels", "return address labels"]

    if any(term in combined for term in bulky_terms) or max_long >= 8.5 or max_short >= 5.5:
        recommended = (
            "9x12 flat mailer outer, 4x9in reply card",
            "selected to protect a bulky or oversized premium package and keep every component flat and presentation-ready.",
        )
    elif any(term in combined for term in premium_terms) or multi_insert or max_long >= 5.25 or max_short >= 4.0 or re.search(r"\$\s*100k|100,?000|affluent|high-income|high income|net worth", combined):
        recommended = (
            "6x9 envelope outer, 4x9in reply card",
            "selected to fit a premium insert package cleanly while maintaining a polished presentation.",
        )
    elif any(term in combined for term in ["senior", "faith", "reactivation", "lapsed"]):
        recommended = (
            "7.5x3.875in Monarch outer, 3.5x8.5in reply card",
            "selected to create a more personal, intimate direct-mail feel.",
        )
    else:
        recommended = (
            "9.5x4.125in #10 standard outer, 3.5x8.5in reply card",
            "selected as the default format for a slim standard direct-mail package.",
        )

    existing = re.search(
        r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)",
        original,
        flags=re.IGNORECASE,
    )
    if existing:
        existing_format = _normalize_single_line(existing.group(1))
        existing_rationale = _normalize_single_line(existing.group(2))
        existing_lower = existing_format.lower()
        recommended_format = recommended[0].lower()

        if (
            (("#10" in existing_lower or "9.5x4.125" in existing_lower) and recommended_format != "9.5x4.125in #10 standard outer, 3.5x8.5in reply card")
            or ("6x9" in existing_lower and recommended_format.startswith("9x12"))
        ):
            return recommended
        return existing_format, existing_rationale

    return recommended

def _split_sentences(value):
    text = str(value or "").strip()
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+", text)
    return [p.strip() for p in parts if p.strip()]

def _extract_primary_scene(imagery_text, theme_text=""):
    imagery_sentences = _split_sentences(imagery_text)
    if imagery_sentences:
        return imagery_sentences[0]
    theme_sentences = _split_sentences(theme_text)
    if len(theme_sentences) > 1:
        return theme_sentences[1]
    if theme_sentences:
        return theme_sentences[0]
    return "children in a hopeful, mission-centered Boys Town moment"

def _extract_support_scene(imagery_text, primary_scene=""):
    imagery_sentences = _split_sentences(imagery_text)
    for sentence in imagery_sentences[1:]:
        if _normalize_loose_text(sentence) != _normalize_loose_text(primary_scene):
            return sentence
    return primary_scene

def _extract_child_reference(letter_opening):
    text = str(letter_opening or "")
    match = re.search(r"\b([A-Z][a-z]{2,})\b", text)
    if match:
        candidate = match.group(1)
        if candidate.lower() not in {"boys", "town", "dear", "today", "because", "when", "with", "your", "this"}:
            return candidate
    return "the same story moment introduced in the donor letter opening"

def _derive_surface_prop(scene_text, theme_text="", cluster_text=""):
    combined = f"{scene_text} {theme_text} {cluster_text}".lower()
    rules = [
        (("garden", "seed", "seedling", "plant", "bloom", "flower", "sunflower"), "a small terracotta pot with a seedling"),
        (("book", "read", "reading", "library", "classroom", "homework"), "a single open book"),
        (("football", "mascot", "osu", "university", "team", "stadium", "sports"), "a small pennant or football tucked near the upper edge"),
        (("kitchen", "dinner", "table", "meal", "grocery", "recipe"), "a handwritten recipe card and a folded tea towel"),
        (("blanket", "home", "bedroom", "caregiver", "family", "safe", "safety", "warmth"), "a soft knit blanket edge and a small framed photo slot"),
        (("sunrise", "light", "window", "hope", "healing", "transform"), "a pressed botanical sprig and a warm window-light highlight"),
        (("christmas", "holiday", "ornament", "winter"), "a satin ribbon and a small evergreen clipping"),
        (("easter", "spring", "pastel"), "a soft floral sprig and one painted egg"),
    ]
    for keywords, prop in rules:
        if any(word in combined for word in keywords):
            return prop
    return "a small framed photo slot and one tactile, story-led prop"

def _derive_surface_description(primary_scene, support_scene, theme_text="", cluster_text=""):
    prop = _derive_surface_prop(primary_scene, theme_text, cluster_text)
    support = _normalize_single_line(support_scene)
    surface = "warm matte paper layered over a lightly textured linen backdrop"
    combo = f"{primary_scene} {support_scene}".lower()
    if any(word in combo for word in ["rustic", "country", "outdoors", "garden", "wood", "farm"]):
        surface = "weathered oak with a soft matte paper underlay"
    elif any(word in combo for word in ["premium", "legacy", "heirloom", "gold", "luxury"]):
        surface = "smooth archival paper on a refined stone-texture surface"
    desc = f"{surface}, using {prop} to translate the campaign's lead scene into a tangible prop"
    if support and _normalize_loose_text(support) != _normalize_loose_text(primary_scene):
        desc += f", with subtle secondary cues from {support}"
    return desc

def _extract_anchor_terms(*values):
    stopwords = {
        "boys", "town", "theme", "imagery", "color", "palette", "premium", "addin", "appeal", "package",
        "children", "child", "donor", "letter", "reply", "card", "front", "back", "exact", "approved",
        "campaign", "creative", "direction", "design", "using", "their", "there", "these", "those", "this",
        "with", "from", "that", "into", "over", "under", "about", "because", "while", "where", "which",
        "should", "would", "could", "across", "toward", "towards", "through", "within", "outside", "visible",
        "specific", "visual", "motif", "motifs", "supporting", "hopeful", "warm", "personal", "family"
    }
    seen = []
    for value in values:
        for token in re.findall(r"[A-Za-z]{4,}", str(value or "").lower()):
            if token in stopwords:
                continue
            if token not in seen:
                seen.append(token)
    return seen[:12]

def _count_anchor_hits(text, anchors):
    lowered = str(text or "").lower()
    return sum(1 for anchor in anchors if anchor and anchor in lowered)

def _blueprint_needs_visual_repair(text, theme_text, imagery_text, letter_opening, addin_text):
    collapsed = _normalize_single_line(text).lower()
    if not collapsed:
        return True
    placeholder_signals = [
        "reflects this approved imagery direction",
        "use the exact selected add-in details already specified",
        "use only the exact approved palette listed here",
        "use the exact approved campaign palette",
    ]
    if any(signal in collapsed for signal in placeholder_signals):
        return True
    if " loose fan layout on " not in collapsed:
        return True
    if _count_anchor_hits(collapsed, _extract_anchor_terms(theme_text, imagery_text, letter_opening, addin_text)) < 2:
        return True
    if not any(token in collapsed for token in ["illustration", "hero image", "prop", "texture", "surface", "motif", "scene"]):
        return True
    return False

def _build_premium_blueprint(text, low, mid, high, section_map=None):
    section_map = section_map or {}
    theme_text = section_map.get("Theme", "")
    imagery_text = section_map.get("Imagery", "")
    palette = _normalize_single_line(section_map.get("Color Palette", "")) or "use the exact approved campaign palette"
    addin = _normalize_single_line(section_map.get("Premium Add-In", "")) or "use the selected premium add-in"
    teaser = _extract_emotion_led_teaser(section_map.get("Envelope Teaser Options", "")) or "use the Emotion-Led teaser from the approved envelope copy"
    letter_opening = section_map.get("Letter Opening", "")
    testing_notes = _normalize_single_line(section_map.get("Testing Notes", ""))
    cluster_summary = section_map.get("Target Cluster Summary", "")
    theme_headline = _extract_theme_headline(theme_text)
    primary_scene = _extract_primary_scene(imagery_text, theme_text)
    support_scene = _extract_support_scene(imagery_text, primary_scene)
    child_reference = _extract_child_reference(letter_opening)
    package_format, package_rationale = _infer_package_format(addin, cluster_summary, text)
    existing_package = re.search(r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)", text, flags=re.IGNORECASE)
    force_rebuild = bool(existing_package and _normalize_single_line(existing_package.group(1)) != package_format)
    envelope_dims = package_format.split(' outer')[0]
    reply_dims = package_format.split(', ', 1)[1].replace(' reply card','') if ', ' in package_format else '3.5x8.5in'
    surface_description = _derive_surface_description(primary_scene, support_scene, theme_text, cluster_summary)
    motif_terms = _extract_anchor_terms(theme_text, imagery_text, letter_opening, addin)
    motif_phrase = ", ".join(motif_terms[:4]) if motif_terms else _normalize_single_line(primary_scene)
    split_addins = bool(testing_notes and re.search(r"control\s*:.*?vs\.\s*test\s*:", testing_notes, flags=re.IGNORECASE))
    addin_faces = "Describe the FRONT as the hero face and the BACK as the reverse face, both fully visible"
    if split_addins:
        addin_faces += "; if Testing Notes compare two distinct physical add-ins, render them as ④A Control Add-In and ④B Test Add-In side by side"
    annotation_callouts = (
        "⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."
        if not split_addins else
        "⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; when the package shows an A/B premium test, label them separately as ④A Control Add-In and ④B Test Add-In; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."
    )
    return _normalize_single_line(
        f'Package format: {package_format}. Rationale: {package_rationale} '
        f'Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children\'s charity. '
        f'All components spread across the full width of the frame in a loose fan layout on {surface_description}: envelope front upper-left, envelope back beside it, donor letter center, reply card lower-right, premium add-in beside the letter, color swatch strip running vertically along the right edge, 20% negative space around the perimeter — no component should be cropped or compressed. '
        f'① Outer envelope FRONT [{envelope_dims}] — show the Emotion-Led teaser copy exactly as approved: "{teaser}"; Boys Town return address upper-left; stamp zone upper-right; envelope design uses the campaign palette exactly as specified and visibly translates the campaign concept through {motif_phrase}, not generic patterning. '
        f'② Outer envelope BACK [{envelope_dims}] — show the sealed flap with the Boys Town logo and tagline "Saving Children, Healing Families" clearly legible; back design echoes the same campaign imagery language with one tasteful visual callback to {support_scene}. '
        f'③ Donor letter 8.5x11in folded to thirds — headline uses "{theme_headline}"; body text is fully readable English sentences that reference {child_reference}; include a visible hero image or illustration panel showing {primary_scene}; margins, footer, or small decorative accents should carry the supporting motif from {support_scene}; apply colors and tone from {palette}. '
        f'④ Premium add-in — use the exact selected add-in and design details already specified: {addin}. {addin_faces}; the add-in artwork must clearly inherit the same campaign imagery direction, especially {primary_scene}, with material, texture, and finishing called out explicitly so the rendering feels premium and printable. '
        f'⑤ Reply card [{reply_dims}] — display the exact ask amounts **${low}**, **${mid}**, and **${high}** in large, clearly legible text with no substitutions; copy every dollar amount and its description verbatim from the Call to Action above; use campaign colors and a small visual echo of {primary_scene} so the reply device feels part of the same package. '
        f'{_swatch_instruction(palette)} '
        f'{annotation_callouts} '
        f'Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic.'
    )

def _blueprint_has_required_scaffold(text):
    collapsed = _normalize_single_line(text).lower()
    required_groups = [
        ["package format:", "rationale:"],
        ["flat-lay", "blueprint"],
        ["①", "②", "③", "④", "⑤", "⑥", "⑦"],
        ["color swatch strip", "right edge"],
        ["annotation", "callout"],
        ["landscape 16:9", "directly overhead", "90 degrees"],
        ["photorealistic"],
    ]
    for group in required_groups:
        if not all(token in collapsed for token in group):
            return False
    return True

def enforce_image_prompt_lines(lines, low, mid, high, section_map=None):
    section_map = section_map or {}
    text = _normalize_single_line(" ".join([ln.strip() for ln in lines if ln.strip()]))
    if not text:
        text = ""

    theme_headline = _extract_theme_headline(section_map.get("Theme", ""))
    teaser = _extract_emotion_led_teaser(section_map.get("Envelope Teaser Options", "")) or "use the Emotion-Led teaser from the approved envelope copy"
    palette = _normalize_single_line(section_map.get("Color Palette", "")) or "use the exact approved campaign palette"
    addin = _normalize_single_line(section_map.get("Premium Add-In", "")) or "use the selected premium add-in"
    imagery = _normalize_single_line(section_map.get("Imagery", "")) or "reflect the approved imagery direction"
    testing_notes = _normalize_single_line(section_map.get("Testing Notes", ""))
    cluster_summary = section_map.get("Target Cluster Summary", "")
    letter_opening = section_map.get("Letter Opening", "")
    package_format, package_rationale = _infer_package_format(addin, cluster_summary, text)

    if not re.search(r"package format:\s*", text, flags=re.IGNORECASE):
        text = f"Package format: {package_format}. Rationale: {package_rationale} " + text
    elif not re.search(r"rationale:\s*", text, flags=re.IGNORECASE):
        text = re.sub(
            r"(?i)(package format:\s*[^\n]+)",
            lambda m: m.group(1) + ". Rationale: " + package_rationale,
            text,
            count=1,
        )

    if "flat-lay" not in text.lower() or "blueprint" not in text.lower() or "landscape 16:9" not in text.lower():
        opener = (
            "Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children's charity. "
            "All components spread across the full width of the frame in a loose fan layout with envelope front upper-left, envelope back beside it, donor letter center, reply card lower-right, premium add-in beside the letter, color swatch strip running vertically along the right edge, and 20% negative space around the perimeter — no component should be cropped or compressed."
        )
        text = f"{opener} {text}".strip()

    needs_component_scaffold = not all(token in text for token in ["①", "②", "③", "④", "⑤"])
    if needs_component_scaffold:
        component_block = (
            f' ① Outer envelope FRONT [{package_format.split(" outer")[0]}] — show the Emotion-Led teaser copy exactly as approved: "{teaser}"; Boys Town return address upper-left; stamp zone upper-right; envelope design uses the campaign palette exactly as specified.'
            f' ② Outer envelope BACK [{package_format.split(" outer")[0]}] — show the sealed flap with the Boys Town logo and tagline "Saving Children, Healing Families" clearly legible; place directly beside ① so both faces are visible together.'
            f' ③ Donor letter 8.5x11in folded to thirds — headline uses "{theme_headline}"; body text is fully readable English and reflects this approved imagery direction: {imagery}.'
            f' ④ Premium add-in — use the exact selected add-in and design details already specified: {addin}. If Testing Notes clearly compare two distinct physical add-ins, render them as ④A Control Add-In and ④B Test Add-In side by side.'
            f' ⑤ Reply card [{package_format.split(", ", 1)[1].replace(" reply card","")}] — display the exact ask amounts **${low}**, **${mid}**, and **${high}** in large, clearly legible text with no substitutions.'
        )
        text = f"{text} {component_block}".strip()

    swatch_instruction = _swatch_instruction(palette)
    if "color swatch strip" in text.lower() and "right edge" in text.lower():
        text = re.sub(
            r"⑥ Color swatch strip along the right edge\s*—\s*.*?(?=\s*⑦\s+Annotation|\s*Landscape 16:9|$)",
            swatch_instruction,
            text,
            count=1,
            flags=re.IGNORECASE,
        )
    else:
        text += " " + swatch_instruction

    if "annotation" not in text.lower() or "callout" not in text.lower():
        text += " ⑦ Annotation callouts — each component is labeled with a white circled number in its upper-left corner, with thin leader lines pointing to clean sans-serif labels outside the component boundary for component name, size, and dominant color; label the swatch strip as ⑥ with a single callout to the strip as a whole, and never render a separate physical annotation strip or legend panel."

    if "landscape 16:9" not in text.lower() or "directly overhead" not in text.lower() or "90 degrees" not in text.lower():
        text += " Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic."

    text = re.sub(
        r"\s*A/B add-in rendering must follow these approved Testing Notes:.*?(?=\s*Reply card must display exactly|\s*$)",
        "",
        text,
        flags=re.IGNORECASE,
    )

    exact_sentence = f" Reply card must display exactly **${low}**, **${mid}**, and **${high}**, matching the Call to Action above with no substitutions."
    if "Reply card must display exactly" not in text:
        text += exact_sentence

    text = _normalize_single_line(text)
    # Strip duplicate flat-lay blocks — keep only the first complete prompt
    _flat_marker = "flat-lay product photography blueprint"
    _first = text.lower().find(_flat_marker)
    if _first != -1:
        _second = text.lower().find(_flat_marker, _first + len(_flat_marker))
        if _second != -1:
            text = text[:_second].strip()
    existing_package = re.search(r"Package format:\s*([^\n]+?)\s+Rationale:\s*([^.]{0,200}\.?)", text, flags=re.IGNORECASE)
    force_rebuild = bool(existing_package and _normalize_single_line(existing_package.group(1)) != package_format)
    if force_rebuild or _blueprint_needs_visual_repair(text, section_map.get("Theme", ""), section_map.get("Imagery", ""), letter_opening, addin):
        text = _build_premium_blueprint(text, low, mid, high, section_map=section_map)
    elif not _blueprint_has_required_scaffold(text):
        text = _build_premium_blueprint(text, low, mid, high, section_map=section_map)
    # Safety: strip any ## markers the model included — they break the frontend section parser
    text = re.sub(r'##\s*', '', text)
    return [text.strip()]

def enforce_ask_ladder_consistency(text, low, mid, high):
    if text is None:
        return text
    sections = split_sections(text)
    if not sections:
        return text
    section_map = _section_map_from_sections(sections)
    new_sections = []
    for heading, lines in sections:
        if heading == "Call to Action":
            lines = enforce_cta_lines(lines, low, mid, high)
        elif heading == "Appeal Package Image Prompt":
            lines = enforce_image_prompt_lines(lines, low, mid, high, section_map=section_map)
        new_sections.append((heading, lines))
    return join_sections(new_sections)

def _compact_section_text(lines):
    return " ".join([ln.strip() for ln in (lines or []) if ln and ln.strip()])

def _normalize_loose_text(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()

def strip_unverified_baseline_claims(text):
    if not text:
        return text
    updated = text
    updated = re.sub(r",?\s*\(?\s*\d+(?:\.\d+)?x baseline(?: lift)?\s*\)?", "", updated, flags=re.IGNORECASE)
    updated = re.sub(r"\(?\s*lift vs baseline\s*\)?", "historical response comparison", updated, flags=re.IGNORECASE)
    updated = re.sub(r"\s{2,}", " ", updated)
    updated = re.sub(r"\n{3,}", "\n\n", updated)
    return updated.strip()

def enforce_addin_override_section(lines, addin_override):
    override = clean_text_input(addin_override, max_len=300)
    if not override:
        return lines
    existing = _compact_section_text(lines)
    if _normalize_loose_text(override) in _normalize_loose_text(existing):
        return lines
    return [
        f"**{override}**",
        f"Use {override} as the premium add-in for this package. This is a direct user override and should be treated as the selected format rather than re-ranked against other historical options.",
        "Design the add-in so it clearly fits the chosen theme, imagery, color palette, and package format while keeping the explanation concise and execution-ready.",
    ]

def enforce_imagery_override_section(lines, imagery_override):
    override = clean_text_input(imagery_override, max_len=300)
    if not override:
        return lines
    prefix = f"Primary visual direction: {override}. This override must be clearly visible in the hero image and supporting package graphics."
    existing = _compact_section_text(lines)
    if _normalize_loose_text(override) in _normalize_loose_text(existing):
        return lines
    if lines and lines[0].strip():
        return [prefix, ""] + lines
    return [prefix]

def enforce_output_integrity(text, addin_override="", imagery_override="", has_real_baseline=True):
    if text is None:
        return text
    sections = split_sections(text)
    if not sections:
        updated = text
    else:
        new_sections = []
        for heading, lines in sections:
            if heading == "Premium Add-In":
                lines = enforce_addin_override_section(lines, addin_override)
            elif heading == "Imagery":
                lines = enforce_imagery_override_section(lines, imagery_override)
            elif heading == "Rationale":
                lines = enforce_rationale_lines(lines)
            new_sections.append((heading, lines))
        updated = join_sections(new_sections)
    if not has_real_baseline:
        updated = strip_unverified_baseline_claims(updated)
    return updated

