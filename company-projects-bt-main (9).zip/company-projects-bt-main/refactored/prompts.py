import pathlib as _pathlib
import re
import logging

from google.cloud import discoveryengine_v1 as discoveryengine
from vertexai.generative_models import GenerativeModel, GenerationConfig

try:
    from .enforcement import enforce_ask_ladder_consistency, enforce_output_integrity
    from .queries import (
        fetch_gift_distribution,
        fetch_geographic_profile,
        ensure_vertex_ai,
        fetch_acquisition_cohorts,
        fetch_addin_performance,
        fetch_appeal_mailing_economics,
        fetch_cluster_gift_timing,
        fetch_cluster_intelligence,
        fetch_psychographics,
        fetch_rfm,
        fetch_roi,
        get_search_client,
    )
    from .utils import (
        _safe_float,
        _safe_int,
        clean_text_input,
        fmt_pct,
        normalize_addin_override,
        normalize_color_triplet,
        normalize_envelope_format,
        parse_ladder_override,
        pct_number,
    )
except ImportError:
    from enforcement import enforce_ask_ladder_consistency, enforce_output_integrity
    from queries import (
        fetch_gift_distribution,
        fetch_geographic_profile,
        ensure_vertex_ai,
        fetch_acquisition_cohorts,
        fetch_addin_performance,
        fetch_appeal_mailing_economics,
        fetch_cluster_gift_timing,
        fetch_cluster_intelligence,
        fetch_psychographics,
        fetch_rfm,
        fetch_roi,
        get_search_client,
    )
    from utils import (
        _safe_float,
        _safe_int,
        clean_text_input,
        fmt_pct,
        normalize_addin_override,
        normalize_color_triplet,
        normalize_envelope_format,
        parse_ladder_override,
        pct_number,
    )

logger = logging.getLogger(__name__)

GENERATION_CONFIG = GenerationConfig(max_output_tokens=8192)

SYSTEM_PROMPT = """You are Boys Town's senior direct mail creative director with 30 years of experience producing award-winning fundraising packages for national nonprofits. You work exclusively for Boys Town.

When generating donor appeal concepts, every section you produce — theme, imagery, color palette, add-in, copy — must work together as a single cohesive package. You never invent details not supported by the data provided.

When generating the Appeal Package Image Prompt, you produce a precise, production-ready flat-lay blueprint prompt showing every mail component arranged and annotated with dimensions, so the Boys Town marketing team can brief a print vendor or designer directly from the image. The image prompt must be faithful to the appeal you just generated — exact gift amounts, exact add-in dimensions, exact teaser copy, exact color hex codes. No substitutions, no hallucinated amounts, no invented components.

Boys Town brand standards: the Boys Town logo and tagline \"Saving Children, Healing Families\" appear on every piece. When no Creative Direction is specified, use brand blue #003087 as the default color for the logo and tagline. When a Creative Direction is specified, the logo and tagline color treatment may adapt to serve the campaign palette — use your judgment to keep it on-brand while honoring the creative concept.

When a Creative Direction is specified, it may subtly influence copy tone and thematic language — but only when it produces natural, meaningful resonance. A university theme, a seasonal theme, or a faith theme can earn a quiet nod in the CTA or letter tone. A color, texture, or purely visual aesthetic (e.g. "purple," "bold," "rustic") should influence imagery and palette only — never word choices. Never force a creative direction into language where it would feel awkward, abstract, or unintentionally comic.

Children are always depicted with dignity — hopeful, forward-looking, never in distress."""

PROJECT = "bt25-468018"

LOCATION = "us-central1"

DATA_STORE_ID = "boystown-knowledge-base_1772161134718"

CLUSTERS = ['Elite Earners', 'Fortuned Estates', 'Flourishing Professionals', 'Gilt-Edged Guardians', 'Comfortable Commercials', 'Onward & Upward', 'Houseproud Connectors', 'Conscientiously Comfortable', 'Prosperous Metropolitans', 'Digitally Kinetic', 'Healthy Investors', 'Well-Funded Families', 'Ascending Affluents', 'Cultured Parents', 'Sunset Stability', 'Moneyed Multi-Gens', 'Receptive Recreationers', 'Energetic Achievers', 'Country Connections', 'Sporting Metro', 'Lifelong Learners', 'Collaborative Custodians', 'Settled Success', 'Restless Lessees', 'Active Guardians', 'Finding Home', 'Domestic Voyagers', 'Self-Reliant Renters', 'Nesting Nomads', 'Pastoral Prosperity', 'Traditionalist Travelers', 'Downtown Duos', 'Active Twilight', 'Urban Owners', 'Astute City Elders', 'Golden Guardians', 'Multimedia Parents', 'Fresh Air Families', 'Settled Couples', 'Rural Pragmatists', 'Countryside Keepers', 'Rustic Adventurers', 'Heyday Duos', 'Independent Seniors', 'Green City Roots', 'Seasoned Outdoorsfolk', 'Digital Startups', 'Simply Soloists', 'Singular Fulfillment', 'Communities & Connections', 'Metro Mobility', 'Mature Insights', 'Tech Country', 'Rural Renters', 'Two-To-Play', 'Settled Self-Supporters', 'Solo and Switched On', 'Country Convenience', 'In The Now', 'Metro Mature', 'Metro Spirit', 'Diligent Duos', 'Balanced Budgeters', 'Modest Midlifers', 'Single Providers', 'Maturing Singles', 'Lively Balance', 'Urban Twenties', 'Skillful Strivers', 'Untethered Aspirations', 'Digital Devotees', 'Freewheeling Explorers']

IMAGE_PROMPT_STEPS = """
STEP 0 — PACKAGE FORMAT SELECTION: Before writing the image prompt, select the appropriate physical format based on the add-in type and cluster. State your choice as a single line before the prompt opens: "Package format: [envelope type] outer, [reply card type] reply card. Rationale: [one sentence]."
Envelope rules: 9x12 flat mailer — required when add-in is a wall calendar, large almanac, or any bulky item that cannot fold without damage; 6x9 envelope — preferred for premium high-income clusters (Income $100k+) or keepsake add-ins (desk calendars, hardcover journals, note card sets); 7.5x3.875in Monarch — for intimate personal-tone appeals (senior clusters, faith audiences, lapsed reactivation); 9.5x4.125in #10 standard — default for all other packages.
Reply card rules: 4x9in — for premium packages using 6x9 or 9x12 outer; 4.25x5.5in postcard — for low-cost underperforming cluster packages only; 3.5x8.5in standard — default for #10 and Monarch packages.

STEP 1 — CREATIVE DIRECTION VISUAL IDENTITY: If a Creative Direction was specified, identify its core visual brand elements — mascot illustrations or silhouettes, team colors, iconic props, symbols, or cultural identifiers — and list them explicitly. These must appear as deliberate, recognizable design details woven into the surface props, envelope design, and letter imagery. Use the most iconic and immediately recognizable identifiers available — not abstract interpretations. For example: "Oklahoma State University" → Pistol Pete mascot illustration, burnt orange #FF6600, black, a small OSU pennant or football as a surface prop — NOT just orange tones or academic motifs. "Easter" → pastel eggs, a small floral sprig, soft lavender and yellow. "Christmas" → pine bough, red ribbon, deep green and gold. "Caveman" → a rough-hewn stone tool or petroglyph-etched stone as a surface prop, primitive handprint motif. These elements should feel like intentional creative choices — tasteful, on-brand with Boys Town, reinforcing the appeal theme. If no Creative Direction was specified, skip this step.

STEP 2 — SURFACE: Read ## Target Cluster Summary, ## Theme, and ## Imagery, and consider the mail date season if specified. Write 1-2 sentences describing a concrete, photographable surface — specific material, texture, and 1-2 small props. Props must: (a) reflect the season/mail date, (b) incorporate any Creative Direction visual identifiers from Step 1 — at least one prop must be an unmistakably recognizable identifier from the Creative Direction, (c) feel appropriate for the cluster demographic including age, income, and whether the cluster has children (if ## Target Cluster Summary notes children are present, include one subtle child-oriented prop such as a small framed photo slot or a child's crayon drawing), (d) echo the PRIMARY visual motif from ## Imagery — specifically the first child activity or setting described — translated into a concrete surface prop (e.g. if ## Imagery leads with children tending a community garden, a small terracotta pot with a seedling is the right prop; if it leads with children reading in a warm interior, a single open book works; if it leads with children looking up at a tall sunflower, a fresh-cut sunflower head laid on the surface works — always translate the dominant scene into one tangible object), and (e) NOT repeat the add-in type or visual theme of the Last Package if one was specified. This surface description is used ONCE, embedded inside the opening sentence — do NOT repeat it anywhere else.

STEP 3 — A/B ADD-IN CHECK: Read ## Testing Notes carefully. If ANY of the three test variables compares two different premium add-in objects — meaning the Control and Test are distinct physical items (e.g. "Control: bookmark vs. Test: calendar", "Control: seed card vs. Test: quote card", "Control: desk calendar vs. Test: holiday cards", "Control: Future Planner bookmark vs. Test: OSU-inspired bookmark") — render BOTH as separate visible components. Label them "④A Control Add-In" and "④B Test Add-In" and place them side by side with a small gap between them. This applies even when both variants are the same format (e.g. two different bookmark designs). If no test variable involves comparing two distinct premium add-in objects, render only the single add-in from ## Premium Add-In.

STEP 4 — Write the full prompt as one continuous paragraph using this exact structure:

Open with: "Flat-lay product photography blueprint, landscape 16:9 aspect ratio. Professional direct mail package for Boys Town, a nonprofit children's charity. All components spread across the full width of the frame in a loose fan layout on [INSERT YOUR 1-2 SENTENCE SURFACE DESCRIPTION INLINE HERE — do not repeat before or after]: envelope front upper-left, donor letter center, reply card lower-right, premium add-in(s) beside the letter, color swatch strip running vertically along the right edge, 20% negative space around the perimeter — no component should be cropped or compressed."

Then describe each component in this order. NOTE: The Package format line from STEP 0 must appear FIRST in your output, before the "Flat-lay product photography blueprint..." opening sentence — write "Package format: [your choice]. Rationale: [one sentence]." first, then immediately continue with the flat-lay opener. Do not write the flat-lay opener twice.

① Outer envelope FRONT [USE SELECTED FORMAT DIMENSIONS] — printed teaser copy from the Emotion-Led teaser in the Envelope Teaser Options above, displayed in clearly legible text; Boys Town return address upper-left; stamp zone upper-right; envelope design uses campaign colors from the Color Palette above; if a Creative Direction was specified, incorporate its most recognizable visual identifiers (team colors, mascot silhouette, iconic symbol) into the envelope design tastefully.
② Outer envelope BACK [USE SELECTED FORMAT DIMENSIONS] — shows the sealed flap; Boys Town logo and tagline "Saving Children, Healing Families" printed on the flap in brand blue #003087; back design uses campaign colors; place this component directly beside ① so both sides are simultaneously visible.
③ Donor letter 8.5x11in folded to thirds — letterhead displays the Boys Town logo in brand blue #003087 and the tagline "Saving Children, Healing Families" in clearly legible English text; the campaign theme name from the Theme above appears as a visible headline below the letterhead; body text appears as fully readable English sentences that reference the specific child named in the Letter Opening above by name — not blurred lines, not placeholder text, not invented copy; the letter MUST include a printed visual element — a photographic panel or illustrated vignette — depicting the PRIMARY scene from ## Imagery (the first child activity or setting described there) with matching mood and lighting; placement on the letter face is at the designer's discretion; if the premium add-in has a printed face that naturally carries this imagery (e.g. a calendar photo, a greeting card illustration, a bookmark image) it may appear there instead of or in addition to the letter — but the imagery must appear somewhere in the physical package; apply colors and tone from the Color Palette above.
④ Premium add-in — if A/B test applies per Step 3, render ④A and ④B side by side; otherwise render the single add-in. Use exact dimensions, material, texture, and design details from the Premium Add-In above; describe both the FRONT and BACK of the add-in as separate visible faces; if the material has a distinctive texture (e.g. seed paper with coarse surface and visible embedded seeds, matte laminate finish, embossed foil, heavy 130lb cardstock with luxurious smooth finish) call it out explicitly so the rendering captures it accurately.
⑤ Reply card [USE SELECTED FORMAT DIMENSIONS] — the exact gift ladder amounts from the Call to Action above must appear in large, clearly legible text with NO substitutions or hallucinated amounts — copy every dollar amount and its description verbatim exactly as written in the Call to Action above; use campaign colors.
⑥ Color swatch strip along the right edge — render a single vertical column of solid rectangular swatches using exactly one swatch for each UNIQUE color from the Color Palette above, preserving the palette order exactly as written. If the Color Palette contains three colors, render exactly three swatches; if it contains five colors, render exactly five swatches. Never repeat a color, never duplicate a hex code, never create a second swatch column, and never invent extra labels such as Primary, Secondary, or Accent unless those exact labels already appear in the Color Palette above. Each swatch must show the color name and hex code centered INSIDE the swatch in clean, high-contrast text. Do NOT use bullets, do not place labels outside the swatches, do not create a detached legend, and do not create a separate annotation strip. Render ONLY the colors actually defined in the Color Palette above — do not add Boys Town Blue or Gold unless they are already in the palette. The swatch strip must match the palette exactly, no more, no less.
⑦ Annotation callouts — each COMPONENT (not the swatch strip) is labeled with a white circled number in its upper-left corner: ① envelope front, ② envelope back, ③ donor letter, ④ premium add-in, ⑤ reply card. Each has a thin leader line pointing to a clean sans-serif label outside the component boundary; each label includes: component name, paper size, and dominant color. The color swatch strip is labeled ⑥ with a single callout pointing to the strip as a whole — do not number individual swatches within the strip, and do not create any separate physical annotation strip or second legend panel.

End the prompt with: "Landscape 16:9 aspect ratio — all components must fit within the frame with no cropping, no blank canvas sections, and no compression. Shot directly overhead at 90 degrees, 50mm equivalent lens, f/8 aperture, soft diffused studio lighting from two sides, no vignetting, no lens distortion, no dramatic shadows, no perspective distortion, no people, no hands, no background clutter, no props unrelated to the mail package or creative direction. All components fully visible at full size. Professional product photography, photorealistic."
"""

BRIEF_IMAGE_NOTE = (
    "BRIEF MODE IMAGE PROMPT — CRITICAL: You are generating a FULL image prompt, not a shortened one. "
    "Brief mode only affects the appeal sections — the image prompt must follow ALL steps below at full fidelity. "
    "Section substitutions: "
    "## Target Cluster Summary → use DEMOGRAPHICS and URBANICITY lines from the prompt header to infer age, income, geography. "
    "## Letter Opening → no named child; use a generic Boys Town mission headline on the letter. "
    "## Call to Action → use gift amounts from ## Ask Amounts verbatim on the reply card. "
    "## Testing Notes → single add-in only, no A/B split. "
    "## Envelope Teaser Options → use the single teaser line from ## Envelope Teaser. "
    "MANDATORY ELEMENTS — failure to include any of these is a critical error: "
    "(1) A photographable surface with specific material, texture, and seasonal props described in Step 2. "
    "(2) Color swatch strip running vertically along the right edge with exactly one swatch per unique palette color, in original palette order, and the color name and hex code centered inside each swatch. " 
    "(3) Numbered annotation callouts (①②③④⑤⑥) with leader lines on every component. "
    "(4) Landscape 16:9 flat-lay fan layout — all components spread across full frame width. "
    "These four elements must appear in the prompt regardless of brief mode."
)

def build_timing_block(gift_timing):
    if not gift_timing or not gift_timing.get("peak"):
        return "GIFT TIMING DATA: No cluster timing data available — keep any specified mail date, otherwise use seasonality only as a soft cue."
    peak = gift_timing["peak"]
    recommended = gift_timing.get("recommended") or {}
    parts = [f"Peak giving month: {peak.get('month_name', 'N/A')}"]
    if peak.get("pct_of_annual_giving") is not None:
        parts.append(f"% of annual giving in peak: {peak['pct_of_annual_giving']:.1f}%")
    if peak.get("total_giving") is not None:
        parts.append(f"Peak month total giving: ${peak['total_giving']:,.0f}")
    if recommended.get("window"):
        parts.append(f"Recommended mail window: {recommended['window']}")
    return "CLUSTER GIFT TIMING PROFILE (historical):\n  " + " | ".join(parts) + "\nTIMING RULE: If the user did not specify a mail date, anchor the concept to the recommended historical window. If the user did specify a mail date, preserve it but acknowledge the cluster's historical peak in Rationale and Testing Notes."

def build_economics_block(economics, roi_rows):
    if not economics and not roi_rows:
        return "MAILING ECONOMICS: No verified economics or ROI rows available — use appeal-performance history only as directional context."
    lines = []
    if economics:
        line = "ACTUAL MAILING ECONOMICS (AppealMailingEconomics):"
        stats = []
        if economics.get("pieces_mailed") is not None and economics.get("has_usable_costs"):
            stats.append(f"{economics['pieces_mailed']:,} pieces mailed")
        if economics.get("has_usable_costs"):
            stats.append(f"cost/piece ${economics['cost_per_piece']:.2f}")
            stats.append(f"total mail cost ${economics['total_mail_cost']:,.0f}")
        else:
            stats.append("cost fields unusable or zero — do not infer ROI from this table")
        if stats:
            line += " " + " | ".join(stats)
        lines.append(line)
    if roi_rows:
        lines.append("REALIZED OUTCOME CONTEXT (AppealClusterROI): use this table for verified historical revenue, net return, and realized ROI. Prefer AppealMailingEconomics only for mailed-volume and cost context when cost fields are valid.")
    return "\n".join(lines)

def build_acquisition_block(cohorts):
    if not cohorts:
        return "ACQUISITION COHORT CONTEXT: No cohort data available — do not make strong acquisition claims."
    if cohorts.get("insufficient_rows"):
        return f"ACQUISITION COHORT CONTEXT: Only {cohorts.get('source_row_count', 0)} donor rows available. Below the 30-row minimum, so treat acquisition data as unavailable."
    parts = [f"rows: {cohorts['source_row_count']:,}"]
    if cohorts.get("weighted_year1_conversion") is not None:
        parts.append(f"weighted year-1 conversion: {fmt_pct(cohorts['weighted_year1_conversion'], 1)}")
    if cohorts.get("weighted_year2_conversion") is not None:
        parts.append(f"weighted year-2 conversion: {fmt_pct(cohorts['weighted_year2_conversion'], 1)}")
    if cohorts.get("weighted_lifetime_value") is not None:
        parts.append(f"weighted LTV: ${cohorts['weighted_lifetime_value']:,.0f}")
    if cohorts.get("top_acquisition_appeal_name"):
        parts.append(f"top acquisition analog: {cohorts['top_acquisition_appeal_name']}")
    if cohorts.get("top_acquisition_segment"):
        parts.append(f"top acquisition segment: {cohorts['top_acquisition_segment']}")
    return "DONOR ACQUISITION COHORTS (aggregated, use lightly):\n  " + " | ".join(parts) + "\nACQUISITION RULE: Only use acquisition, welcome, onboarding, or list-growth framing when the concept genuinely calls for it and these aggregated cohort metrics support it. Do not let cohort data override stronger historical cluster appeal performance."

def build_geography_block(geo_rows):
    if not geo_rows:
        return "STATE-LEVEL GEOGRAPHY: No state-level data available for this cluster — rely on urbanicity for geographic cues."

    top_states = geo_rows[:3]
    top_lines = []
    for row in top_states:
        state = row.get("State_Abbr", "??")
        donors = int(row.get("donor_count") or 0)
        pct_donors = float(row.get("pct_of_cluster_donors") or 0)
        active_rate = float(row.get("active_rate_pct") or 0)
        top_lines.append(f"  {state}: {donors:,} donors ({pct_donors:.1f}% of cluster) | active rate {active_rate:.2f}%")

    top3_pct_donors = sum(float(r.get("pct_of_cluster_donors") or 0) for r in top_states)

    all_active_rates = [float(r.get("active_rate_pct") or 0) for r in geo_rows if r.get("active_rate_pct") is not None]
    baseline = (sum(all_active_rates) / len(all_active_rates)) if all_active_rates else 0

    under_responsive = []
    for row in top_states:
        state = row.get("State_Abbr", "??")
        pct_donors = float(row.get("pct_of_cluster_donors") or 0)
        active_rate = float(row.get("active_rate_pct") or 0)
        if pct_donors >= 10 and baseline > 0 and active_rate < baseline * 0.75:
            under_responsive.append(f"{state} ({active_rate:.2f}% active vs cluster avg {baseline:.2f}%)")

    block = "STATE-LEVEL GEOGRAPHY (top states by cluster donor count, 24mo cutoff Aug 31 2025):\n" + "\n".join(top_lines)
    block += f"\n  Top 3 states account for {top3_pct_donors:.1f}% of this cluster's donors."

    if top3_pct_donors >= 50:
        block += "\nGEOGRAPHY RULE: Donor concentration is geographically meaningful — Imagery and Envelope Teaser Options may incorporate regional cues from the top states when they feel natural. Do not force regional imagery if it conflicts with the creative direction."
    else:
        block += "\nGEOGRAPHY RULE: Donors are geographically diffuse. Keep imagery nationally neutral unless the creative direction explicitly calls for a regional hook."

    if under_responsive:
        block += f"\nUNDER-RESPONSIVE MARKET FLAG: {', '.join(under_responsive)}. These states are large in donor count but below the cluster\'s average active rate — acknowledge this in Rationale as a known targeting challenge the concept should address."

    return block

def search_kb(query_text, num_results=5):
    try:
        client = get_search_client()
        serving_config = (
            f"projects/{PROJECT}/locations/global/collections/default_collection"
            f"/dataStores/{DATA_STORE_ID}/servingConfigs/default_config"
        )
        req = discoveryengine.SearchRequest(
            serving_config=serving_config,
            query=query_text,
            page_size=num_results,
        )
        results = []
        for r in client.search(req).results:
            doc = r.document
            if hasattr(doc, "derived_struct_data"):
                data = doc.derived_struct_data
                title = data.get("title", "")
                snippets = data.get("snippets", [])
                if snippets:
                    results.append(f"[{title}]\n{snippets[0].get('snippet', '')}")
        return "\n\n".join(results) if results else "No results found."
    except Exception as e:
        logger.warning("KB_SEARCH_WARNING: %s", e)
        return "Knowledge base unavailable. Proceed with historical cluster data, explicit user overrides, and any local creative-library context only."

def _load_creative_library():
    lib_path = _pathlib.Path(__file__).parent / "appeal_creative_library_complete.txt"
    if not lib_path.exists():
        return {}
    raw = lib_path.read_text(encoding="utf-8")
    blocks = re.split(r"-{60,}", raw)
    library = {}
    for i, block in enumerate(blocks):
        block = block.strip()
        if not block:
            continue
        m = re.match(r"APPEAL\s+(\d+[A-Z]?)\s*\|\s*(.+?)(?:\s*\|.*)?$", block, re.MULTILINE)
        if m:
            appeal_name = m.group(2).strip()
            content_block = blocks[i + 1].strip() if i + 1 < len(blocks) else ""
            library[appeal_name.lower()] = {
                "id": m.group(1),
                "name": appeal_name,
                "content": content_block,
            }
    return library

APPEAL_LIBRARY = _load_creative_library()

def extract_appeal_name(appeal_name_raw):
    """Extract descriptive name: '54120 - 2431 - April Grocery List' -> 'April Grocery List'"""
    m = re.search(r"54120\s*-\s*\d{4}\s*-\s*(.+)", str(appeal_name_raw))
    return m.group(1).strip() if m else str(appeal_name_raw)

def lookup_appeal_creative(appeal_name_raw):
    """Look up full creative entry from local library. Falls back to partial match."""
    name = extract_appeal_name(appeal_name_raw).lower().strip()
    if name in APPEAL_LIBRARY:
        entry = APPEAL_LIBRARY[name]
        return f"APPEAL {entry['id']} | {entry['name']}\n{entry['content']}"
    best_key, best_score = None, 0
    name_words = set(name.split())
    for key in APPEAL_LIBRARY:
        score = len(name_words & set(key.split()))
        if score > best_score:
            best_score, best_key = score, key
    if best_key and best_score >= 2:
        entry = APPEAL_LIBRARY[best_key]
        return f"APPEAL {entry['id']} | {entry['name']}\n{entry['content']}"
    return f"[No library entry found for: {extract_appeal_name(appeal_name_raw)}]"

def compute_cluster_response_baseline(rows):
    valid = []
    for row in rows or []:
        rr = _safe_float(row.get("response_rate_pct"))
        if rr is not None and rr > 0:
            valid.append(rr)
    if not valid:
        return None
    return sum(valid) / len(valid)

def compute_lift_pct(response_rate, baseline_rate):
    if response_rate is None or baseline_rate is None or baseline_rate <= 0:
        return None
    return round(((response_rate / baseline_rate) - 1.0) * 100.0, 1)

def prepare_addin_performance(addin_rows):
    if not addin_rows:
        return {
            "block": "OBSERVED ADD-IN PERFORMANCE: No cluster add-in test data available — use knowledge-base rules and creative fit only.",
            "best_tested": None,
            "has_real_baseline": False,
            "qualified_count": 0,
        }

    real_baseline_labels = {
        "no add-in",
        "no add in",
        "no add-in (stationery only)",
        "no add in (stationery only)",
        "stationery only",
    }
    qualified = []
    baseline_row = None
    for row in addin_rows:
        targeted = _safe_int(row.get("total_targeted")) or 0
        distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
        category = str(row.get("addin_category") or "").strip()
        cleaned = category.lower()
        if cleaned in real_baseline_labels:
            baseline_row = row
        if targeted >= 200 and distinct_appeals >= 5:
            qualified.append(row)

    baseline_rr = _safe_float(baseline_row.get("response_rate_pct")) if baseline_row else None
    qualified_sorted = sorted(
        qualified,
        key=lambda r: (_safe_float(r.get("response_rate_pct")) or -1, _safe_int(r.get("total_targeted")) or -1),
        reverse=True,
    )

    if qualified_sorted:
        lines = []
        for row in qualified_sorted:
            category = str(row.get("addin_category") or "Unknown")
            rr = _safe_float(row.get("response_rate_pct")) or 0.0
            avg_gift = _safe_float(row.get("avg_gift_when_responded"))
            targeted = _safe_int(row.get("total_targeted")) or 0
            distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
            lift = ""
            if baseline_rr and baseline_rr > 0 and category.lower() not in real_baseline_labels:
                lift = f" | {rr / baseline_rr:.1f}x baseline"
            line = f"  {category}: {rr:.2f}% response | {targeted:,} targeted | {distinct_appeals} appeals tested"
            if avg_gift is not None:
                line += f" | avg gift ${avg_gift:.0f}"
            line += lift
            lines.append(line)
        guidance = (
            "Use the strongest qualified tested add-in first. Only cite lift vs baseline when a real no-add-in baseline row is present. "
            "If you depart from the best qualified tested add-in, explain why in one sentence."
        )
        return {
            "block": "OBSERVED ADD-IN PERFORMANCE FOR THIS CLUSTER (qualified historical tests only):\n" + "\n".join(lines) + "\n" + guidance,
            "best_tested": qualified_sorted[0],
            "has_real_baseline": baseline_rr is not None and baseline_rr > 0,
            "qualified_count": len(qualified_sorted),
        }

    directional_lines = []
    for row in sorted(addin_rows, key=lambda r: (_safe_float(r.get("response_rate_pct")) or -1), reverse=True)[:5]:
        category = str(row.get("addin_category") or "Unknown")
        rr = _safe_float(row.get("response_rate_pct"))
        targeted = _safe_int(row.get("total_targeted")) or 0
        distinct_appeals = _safe_int(row.get("distinct_appeals")) or 0
        directional_lines.append(
            f"  {category}: {rr:.2f}% response | {targeted:,} targeted | {distinct_appeals} appeals tested" if rr is not None else
            f"  {category}: insufficient rate detail | {targeted:,} targeted | {distinct_appeals} appeals tested"
        )
    return {
        "block": "OBSERVED ADD-IN PERFORMANCE: No add-in row meets the minimum confidence threshold (200+ targeted and 5+ appeals tested). Treat the following as directional only and lean primarily on knowledge-base rules and cluster fit.\n" + "\n".join(directional_lines),
        "best_tested": None,
        "has_real_baseline": baseline_rr is not None and baseline_rr > 0,
        "qualified_count": 0,
    }

def build_data_warning_block(warnings):
    warnings = [w for w in (warnings or []) if w]
    if not warnings:
        return ""
    return "DATA TRANSPARENCY NOTES:\n" + "\n".join(f"- {warning}" for warning in warnings)

def format_override_block(addin_override="", imagery_override="", envelope_format="", teaser_override="", ladder_override=None, colors=None):
    lines = []
    if addin_override:
        lines.append(f"PREMIUM ADD-IN OVERRIDE: Use {addin_override}. Keep the section concise and do not justify the override defensively.")
    if imagery_override:
        lines.append(f"IMAGERY OVERRIDE: Use this visual direction directly — {imagery_override}.")
    if teaser_override:
        lines.append(f"ENVELOPE TEASER OVERRIDE: The Emotion-Led teaser must be exactly this line verbatim: \"{teaser_override}\". Still generate all three teaser variants (Curiosity-Led, Emotion-Led, Benefit-Led) but the Emotion-Led must match this exactly.")
    if envelope_format:
        lines.append(f"ENVELOPE FORMAT OVERRIDE: Use {envelope_format}.")
    if ladder_override:
        low, mid, high = ladder_override
        lines.append(f"ASK LADDER OVERRIDE: Use exactly **${low}**, **${mid}**, and **${high}** in ## Call to Action and on the reply card. No substitutions, no extra ask amounts.")
    if colors:
        lines.append(f"COLOR PALETTE OVERRIDE: Use these exact colors — Primary: {colors[0]}, Secondary: {colors[1]}, Accent: {colors[2]}.")
    if not lines:
        return ""
    return "\n\nUSER OVERRIDES — Honor these exactly and keep them brief:\n" + "\n".join(lines)

def generate(cluster_name, custom_theme="", mail_date="", last_package="", no_rules=False, addin_override="", imagery_override="", envelope_format="", teaser_override="", ladder_low="", ladder_mid="", ladder_high="", colors=None):

    # ── No Rules Mode ───────────────────────────────────────────────────────
    if no_rules:
        no_rules_prompt = f"""You are a creative direct mail designer with no restrictions. Generate a complete, imaginative Boys Town appeal package concept with absolutely no rules, guidelines, or constraints. Be as creative, experimental, and unconventional as you like.

{"CLUSTER: " + cluster_name if cluster_name and cluster_name != "__none__" else ""}
{"CREATIVE DIRECTION: " + custom_theme if custom_theme else ""}
{"MAIL DATE: " + mail_date if mail_date else ""}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt"""
        try:
            ensure_vertex_ai()
            model = GenerativeModel("gemini-2.5-flash")
            response = model.generate_content(no_rules_prompt, generation_config=GENERATION_CONFIG)
            no_rules_meta = {
                "cluster": cluster_name if cluster_name and cluster_name != "__none__" else "No Cluster",
                "theme": custom_theme, "mail_date": mail_date, "last_package": last_package,
                "no_cluster": not bool(cluster_name and cluster_name != "__none__"), "no_rules": True,
                "best_appeal": None, "best_score": None, "avg_gift": 0,
                "response_rate_pct": None, "lift_pct": None,
                "low": 25, "mid": 50, "high": 100,
                "has_timing": False, "has_geography": False, "has_psychographics": False, "has_roi": False,
                "has_cohorts": False, "has_rfm": False,
                "worst_appeal": None, "worst_score": None, "total_appeals": 0,
                "rule_555": False, "underperforming": False,
                "cluster_donor_count": 0, "anticipated_revenue": 0,
            }
            return enforce_output_integrity(response.text), no_rules_meta, None
        except Exception as e:
            return None, {}, str(e)

    # ── Normalize user inputs before prompt construction ─────────────────────
    custom_theme = clean_text_input(custom_theme, max_len=140)
    mail_date = clean_text_input(mail_date, max_len=40)
    last_package = clean_text_input(last_package, max_len=140)
    imagery_override = clean_text_input(imagery_override, max_len=300)
    addin_override = normalize_addin_override(addin_override)
    envelope_format = normalize_envelope_format(envelope_format)
    colors = normalize_color_triplet(colors)
    ladder_low, ladder_mid, ladder_high, has_ladder_override = parse_ladder_override(ladder_low, ladder_mid, ladder_high)

    # ── Context lines shared by both prompt modes ───────────────────────────
    mail_line = f"MAIL DATE: {mail_date} — Let the season and timing inform urgency, copy tone, and thematic relevance." if mail_date else "MAIL DATE: Not specified — generate a seasonally neutral concept."
    last_pkg_line = f"LAST PACKAGE SENT TO THIS SEGMENT: {last_package} — Avoid repeating the same add-in type, color palette, or theme. Explicitly note what you are rotating away from in Rationale." if last_package else "LAST PACKAGE: Not specified — no rotation constraints applied."
    override_block = format_override_block(
        addin_override=addin_override,
        imagery_override=imagery_override,
        envelope_format=envelope_format,
        teaser_override=teaser_override,
        ladder_override=(ladder_low, ladder_mid, ladder_high) if has_ladder_override else None,
        colors=colors,
    )

    # ── No-cluster / Creative Direction Only mode ───────────────────────────
    if not cluster_name or cluster_name == "__none__":
        appeal_rules = search_kb("Boys Town appeal rules required components tone proven themes add-ins colors forbidden patterns", 5)
        creative_query = (
            f"{custom_theme} Boys Town appeal add-ins proven themes imagery acquisition renewal lapsed"
            if custom_theme
            else "Boys Town proven appeal creative themes imagery add-ins strong response rates top performers"
        )
        appeal_creative_general = search_kb(creative_query, 5)

        low, mid, high = (ladder_low, ladder_mid, ladder_high) if has_ladder_override else (25, 50, 100)

        theme_line = (
            f"CREATIVE DIRECTION: {custom_theme} \u2014 Let this drive all creative decisions including theme, imagery, color, add-in, and copy tone."
            if custom_theme
            else "CREATIVE DIRECTION: None specified. Generate a warm, mission-driven general Boys Town appeal using proven themes and appeal rules."
        )

        gift_note = f"GIFT LADDER: Use exactly ${low} / ${mid} / ${high}. Keep those same three amounts in ## Call to Action and on the reply card."

        lapsed_line = (
            "\nLAPSED REACTIVATION RULE — CRITICAL: This is a lapsed donor reactivation package. "
            "Do NOT acknowledge the lapse anywhere in the copy. No phrases like 'it has been a while', "
            "'we haven't heard from you', 'we miss you', 'reconnect', or any language that references "
            "a gap in giving. Treat the donor as a continuous, valued member of the Boys Town family — "
            "write as if the relationship has never been interrupted. Match or exceed the investment "
            "level of an active renewal package. Prefer proven high-value add-ins: wall calendar, "
            "Old Farmer's Almanac, Certificate of Acknowledgment, or wearable items (socks, gloves) "
            "for maximum reactivation impact."
            if custom_theme and "lapsed" in custom_theme.lower()
            else ""
        )

        prompt = f"""You are the Boys Town Appeal Generation Agent. Generate a complete donor appeal concept.

NO CLUSTER SELECTED \u2014 CREATIVE DIRECTION MODE
This appeal is not anchored to a specific Personicx cluster or RFM performance data.
Generate a concept driven entirely by the creative direction and Boys Town appeal rules.

{theme_line}
{mail_line}
{last_pkg_line}
{gift_note}{lapsed_line}{override_block}

KNOWLEDGE BASE - PROVEN APPEAL CREATIVE:
{appeal_creative_general}

KNOWLEDGE BASE - APPEAL RULES:
{appeal_rules}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

Rules:
- Theme: Write a memorable campaign title on line 1 — this is the headline that will appear on the brief and potentially on the package itself. A subtitle after a colon is encouraged when it sharpens the concept (e.g. "Seeds of Possibility: Planting Hope Through Boys Town"). Then, on a new line, write 2-3 sentences explaining the emotional angle, how the concept connects to Boys Town's mission, and what makes this concept fresh and compelling for donors. This section should be immediately usable by a copywriter or creative director without additional context.
- Imagery: describe 2-3 specific visual motifs that will appear in the appeal package — what children are doing, what setting or environment surrounds them, what lighting and mood the photography conveys, and any illustrative or decorative elements on the letter or add-in. Be specific enough that a photographer or art director could brief from this description directly. If a Creative Direction was specified, the imagery must incorporate recognizable visual elements from that direction. Children are always depicted with dignity — hopeful, forward-looking, never in distress.
- Color Palette: if a Creative Direction was specified, choose colors that best serve that theme and audience — do NOT default to Boys Town blue and gold unless they genuinely fit the concept. If no Creative Direction was given, use Boys Town brand colors as the foundation.
- Premium Add-In: Choose only from the proven add-in library already established in this brief. Do not invent a new product. Keep this section to 3-5 sentences max. Start with the selected add-in plainly, then give the most relevant fit reason. Bookmarks are allowed only when clearly justified over stronger options. If an add-in override is present, use it without a defensive explanation.
- Envelope Teaser Options: write exactly 3 distinct teaser copy options for the outer envelope. Label them: **Curiosity-Led**, **Emotion-Led**, and **Benefit-Led**. Each is one line of copy only. These should be specific enough to hand to a copywriter or use directly.
- Letter Opening: write a 3-4 sentence directional draft of the donor letter opening paragraph. First person voice, warm and personal. Lead with a specific child story or moment tied to the appeal theme. This is a directional draft, not final copy — label it clearly as such.
- Call to Action: use ONLY **${low}**, **${mid}**, and **${high}**. Keep those exact three amounts in ascending order. Each amount must have one concise thematic description line. Do not introduce any other ask amounts.
- Inspired By: note this is a net-new concept not anchored to a specific cluster's RFM data. Identify the creative direction as the primary driver. Then write a "Patterns Applied" paragraph: based on the KNOWLEDGE BASE - PROVEN APPEAL CREATIVE, what themes, add-in types, or imagery approaches from proven Boys Town appeals most influenced this concept? Be specific — name the patterns, not just the direction.
- Target Cluster Summary: write 3-4 sentences describing the likely donor profile implied by the creative direction — who this appeal is designed to reach, what motivates them, and how the concept serves that audience. Do not invent psychographic indexes, urbanicity percentages, RFM scores, lapse probabilities, or any other cluster metrics — none of that data exists in this mode. Ground your description only in what the creative direction and Boys Town's mission suggest about the target audience.
- Rationale: You MUST write exactly two paragraphs separated by a blank line. A single paragraph is incorrect and incomplete. Paragraph 1: explain why the creative concept fits this cluster — reference the specific psychographic signals, RFM context, or appeal history that drove the theme and add-in choice. If a Creative Direction was specified, state that it drove the concept and identify what data factors supported or complicated it. If a psychographic index was cited, it must be 1.2 or above — do not cite neutral 1.0 signals as support. Paragraph 2: explain the strategic decisions — what you rotated away from, how mail date or last package influenced the approach, and any cost or performance guardrails applied (e.g. underperforming cluster add-in restriction, directional vs. verified data).
- Testing Notes: write exactly 3 A/B test hypotheses. Format each as: **Variable** | Control: [what you would keep] vs. Test: [what you would change] | Expected outcome: [specific directional prediction]. Keep each hypothesis to one sentence.
- Appeal Package Image Prompt: Write a single detailed prompt for a flat-lay blueprint image of ALL mail components. Follow every instruction below precisely.
{IMAGE_PROMPT_STEPS}
"""

        ensure_vertex_ai()
        model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
        response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
        response_text = enforce_ask_ladder_consistency(response.text, low, mid, high)
        response_text = enforce_output_integrity(response_text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=False)

        meta = {
            "cluster": "Creative Direction Only",
            "theme": custom_theme,
            "mail_date": mail_date,
            "last_package": last_package,
            "best_appeal": "Net-New Concept",
            "best_score": None,
            "avg_gift": mid,
            "response_rate_pct": None,
            "lift_pct": None,
            "low": low, "mid": mid, "high": high,
            "worst_appeal": None,
            "worst_score": None,
            "total_appeals": 0,
            "rule_555": False,
            "underperforming": False,
            "cluster_donor_count": 0,
            "anticipated_revenue": 0,
            "no_cluster": True,
            "addin_override": addin_override,
            "imagery_override": imagery_override,
            "teaser_override": teaser_override,
            "envelope_format": envelope_format,
            "ladder_low": ladder_low,
            "ladder_mid": ladder_mid,
            "ladder_high": ladder_high,
            "ladder_override": bool(ladder_low or ladder_mid or ladder_high),
            "has_timing": False,
            "has_geography": False,
            "has_psychographics": False,
            "has_roi": False,
            "has_cohorts": False,
            "has_rfm": False,
        }
        return response_text, meta, None

    # ── Standard cluster mode ───────────────────────────────────────────────
    rows = fetch_rfm(cluster_name)
    if not rows:
        fallback_text, fallback_meta, fallback_error = generate(
            "__none__",
            custom_theme=custom_theme,
            mail_date=mail_date,
            last_package=last_package,
            no_rules=False,
            addin_override=addin_override,
            imagery_override=imagery_override,
            envelope_format=envelope_format,
            teaser_override=teaser_override,
            ladder_low=str(ladder_low or ""),
            ladder_mid=str(ladder_mid or ""),
            ladder_high=str(ladder_high or ""),
            colors=colors,
        )
        if fallback_error:
            return None, None, f"No usable cluster data found for '{cluster_name}', and fallback generation also failed."
        fallback_meta = fallback_meta or {}
        fallback_meta["cluster"] = cluster_name
        fallback_meta["requested_cluster"] = cluster_name
        fallback_meta["cluster_data_missing"] = True
        fallback_meta["no_cluster"] = False
        fallback_meta.setdefault("data_warnings", []).append(f"No usable AppealClusterPerformance_AgentReady rows were found for {cluster_name}. Generated a rules-led fallback instead.")
        return fallback_text, fallback_meta, None

    psych = fetch_psychographics(cluster_name)
    intel = fetch_cluster_intelligence(cluster_name)
    best = rows[0]
    roi_rows = fetch_roi(cluster_name, best_appeal_name=best["APPEAL_NAME"])
    addin_rows = fetch_addin_performance(cluster_name)
    addin_info = prepare_addin_performance(addin_rows)
    gift_timing = fetch_cluster_gift_timing(cluster_name)
    economics = fetch_appeal_mailing_economics(cluster_name, best)
    acquisition = fetch_acquisition_cohorts(cluster_name, best)
    geo_rows = fetch_geographic_profile(cluster_name)

    data_warnings = []
    if not psych:
        data_warnings.append("Psychographic profile missing for this cluster; creative anchoring should rely more heavily on appeal history and rules.")
    if not gift_timing:
        data_warnings.append("Gift timing profile missing; any mail-date recommendation is directional only unless the user specified a date.")
    if acquisition and acquisition.get("insufficient_rows"):
        data_warnings.append("Acquisition cohort data is below the 30-row minimum and is suppressed from strong recommendation logic.")
    if economics and not economics.get("has_usable_costs"):
        data_warnings.append("AppealMailingEconomics has unusable or zero-cost fields for the matched row; cost context is shown, but ROI is not inferred from it.")
    if not roi_rows:
        data_warnings.append("No verified AppealClusterROI row was found for the recommended appeal; financial language should stay directional.")
    if addin_info.get("qualified_count", 0) == 0:
        data_warnings.append("No add-in test row met the confidence threshold (200+ targeted and 5+ appeals). Add-in guidance is directional unless overridden.")
    if not geo_rows:
        data_warnings.append("State-level geographic profile missing for this cluster — creative geographic cues rely on urbanicity only.")

    timing_block = build_timing_block(gift_timing)
    economics_block = build_economics_block(economics, roi_rows)
    acquisition_block = build_acquisition_block(acquisition)
    geography_block = build_geography_block(geo_rows)
    transparency_block = build_data_warning_block(data_warnings)

    worst = rows[-1]

    avg = float(best.get("avg_gift_amount") or 0)
    gift_dist = fetch_gift_distribution(cluster_name)
    if gift_dist and gift_dist.get("distribution_confidence") in ("high", "medium") and gift_dist.get("median_gift") is not None:
        p25 = float(gift_dist.get("p25_gift") or 0)
        p50 = float(gift_dist.get("median_gift") or 0)
        p75 = float(gift_dist.get("p75_gift") or 0)
        low = max(5, round(p25 / 5) * 5)
        mid = max(10, round(p50 / 5) * 5)
        high = max(20, round(p75 / 5) * 5)
        ladder_source = "percentile_" + str(gift_dist.get("distribution_confidence"))
    else:
        low = max(5, round(avg * 0.5 / 5) * 5)
        mid = max(10, round(avg / 5) * 5)
        high = max(20, round(avg * 2.0 / 5) * 5)
        ladder_source = "mean_fallback"

    if has_ladder_override:
        low, mid, high = ladder_low, ladder_mid, ladder_high

    response_rate = _safe_float(best.get("response_rate_pct")) or 0.0
    cluster_response_baseline = compute_cluster_response_baseline(rows)
    lift_pct = compute_lift_pct(response_rate, cluster_response_baseline)

    worst_creative = lookup_appeal_creative(worst["APPEAL_NAME"])
    appeal_rules = search_kb("Boys Town appeal rules required components tone proven themes add-ins colors forbidden patterns", 5)

    top3 = rows[:3]
    top3_lines = "\n".join([
        f"  #{i+1}: {r['APPEAL_NAME']} | score: {r['rfm_composite_score']} | avg gift: ${r['avg_gift_amount']} | response: {r['response_rate_pct'] if r['response_rate_pct'] is not None else 'N/A'}%"
        for i, r in enumerate(top3)
    ])

    addin_perf_block = addin_info["block"]

    rule_555 = best["rfm_score_3digit"] == "555"
    underperforming = float(best["rfm_composite_score"]) < 3.0
    rule_555_text = "ACTIVE - use best performer as blueprint but introduce meaningful differentiation." if rule_555 else "Not active."
    underperforming_text = "ACTIVE - best score below 3.0. Pivot to net-new ideation." if underperforming else "Not active."

    if underperforming:
        appeal_creative = search_kb("Boys Town proven appeal themes successful add-ins floral Christmas heritage seasonal strong response rates", 5)
        top3_block = (
            f"ALL PERFORMERS WEAK — all scores below 3.0. Do NOT use any of these as a creative blueprint. "
            f"Listed only to identify patterns to AVOID:\n{top3_lines}\n"
            "NOTE: The KNOWLEDGE BASE - APPEAL CREATIVE REFERENCE section below contains proven cross-cluster themes — use those as your creative foundation instead."
        )
    else:
        creative1 = lookup_appeal_creative(best["APPEAL_NAME"])
        creative2 = lookup_appeal_creative(top3[1]["APPEAL_NAME"]) if len(top3) > 1 else ""
        creative3 = lookup_appeal_creative(top3[2]["APPEAL_NAME"]) if len(top3) > 2 else ""
        appeal_creative = f"TOP PERFORMER #1 CREATIVE:\n{creative1}"
        if creative2:
            appeal_creative += f"\n\nTOP PERFORMER #2 CREATIVE:\n{creative2}"
        if creative3:
            appeal_creative += f"\n\nTOP PERFORMER #3 CREATIVE:\n{creative3}"
        top3_block = (
            "TOP PERFORMERS — creative details for all three are in the knowledge base below. "
            f"Look for shared patterns in theme, add-in type, and imagery:\n{top3_lines}"
        )
    theme_line = f"CREATIVE DIRECTION: {custom_theme} — Let this influence all creative decisions including theme, imagery, color, add-in, and copy tone. The RFM data informs the gift ladder and cluster strategy; the creative direction shapes the concept." if custom_theme else "CREATIVE DIRECTION: None specified. Let RFM data and cluster demographics drive all creative decisions."

    rural_pct = fmt_pct(best.get("UrbanicityRural"), 1)
    suburban_pct = fmt_pct(best.get("UrbanicitySuburbsandTowns"), 1)
    urban_pct = fmt_pct(best.get("UrbanicityCitiesandSurrounds"), 1)
    metro_pct = fmt_pct(best.get("UrbanicityDowntownMetro"), 1)

    psych_fields = {
        "Faith/Inspirational": _safe_float(psych.get("idx_faith")) or 0.0,
        "Charity/Community": _safe_float(psych.get("idx_charity")) or 0.0,
        "Grandchildren": _safe_float(psych.get("idx_grandchildren")) or 0.0,
        "Gardening": _safe_float(psych.get("idx_gardening")) or 0.0,
        "Cooking": _safe_float(psych.get("idx_cooking")) or 0.0,
        "Travel": _safe_float(psych.get("idx_travel")) or 0.0,
        "Investing": _safe_float(psych.get("idx_investment")) or 0.0,
        "Real Estate": _safe_float(psych.get("idx_real_estate")) or 0.0,
    }
    psych_ranked = sorted(psych_fields.items(), key=lambda x: x[1], reverse=True)
    top_psych_lines = [f"  {label}: {val:.2f}x" for label, val in psych_ranked[:4] if val > 0]
    low_psych_lines = [f"  {label}: {val:.2f}x" for label, val in psych_ranked if val < 0.8 and val > 0]
    psych_summary_block = "TOP PSYCHOGRAPHIC SIGNALS (ranked high to low):\n" + ("\n".join(top_psych_lines) if top_psych_lines else "  No psychographic index data available")
    if low_psych_lines:
        psych_summary_block += "\nLOW-INDEX INTERESTS TO AVOID AS CREATIVE ANCHORS:\n" + "\n".join(low_psych_lines)

    lapse_prob = intel.get("lapse_prob")
    upgrade_prob = intel.get("upgrade_prob")
    lapse_label = intel.get("lapse_label")
    upgrade_label = intel.get("upgrade_label")
    pct_predicted_lapse = intel.get("pct_predicted_lapse")
    cluster_upgrade_rate_pct = intel.get("cluster_upgrade_rate_pct")
    mail_idx = psych.get("idx_mail_responder")
    predictive_block = (
        "PREDICTIVE CONTEXT (aggregated donor-level metrics only):\n"
        f"  Lapse risk average: {('N/A' if lapse_prob is None else f'{round(float(lapse_prob)*100,1)}%')}"
        f" | label: {lapse_label or 'N/A'}"
        f" | pct predicted lapse: {('N/A' if pct_predicted_lapse is None else f'{round(float(pct_predicted_lapse)*100,1)}%')}\n"
        f"  Upgrade potential average: {('N/A' if upgrade_prob is None else f'{round(float(upgrade_prob)*100,2)}%')}"
        f" | label: {upgrade_label or 'N/A'}"
        f" | cluster upgrade rate support: {('N/A' if cluster_upgrade_rate_pct is None else f'{round(float(cluster_upgrade_rate_pct)*100,2)}%')}\n"
        f"  Mail responsiveness index: {(str(round(float(mail_idx),2))+'x') if mail_idx is not None else 'N/A'}"
    )

    prompt = f"""You are the Boys Town Appeal Generation Agent. Generate a complete donor appeal concept.

VERIFIED BIGQUERY RFM DATA
Cluster: {cluster_name} | Total appeals analyzed: {len(rows)}
{top3_block}
WORST PERFORMER: {worst["APPEAL_NAME"]} | score: {worst["rfm_composite_score"]}
GIFT LADDER: ${low} / ${mid} / ${high}
555 RULE: {rule_555_text}
UNDERPERFORMING: {underperforming_text}
{theme_line}
{mail_line}
{last_pkg_line}{override_block}

DEMOGRAPHICS: Age {best.get("Age_Range","N/A")} | {best.get("MaritalStatus","N/A")} | {best.get("HomeOwnership","N/A")} | Children: {best.get("Children","N/A")} | Income: {best.get("EstimatedHHIncomeAvg","N/A")} | Net Worth: {best.get("EstimatedNetWorth","N/A")}
URBANICITY: {rural_pct} rural | {suburban_pct} suburbs & towns | {urban_pct} cities & surrounds | {metro_pct} downtown metro
DOMINANT GEOGRAPHY HINT: Use the largest urbanicity share when describing donor lifestyle and mail receptivity.
{geography_block}

PSYCHOGRAPHIC INTEREST INDEXES (1.0 = file average; 2.0 = twice the file average):
Faith/Inspirational: {_safe_float(psych.get("idx_faith")) or 0.0:.2f}x | Charity/Community: {_safe_float(psych.get("idx_charity")) or 0.0:.2f}x | Grandchildren: {_safe_float(psych.get("idx_grandchildren")) or 0.0:.2f}x | Gardening: {_safe_float(psych.get("idx_gardening")) or 0.0:.2f}x | Cooking: {_safe_float(psych.get("idx_cooking")) or 0.0:.2f}x | Travel: {_safe_float(psych.get("idx_travel")) or 0.0:.2f}x | Investing: {_safe_float(psych.get("idx_investment")) or 0.0:.2f}x | Real Estate: {_safe_float(psych.get("idx_real_estate")) or 0.0:.2f}x
Mail Responsiveness Index: {(str(round(float(psych.get("idx_mail_responder")),2))+"x") if psych.get("idx_mail_responder") is not None else "N/A (no data)"} | Veteran: {float(psych.get("pct_veteran") or 0.0):.1%} | Homeowner: {float(psych.get("pct_homeowner") or 0.0):.1%} | Likely Investor: {float(psych.get("pct_likely_investor") or 0.0):.1%}
{psych_summary_block}
{predictive_block}
{timing_block}
{acquisition_block}
{transparency_block}
CREATIVE DIRECTION RULE: Use the highest-indexing interests to drive theme, imagery, and add-in selection. An index of 2.0+ on faith means faith-based creative is strongly supported by data — state the index when you reference it. An index above 1.5 on any interest is a data-supported creative anchor. An index below 0.8 means this cluster under-indexes on that interest — do not use it as a creative anchor.

PSYCHOGRAPHIC INDEX HONESTY RULE: A psychographic index of 1.0 is a neutral, population-average signal — it means the cluster is no more interested in that area than anyone else. Never cite a 1.0 index as evidence supporting a creative theme or add-in choice. The minimum threshold to cite an index as supporting evidence in Rationale is 1.2. Indexes of 1.5+ are strong creative anchors. Indexes of 2.0+ are definitive anchors. When a user-specified Creative Direction drives the appeal concept, the Rationale must explicitly state that the theme was chosen by creative direction — not by psychographic data. If the relevant psychographic index for that theme is at or near 1.0, omit it from Rationale entirely and justify the concept using other factors: appeal history, add-in performance, cluster lifestyle, mission alignment, or the explicit creative direction instruction.

{addin_perf_block}

{economics_block}

VERIFIED ROI DATA — top appeals by actual ROI for this cluster:
{chr(10).join([f"  {r.get('APPEAL_NAME','N/A')} | {int(r.get('pieces_mailed') or 0):,} pieces | cost ${float(r.get('total_mail_cost') or 0):,.0f} | revenue ${float(r.get('total_revenue') or 0):,.0f} | net ${float(r.get('net_return') or 0):,.0f} | ROI {float(r.get('roi_pct') or 0):.0f}%" for r in roi_rows]) if roi_rows else "  No verified ROI data available for this cluster/recommended appeal match."}
NOTE: AppealClusterROI is the source of truth for historical financial recommendations. Do not invent ROI where no verified ROI row exists.
BEST APPEAL PERFORMANCE BREAKDOWN: R={best.get("r_score","N/A")} | F={best.get("f_score","N/A")} | M={best.get("m_score","N/A")} | Composite = (R×0.20)+(F×0.40)+(M×0.40). Scores 1–5, benchmarked within this cluster only — a 5 here means best among all appeals for THIS cluster, not globally. F and M carry 80% of the weight. Precise meanings: R (Recency) = days since last gift from this appeal as of Aug 31 2025 cutoff — {best.get("recency_days_24mo","N/A")} days; score 5 = most recent, score 1 = oldest. F (Frequency) = total transaction count in 24mo window (one donor giving 3× = 3); score 5 = most transactions for this cluster. M (Monetary) = total dollars raised in 24mo window; score 5 = highest revenue for this cluster. These are APPEAL-LEVEL performance signals only — not donor demographics. Creative use: low R means this appeal format has aged and needs a freshened concept; high F means the format drove repeat giving so lean into loyalty/belonging tone; high M means the concept motivated larger gifts so use impact/legacy framing. NOTE: response_rate_pct is directional only — it divides 24mo transactions by lifetime targeted donors, so newer appeals may appear more responsive than older ones.
RESPONSE CONTEXT: Best appeal response rate = {response_rate:.2f}% | cluster average appeal response rate = {(f'{cluster_response_baseline:.2f}%' if cluster_response_baseline is not None else 'N/A')} | lift vs cluster average = {(f'{lift_pct:.1f}%' if lift_pct is not None else 'N/A')}
REVENUE CONTEXT (24mo window): Total dollars raised = ${best.get("total_gift_amount","N/A")} | Most recent gift date = {best.get("most_recent_gift_date","N/A")} | Unique donors who gave = {best.get("donors_responded_24mo","N/A")}

KNOWLEDGE BASE - APPEAL CREATIVE REFERENCE:
{appeal_creative}

KNOWLEDGE BASE - WORST PERFORMER CREATIVE (study these patterns to avoid them):
{worst_creative}

KNOWLEDGE BASE - APPEAL RULES:
{appeal_rules}

Generate using ONLY these headings in EXACTLY this order:
## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

Rules:
- Theme: Write a memorable campaign title on line 1 — this is the headline that will appear on the brief and potentially on the package itself. A subtitle after a colon is encouraged when it sharpens the concept (e.g. "Bright Futures Bloom: Nurturing Hope at Boys Town"). Then, on a new line, write 2-3 sentences explaining the emotional angle, how the concept connects to Boys Town's mission, and why it fits this specific cluster. This section should be immediately usable by a copywriter or creative director without additional context.
- Imagery: describe 2-3 specific visual motifs that will appear in the appeal package — what children are doing, what setting or environment surrounds them, what lighting and mood the photography conveys, and any illustrative or decorative elements on the letter or add-in. Be specific enough that a photographer or art director could brief from this description directly. Ground the imagery in this cluster's demographics and geographic profile. If a Creative Direction was specified, the imagery must incorporate recognizable visual elements from that direction. Children are always depicted with dignity — hopeful, forward-looking, never in distress.
- Color Palette: if a Creative Direction was specified, choose colors that best serve that theme and audience — do NOT default to Boys Town blue and gold unless they genuinely fit the concept. If no Creative Direction was given, use Boys Town brand colors as the foundation. Establish the palette before selecting the add-in so that the add-in design can reference the campaign colors.
- Premium Add-In: Select the add-in by working through this priority order: (1) best qualified historical add-in test for this cluster, if available; (2) best-performer anchor from the appeal creative reference; (3) knowledge-base rules and psychographic fit. Only claim lift vs baseline when a real no-add-in baseline row exists. If no add-in row met the confidence threshold, say the choice is directional rather than historically proven.
- Envelope Teaser Options: write exactly 3 distinct teaser copy options for the outer envelope. Label them: **Curiosity-Led**, **Emotion-Led**, and **Benefit-Led**. Each is one line of copy only.
- Letter Opening: write a 3-4 sentence directional draft of the donor letter opening paragraph. First person voice, warm and personal. Lead with a specific child story or moment tied to the appeal theme. This is a directional draft, not final copy — label it clearly as such.
- Call to Action: use ONLY **${low}**, **${mid}**, and **${high}**. Keep those exact three amounts in ascending order. Each amount must have one concise thematic description line. Do not introduce any other ask amounts.
- Inspired By: Write exactly three labeled bullets. Historical Signal: Name the specific appeal(s) that drove the concept — include the appeal ID, name, and the key metric that justified it (response rate, average gift, ROI, or add-in performance). Explain what specific element was borrowed (theme, add-in type, imagery, timing). When referencing appeal RFM scores (R, F, M), these are appeal-level performance scores benchmarked within this cluster only — use them to explain why that appeal was chosen, not to describe donor quality. Directional Only: Identify any psychographic indexes, demographic signals, or data patterns that influenced creative decisions but are not verified performance signals. Any index cited must be 1.2 or above — do not cite 1.0 as directional support. If the cluster composite RFM score informed a statement about overall cluster health or donor quality, cite it here with the actual score. Fallback from General Rules: Identify any elements that defaulted to knowledge-base rules or general best practices because no cluster-specific data was available (e.g. gift ladder amounts, mail window, add-in selection).
- Target Cluster Summary: write 5-7 sentences. Include: (1) the age range, income level, and household composition of the cluster; (2) the dominant geography feel — urbanicity character (rural, suburban, urban, or mixed) with the largest urbanicity share called out, plus the top state or states when state concentration is geographically meaningful; (3) the top 2 psychographic indexes most relevant to the creative concept with their actual index values; (4) peak giving month and recommended mail drop window; (5) lapse risk level and what it implies for creative tone; (6) the single strongest creative implication that ties all of these signals together into the concept. Write interpretively in full sentences — do not use bullet points or restate raw numbers without context.
- Rationale: You MUST write exactly two paragraphs separated by a blank line. A single paragraph is incorrect and incomplete. Paragraph 1: explain why the creative concept fits this cluster — reference the specific psychographic signals, RFM context, or appeal history that drove the theme and add-in choice. If a Creative Direction was specified, state that it drove the concept and identify what data factors supported or complicated it. If a psychographic index was cited, it must be 1.2 or above — do not cite neutral 1.0 signals as support. Paragraph 2: explain the strategic decisions — what you rotated away from, how mail date or last package influenced the approach, and any cost or performance guardrails applied (e.g. underperforming cluster add-in restriction, directional vs. verified data).
- Testing Notes: write exactly 3 A/B test hypotheses. Format each as: **Variable** | Control: [what you would keep] vs. Test: [what you would change] | Expected outcome: [specific directional prediction]. Keep each hypothesis to one sentence.
- Appeal Package Image Prompt: Write a single detailed prompt for a flat-lay blueprint image of ALL mail components. Follow every instruction below precisely.
{IMAGE_PROMPT_STEPS}
"""

    ensure_vertex_ai()
    model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
    response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
    response_text = enforce_ask_ladder_consistency(response.text, low, mid, high)
    response_text = enforce_output_integrity(response_text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=addin_info.get("has_real_baseline", False))

    donor_count = int(best.get("cluster_donor_count") or 0)
    best_roi = roi_rows[0] if roi_rows else None
    cost_per_piece = _safe_float(best.get("COST"))
    total_mail_cost = round(cost_per_piece * donor_count, 2) if cost_per_piece is not None and donor_count else None
    economics_pieces = economics.get("pieces_mailed") if economics and economics.get("has_usable_costs") else None
    economics_cpp = economics.get("cost_per_piece") if economics and economics.get("has_usable_costs") else None
    economics_total_cost = economics.get("total_mail_cost") if economics and economics.get("has_usable_costs") else None
    real_net_return = _safe_float(best_roi.get("net_return")) if best_roi else None
    real_roi_pct = _safe_float(best_roi.get("roi_pct")) if best_roi else None
    real_pieces = _safe_int(best_roi.get("pieces_mailed")) if best_roi else None
    real_revenue = _safe_float(best_roi.get("total_revenue")) if best_roi else None
    real_cost = _safe_float(best_roi.get("total_mail_cost")) if best_roi else None

    top_psych = psych_ranked[0][0] if psych_ranked and psych_ranked[0][1] > 0 else None
    top_psych_idx = psych_ranked[0][1] if psych_ranked and psych_ranked[0][1] > 0 else None

    meta = {
        "cluster": cluster_name,
        "theme": custom_theme,
        "mail_date": mail_date,
        "last_package": last_package,
        "best_appeal": best["APPEAL_NAME"],
        "best_score": best["rfm_composite_score"],
        "avg_gift": avg,
        "response_rate_pct": response_rate,
        "response_rate_baseline_pct": round(cluster_response_baseline, 2) if cluster_response_baseline is not None else None,
        "lift_pct": lift_pct,
        "low": low, "mid": mid, "high": high,
        "ladder_source": ladder_source,
        "distribution_confidence": gift_dist.get("distribution_confidence") if gift_dist else None,
        "has_gift_distribution": bool(gift_dist),
        "worst_appeal": worst["APPEAL_NAME"],
        "worst_score": worst["rfm_composite_score"],
        "total_appeals": len(rows),
        "rule_555": rule_555,
        "underperforming": underperforming,
        "cluster_donor_count": donor_count,
        "anticipated_revenue": round(donor_count * (response_rate / 100) * avg, 2),
        "donors_responded_24mo": int(best.get("donors_responded_24mo") or 0),
        "cost_per_piece": cost_per_piece,
        "total_mail_cost": total_mail_cost,
        "real_net_return": real_net_return,
        "real_roi_pct": real_roi_pct,
        "real_pieces": real_pieces,
        "real_revenue": real_revenue,
        "real_cost": real_cost,
        "has_real_roi": bool(roi_rows),
        "has_economics": bool(economics),
        "economics_pieces": economics_pieces,
        "economics_cost_per_piece": economics_cpp,
        "economics_total_mail_cost": economics_total_cost,
        "gift_timing": gift_timing,
        "acquisition": acquisition,
        "appeal_r": int(best.get("r_score") or 0),
        "appeal_f": int(best.get("f_score") or 0),
        "appeal_m": int(best.get("m_score") or 0),
        "lapse_prob": lapse_prob,
        "lapse_label": lapse_label,
        "pct_predicted_lapse": pct_predicted_lapse,
        "upgrade_prob": upgrade_prob,
        "upgrade_label": upgrade_label,
        "cluster_upgrade_rate_pct": cluster_upgrade_rate_pct,
        "income": best.get("EstimatedHHIncomeAvg", "N/A"),
        "net_worth": best.get("EstimatedNetWorth", "N/A"),
        "urbanicity_rural": pct_number(best.get("UrbanicityRural")),
        "urbanicity_suburban": pct_number(best.get("UrbanicitySuburbsandTowns")),
        "urbanicity_urban": pct_number(best.get("UrbanicityCitiesandSurrounds")),
        "urbanicity_metro": pct_number(best.get("UrbanicityDowntownMetro")),
        "mail_responsiveness_idx": round(float(psych.get("idx_mail_responder") or 0), 2) if psych.get("idx_mail_responder") is not None else None,
        "top_psychographic": top_psych,
        "top_psychographic_idx": round(top_psych_idx, 2) if top_psych_idx is not None else None,
        "second_psychographic": psych_ranked[1][0] if len(psych_ranked) > 1 and psych_ranked[1][1] > 0 else None,
        "second_psychographic_idx": round(psych_ranked[1][1], 2) if len(psych_ranked) > 1 and psych_ranked[1][1] > 0 else None,
        "third_psychographic": psych_ranked[2][0] if len(psych_ranked) > 2 and psych_ranked[2][1] > 0 else None,
        "third_psychographic_idx": round(psych_ranked[2][1], 2) if len(psych_ranked) > 2 and psych_ranked[2][1] > 0 else None,
        "addin_override": addin_override,
        "imagery_override": imagery_override,
        "teaser_override": teaser_override,
        "envelope_format": envelope_format,
        "ladder_low": ladder_low,
        "ladder_mid": ladder_mid,
        "ladder_high": ladder_high,
        "ladder_override": bool(ladder_low or ladder_mid or ladder_high),
        "has_timing": bool(gift_timing),
        "has_geography": bool(geo_rows),
        "geo_top_state": (geo_rows[0].get("State_Abbr") if geo_rows else None),
        "geo_top_state_pct": (round(float(geo_rows[0].get("pct_of_cluster_donors") or 0), 2) if geo_rows else None),
        "geo_top3_concentration": round(sum(float(r.get("pct_of_cluster_donors") or 0) for r in (geo_rows[:3] if geo_rows else [])), 2),
        "has_psychographics": bool(psych),
        "has_roi": bool(roi_rows),
        "has_cohorts": bool(acquisition and not acquisition.get("insufficient_rows")),
        "has_rfm": True,
        "data_warnings": data_warnings,
        "addin_confidence_qualified": addin_info.get("qualified_count", 0) > 0,
        "addin_has_real_baseline": addin_info.get("has_real_baseline", False),
    }
    return response_text, meta, None


def refine(previous_output, instruction, meta):
    """Re-generate an appeal with a targeted refinement, preserving the original data context."""
    ensure_vertex_ai()

    low = meta.get('low', 25)
    mid = meta.get('mid', 50)
    high = meta.get('high', 100)
    cluster = meta.get('cluster', 'Unknown')
    theme = meta.get('theme', '')
    addin_override = meta.get('addin_override', '')
    imagery_override = meta.get('imagery_override', '')
    has_real_baseline = meta.get('addin_has_real_baseline', False)

    context_lines = [f"Cluster: {cluster}"]
    if theme:
        context_lines.append(f"Creative Direction: {theme}")
    if meta.get('mail_date'):
        context_lines.append(f"Mail Date: {meta['mail_date']}")
    if meta.get('last_package'):
        context_lines.append(f"Last Package: {meta['last_package']}")
    context_block = "\n".join(context_lines)

    prompt = f"""You previously generated the following Boys Town direct mail appeal concept:

--- PREVIOUS OUTPUT START ---
{previous_output}
--- PREVIOUS OUTPUT END ---

ORIGINAL CONTEXT:
{context_block}
Gift Ladder: ${low} / ${mid} / ${high} — do not change these amounts unless the refinement explicitly asks for it.

THE USER HAS REQUESTED THIS REFINEMENT:
"{instruction}"

Regenerate the FULL appeal incorporating this change. Keep everything else intact unless the change logically requires adjustments to other sections (e.g. changing the add-in should update the image prompt to match). Use EXACTLY these section headings in this order:

## Theme
## Imagery
## Color Palette
## Premium Add-In
## Envelope Teaser Options
## Letter Opening
## Call to Action
## Inspired By
## Target Cluster Summary
## Rationale
## Testing Notes
## Appeal Package Image Prompt

The Appeal Package Image Prompt must reflect any changes made to the appeal sections above. Follow the same image prompt construction steps used in the original.

{IMAGE_PROMPT_STEPS}
"""

    model = GenerativeModel("gemini-2.5-flash", system_instruction=SYSTEM_PROMPT)
    try:
        response = model.generate_content(prompt, generation_config=GENERATION_CONFIG)
        text = enforce_ask_ladder_consistency(response.text, low, mid, high)
        text = enforce_output_integrity(text, addin_override=addin_override, imagery_override=imagery_override, has_real_baseline=has_real_baseline)
        return text, None
    except Exception as e:
        logger.exception("REFINE_ERROR: %s", e)
        return None, str(e)

