import sys
import importlib.util
import pathlib
import pytest

# ── Load module from hyphenated filename ────────────────────────────────────
spec = importlib.util.spec_from_file_location(
    "app",
    str(pathlib.Path(__file__).parent / "boys-town-appeal-generator.py")
)
app_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app_module)

clean_text_input       = app_module.clean_text_input
normalize_color_triplet = app_module.normalize_color_triplet
parse_ladder_override  = app_module.parse_ladder_override
normalize_bool         = app_module.normalize_bool

# ── clean_text_input ─────────────────────────────────────────────────────────
def test_clean_text_input_none_returns_empty():
    assert clean_text_input(None) == ""

def test_clean_text_input_collapses_whitespace():
    assert clean_text_input("  hello   world  ") == "hello world"

def test_clean_text_input_truncates_to_max_len():
    assert clean_text_input("abcdefghij", max_len=5) == "abcde"

# ── normalize_color_triplet ──────────────────────────────────────────────────
def test_normalize_color_triplet_valid():
    assert normalize_color_triplet(["#ff0000", "#00ff00", "#0000ff"]) == ["#FF0000", "#00FF00", "#0000FF"]

def test_normalize_color_triplet_adds_hash():
    assert normalize_color_triplet(["ff0000", "00ff00", "0000ff"]) == ["#FF0000", "#00FF00", "#0000FF"]

def test_normalize_color_triplet_wrong_length():
    assert normalize_color_triplet(["#ff0000", "#00ff00"]) is None

def test_normalize_color_triplet_invalid_color():
    assert normalize_color_triplet(["#ff0000", "#00ff00", "notacolor"]) is None

# ── parse_ladder_override ────────────────────────────────────────────────────
def test_parse_ladder_override_valid_ascending():
    low, mid, high, ok = parse_ladder_override("25", "50", "100")
    assert ok is True and low == 25 and mid == 50 and high == 100

def test_parse_ladder_override_not_ascending():
    _, _, _, ok = parse_ladder_override("100", "50", "25")
    assert ok is False

def test_parse_ladder_override_empty_inputs():
    low, mid, high, ok = parse_ladder_override("", "", "")
    assert ok is False and low is None

# ── normalize_bool ───────────────────────────────────────────────────────────
def test_normalize_bool_true_variants():
    assert normalize_bool(True) is True
    assert normalize_bool("true") is True
    assert normalize_bool("yes") is True
    assert normalize_bool(1) is True

def test_normalize_bool_false_variants():
    assert normalize_bool(False) is False
    assert normalize_bool("0") is False
    assert normalize_bool(0) is False
